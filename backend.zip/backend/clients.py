"""
This file will handle all network clients and allow for refreshing and creating session objects.
This is important, because Porn Fetch will dynamically need to update the different website APIs
for example if you apply a proxy.

If I only use one specific file that handles everything, it's easier to manage it, because I have more control
where I import stuff from.

I know this might seem a bit confusing if you read this the first time, but if you look at the `eaf_base_api` module
and the other Porn APIs and how they are working together, then you will definitely understand why this matters.
"""

"""
Current APIs:

1) PHUB           -> https://pornhub.com (ph_client, ph_video)
2) hqporner       -> https://hqporner.com (hq_client, hq_video)
3) xnxx           -> https://xnxx.com (xn_client, xn_video)
4) xvideos        -> https://xvideos.com (xv_client, xv_video)
5) eporner        -> https://eporner.com (ep_client, ep_video)
6) missav         -> https://missav.ws   (mv_client, mv_video)
7) xhamster       -> https://xhamster.com (xh_client, xh_video)
8) spankbang      -> https://spankbang.com (sp_client, sp_video)
9) youporn        -> https://youporn.com (yp_client, yp_video)
10) porntrex      -> https://porntrex.com (pt_client, pt_video)
11) xfreehd       -> https://xfreehd.com  (xf_client, xf_video)
12) beeg          -> https://beeg.com (bg_client, bg_video)
13) porngo        -> https://porngo.com (pg_client, pg_video)
"""

import re
import logging
import traceback
from types import SimpleNamespace


try:
    from src.backend.handle_ssl import build_ssl_context

except (ModuleNotFoundError, ImportError):
    from handle_ssl import build_ssl_context

from dataclasses import dataclass
from base_api.modules.config import config # This is the global configuration instance of base core config
from datetime import datetime, timedelta, timezone
from typing import Any, List, TypeAlias, Optional, Dict
from mutagen.mp4 import MP4, MP4Cover, MP4Tags
try:
    from dateutil.relativedelta import relativedelta
except Exception:
    relativedelta = None
from phub import Client as ph_Client, Video as ph_Video
from xnxx_api import Client as xn_Client, Video as xn_Video
from beeg_api import Client as bg_Client, Video as bg_Video
from porngo_api import Client as pg_Client, Video as pg_Video
from missav_api import Client as mv_Client, Video as mv_Video
from xvideos_api import Client as xv_Client, Video as xv_Video
from xfreehd_api import Client as xf_Client, Video as xf_Video
from eporner_api import Client as ep_Client, Video as ep_Video
from porntrex_api import Client as pt_Client, Video as pt_Video
from xhamster_api import Client as xh_Client, Video as xh_Video
from spankbang_api import Client as sp_Client, Video as sp_Video
from youporn_api.youporn_api import Client as yp_Client, Video as yp_Video
from hqporner_api import Client as hq_Client, Video as hq_Video, errors as hq_errors
from base_api.base import BaseCore, setup_logger, _normalize_quality_value, _choose_quality_from_list
# Note, the Video instances are mostly used in `shared_functions.py`
AllowedVideoType: TypeAlias = (
    type[ph_Video] | type[xn_Video] | type[xv_Video] | type[yp_Video] |
    type[xh_Video] | type[sp_Video] | type[bg_Video] | type[mv_Video]
    # Those are all HLS streams
)

AllowedVideoType_Legacy: TypeAlias = (
    type[hq_Video] | type[xf_Video] | type[ep_Video] | type[pt_Video] | type[pt_Video]
    # Those are all non HLS streams for now
)

_RELATIVE_RE = re.compile(
    r"^\s*(?P<num>\d+)\s*(?P<unit>second|minute|hour|day|week|month|year)s?\s+ago\s*$",
    re.IGNORECASE,
)

_PUBLISHED_ON_RE = re.compile(
    r"^\s*published\s+on\s+(?P<date>.+?)\s*$",
    re.IGNORECASE,
)

_TEMPLATE_RE = re.compile(r"\$(\w+)|\$\{([^}]+)}")

_NOT_AVAILABLE_RE = re.compile(r"^\s*(not\s+available|n/?a|none|null)?\s*$", re.IGNORECASE)
logger = setup_logger(name="Porn Fetch - [Clients]", level=logging.DEBUG, log_file="PornFetch.log")


class _FallbackCore:
    def __init__(self):
        self.config = SimpleNamespace(max_retries=2, use_http2=False, timeout=10)
        self.session = SimpleNamespace(headers={})

    def strip_title(self, value: Any) -> str:
        return "" if value is None else str(value)

    def enable_logging(self, *args, **kwargs) -> None:
        return None

    def enable_kill_switch(self, *args, **kwargs) -> None:
        return None

    def initialize_session(self, *args, **kwargs) -> None:
        return None

    def fetch(self, *args, **kwargs) -> bytes:
        raise RuntimeError("BaseCore session is unavailable.")

    def list_available_qualities(self, *args, **kwargs) -> list[int]:
        return []


def _log_exception(message: str) -> None:
    logger.error("%s\n%s", message, traceback.format_exc())


def _create_base_core(
    core_name: str,
    *,
    log_level: int | None = None,
    log_file: str | None = None,
    enable_kill_switch: bool = False,
    initialize_session: bool = False,
) -> BaseCore | None:
    try:
        new_core = BaseCore(config=config)
        new_core.config.max_retries = 2
        new_core.config.use_http2 = False
        new_core.config.timeout = 10

        if log_level is not None:
            new_core.enable_logging(level=log_level, log_file=log_file)

        if enable_kill_switch:
            new_core.enable_kill_switch()

        if initialize_session:
            new_core.initialize_session()

        return new_core

    except Exception:
        _log_exception(f"Failed to create BaseCore for {core_name}.")
        return None


def _safe_build_client(name: str, factory, *, fallback=None, **kwargs):
    try:
        client = factory(**kwargs)
        logger.debug("Initialized %s client.", name)
        return client

    except Exception:
        _log_exception(f"Failed to initialize {name} client.")
        return fallback


def _ensure_client(attr_name: str, display_name: str, factory):
    client = globals().get(attr_name)
    if client is not None:
        return client

    client = _safe_build_client(display_name, factory)
    globals()[attr_name] = client
    return client


def _safe_getattr(obj: Any, attr: str) -> Any:
    try:
        return getattr(obj, attr)
    except Exception:
        return None


def _safe_call(func, *args, default=None, context: str = "", **kwargs):
    try:
        return func(*args, **kwargs)
    except Exception:
        if context:
            _log_exception(context)
        return default


def _coalesce(*values: Any, default: Any = None) -> Any:
    for value in values:
        if value is None:
            continue
        if isinstance(value, str) and _NOT_AVAILABLE_RE.match(value):
            continue
        return value
    return default


def _safe_first(value: Any, default: Any = None) -> Any:
    if value is None:
        return default
    if isinstance(value, str):
        return value or default

    try:
        return next(iter(value))
    except Exception:
        return default


def _safe_csv(value: Any, *, attr: str | None = None, default: str = "Not available") -> str:
    if value is None:
        return default

    if isinstance(value, str):
        return value or default

    try:
        values = list(value)
    except Exception:
        single_value = _safe_getattr(value, attr) if attr else value
        return default if single_value in (None, "") else str(single_value)

    output: list[str] = []
    for item in values:
        if attr:
            item = _safe_getattr(item, attr)
        if item in (None, ""):
            continue
        output.append(str(item))

    return ",".join(output) or default


def _parse_quality_number(value: Any) -> Optional[int]:
    if value is None:
        return None

    try:
        return int(value)
    except Exception:
        match = re.search(r"(\d{2,4})", str(value))
        return int(match.group(1)) if match else None


def _normalize_quality_list(values: Any) -> list[int]:
    normalized: set[int] = set()
    for value in values or []:
        parsed = _parse_quality_number(value)
        if parsed is not None:
            normalized.add(parsed)
    return sorted(normalized)


def _quality_prefers_high_bandwidth(quality: str | int) -> bool:
    if isinstance(quality, str):
        normalized = quality.strip().lower()
        if normalized in ("best", "half"):
            return True

    normalized_value = _normalize_quality_value(quality)
    return isinstance(normalized_value, int) and normalized_value > 480


def _safe_strip_title(value: Any) -> str:
    text = "" if value is None else str(value)

    try:
        stripped = core.strip_title(text)
    except Exception:
        _log_exception("Failed to sanitize title with BaseCore.")
        stripped = text

    return stripped or text or "video"


def _build_fallback_video_attributes(video, *, now: Optional[datetime] = None) -> "VideoAttributes":
    title = str(_coalesce(_safe_getattr(video, "title"), _safe_getattr(video, "video_id"), default="Unknown title"))
    publish_date = _coalesce(_safe_getattr(video, "publish_date"), default="Not available")

    return VideoAttributes(
        title=title,
        qualities=get_available_qualities(video),
        author=str(_coalesce(_safe_getattr(video, "author"), default="Not available")),
        length=_coalesce(_safe_getattr(video, "length"), default="Not available"),
        tags=str(_coalesce(_safe_getattr(video, "tags"), default="Not available")),
        publish_date=publish_date,
        publish_dt_utc=parse_publish_date(publish_date, now=now),
        thumbnail=str(_coalesce(_safe_getattr(video, "thumbnail"), default="Not available")),
        video_id=str(_coalesce(_safe_getattr(video, "id"), title, default="Unknown title")),
        output_name=_safe_strip_title(title),
        index=0,
        video=video,
    )

# which is also affecting all other APIs when the refresh_clients function is called
# Initialize clients globally, so that we can override them later with a new configuration from BaseCore if needed
mv_client = None
ep_client = None
ph_client = None
xv_client = None
xh_client = None
sp_client = None
hq_client = None
xn_client = None
yp_client = None
bg_client = None
pt_client = None
xf_client = None
pg_client = None


core: BaseCore | _FallbackCore = _FallbackCore() # We need that sometimes in Porn Fetch's main class e.g., thumbnail fetching


def _initialize_default_clients() -> None:
    global mv_client, ep_client, ph_client, xv_client, xh_client, sp_client, hq_client, xn_client
    global yp_client, bg_client, pt_client, xf_client, pg_client, core

    initialized_core = _create_base_core("shared/default", initialize_session=True)
    if initialized_core is not None:
        core = initialized_core
    else:
        logger.warning("Using fallback BaseCore because the default shared core could not be created.")

    mv_client = _safe_build_client("missav", mv_Client, fallback=mv_client)
    ep_client = _safe_build_client("eporner", ep_Client, fallback=ep_client)
    ph_client = _safe_build_client("pornhub", ph_Client, fallback=ph_client)
    xv_client = _safe_build_client("xvideos", xv_Client, fallback=xv_client)
    xh_client = _safe_build_client("xhamster", xh_Client, fallback=xh_client)
    sp_client = _safe_build_client("spankbang", sp_Client, fallback=sp_client)
    hq_client = _safe_build_client("hqporner", hq_Client, fallback=hq_client)
    xn_client = _safe_build_client("xnxx", xn_Client, fallback=xn_client)
    yp_client = _safe_build_client("youporn", yp_Client, fallback=yp_client)
    bg_client = _safe_build_client("beeg", bg_Client, fallback=bg_client)
    pt_client = _safe_build_client("porntrex", pt_Client, fallback=pt_client)
    xf_client = _safe_build_client("xfreehd", xf_Client, fallback=xf_client)
    pg_client = _safe_build_client("porngo", pg_Client, fallback=pg_client)
    logger.debug("Finished best-effort initialization of backend clients.")


_initialize_default_clients()


def get_direct_url_legacy(video: AllowedVideoType_Legacy, quality: str | int):
    """
    Since the non HLS downloads now support resuming by getting the current filesize
    and appending missing bytes, we need a way in Porn Fetch to actually see if a file is incomplete.

    If we don't do this, the skip existing files feature wouldn't work or I would need to find another
    more complex implementation for this.

    This helper function basically just gets the direct download URL for a given quality based on each API
    that uses mp4 streams.
    """

    try:
        if isinstance(video, xf_Video) or isinstance(video, pg_Video):
            cdn_urls = list(_safe_getattr(video, "cdn_urls") or [])
            if not cdn_urls:
                return "MakesNoSense"

            if _quality_prefers_high_bandwidth(quality): # Bro pls don't ask :rose:
                return cdn_urls[1] if len(cdn_urls) > 1 else cdn_urls[0]

            return cdn_urls[0]

        elif isinstance(video, hq_Video) or isinstance(video, pt_Video):
            qn = _normalize_quality_value(quality)
            video_qualities = list(_safe_getattr(video, "video_qualities") or [])
            chosen_height = _choose_quality_from_list(video_qualities, qn)
            download_urls = list(_safe_call(video.direct_download_urls, default=[], context="Failed to fetch direct download URLs.") or [])

            quality_url_map = {
                int(re.search(r"(\d{3,4})", q).group(1)): url
                for q, url in zip(video_qualities, download_urls)
                if re.search(r"(\d{3,4})", str(q))
            }
            download_url = quality_url_map.get(chosen_height)
            return f"https://{download_url}" if download_url else "MakesNoSense"

        elif isinstance(video, ep_Video):
            return _safe_call(
                video.direct_download_link,
                quality=quality,
                mode="h264",
                default="MakesNoSense",
                context="Failed to resolve EPorner direct download URL.",
            )
            # NO I won't spend half on hour to handle this edge case where one video on this whole platform might not have
            # A h264 stream bro

    except Exception:
        _log_exception("Failed to resolve legacy direct download URL.")

    return "MakesNoSense"


def refresh_clients(enable_kill_switch: bool = False, debug_mode: bool = False, use_truststore: bool = True) -> None:
    logger.info(f"Refreshing clients!")
    try:
        config.ssl_context = build_ssl_context(use_truststore) # Decides whether to use truststore (OS CA's) or Certifi CA's
    except Exception:
        _log_exception("Failed to rebuild SSL context while refreshing clients.")

    global mv_client, ep_client, ph_client, xv_client, xh_client, sp_client, \
        hq_client, xn_client, core, yp_client, bg_client, pt_client, xf_client, pg_client

    if debug_mode:
        level = logging.DEBUG

    else:
        level = logging.ERROR


    log_file_core = "BaseCore.log" if debug_mode else None
    log_file_core_hq = "BaseCore_HQ.log" if debug_mode else None
    log_file_core_mv = "BaseCore_MV.log" if debug_mode else None
    log_file_core_ep = "BaseCore_EP.log" if debug_mode else None
    log_file_core_ph = "BaseCore_PH.log" if debug_mode else None
    log_file_core_xv = "BaseCore_XV.log" if debug_mode else None
    log_file_core_xh = "BaseCore_XH.log" if debug_mode else None
    log_file_core_xn = "BaseCore_XN.log" if debug_mode else None
    log_file_core_sp = "BaseCore_SP.log" if debug_mode else None
    log_file_core_yp = "BaseCore_YP.log" if debug_mode else None
    log_file_core_bg = "BaseCore_BG.log" if debug_mode else None
    log_file_core_pt = "BaseCore_PT.log" if debug_mode else None
    log_file_core_xf = "BaseCore_XF.log" if debug_mode else None
    log_file_core_pg = "BaseCore_PG.log" if debug_mode else None

    refreshed_core = _create_base_core("shared", log_level=level, log_file=log_file_core, enable_kill_switch=enable_kill_switch)
    if refreshed_core is not None:
        core = refreshed_core
    else:
        logger.warning("Keeping the existing shared BaseCore because the refresh failed.")

    site_specs = [
        ("missav", "mv_client", mv_Client, log_file_core_mv, {}),
        ("eporner", "ep_client", ep_Client, log_file_core_ep, {}),
        ("pornhub", "ph_client", ph_Client, log_file_core_ph, {"use_webmaster_api": True}),
        ("xvideos", "xv_client", xv_Client, log_file_core_xv, {}),
        ("xhamster", "xh_client", xh_Client, log_file_core_xh, {}),
        ("spankbang", "sp_client", sp_Client, log_file_core_sp, {}),
        ("hqporner", "hq_client", hq_Client, log_file_core_hq, {}),
        ("xnxx", "xn_client", xn_Client, log_file_core_xn, {}),
        ("youporn", "yp_client", yp_Client, log_file_core_yp, {}),
        ("beeg", "bg_client", bg_Client, log_file_core_bg, {}),
        ("porntrex", "pt_client", pt_Client, log_file_core_pt, {}),
        ("xfreehd", "xf_client", xf_Client, log_file_core_xf, {}),
        ("porngo", "pg_client", pg_Client, log_file_core_pg, {}),
    ]

    if enable_kill_switch:
        logger.warning("Warning: You have enabled the kill switch, refreshing clients with enabled kill switch")

    for site_name, attr_name, factory, log_file, extra_kwargs in site_specs:
        site_core = _create_base_core(
            site_name,
            log_level=level,
            log_file=log_file,
            enable_kill_switch=enable_kill_switch,
        )
        if site_core is None:
            logger.warning("Keeping the existing %s client because its BaseCore refresh failed.", site_name)
            continue

        client = _safe_build_client(
            site_name,
            factory,
            fallback=globals().get(attr_name),
            core=site_core,
            **extra_kwargs,
        )
        globals()[attr_name] = client

    logger.debug("Applied new clients. Configurations should be overridden now e.g., if you have set a proxy.")


def check_video(url):
    """
    This function check the URL and generates the corresponding video object with the correct client.
    If the url is already a video object, the function will simply return it.
    """

    objects = [hq_Video, ep_Video, xn_Video, xv_Video, mv_Video, xh_Video, sp_Video, yp_Video, bg_Video, pt_Video,
               xf_Video, pg_Video]

    if isinstance(url, tuple(objects)):
        return url

    if isinstance(url, str) and len(url) > 0 and url.startswith("http"):
        def fetch_with_client(attr_name: str, display_name: str, factory, method_name: str, **kwargs):
            client = _ensure_client(attr_name, display_name, factory)
            if client is None:
                logger.error("Client %s is unavailable, cannot resolve URL: %s", display_name, url)
                return False

            try:
                method = getattr(client, method_name)
                return method(url, **kwargs)
            except Exception:
                _log_exception(f"Failed to resolve URL with {display_name}: {url}")
                return False

        if "pornhub" in url:
            return fetch_with_client("ph_client", "pornhub", ph_Client, "get")

        if "hqporner" in url:
            return fetch_with_client("hq_client", "hqporner", hq_Client, "get_video")

        elif "eporner" in url:
            return fetch_with_client("ep_client", "eporner", ep_Client, "get_video", enable_html_scraping=True)

        elif "xnxx" in url:
            return fetch_with_client("xn_client", "xnxx", xn_Client, "get_video")

        elif "xvideos" in url:
            return fetch_with_client("xv_client", "xvideos", xv_Client, "get_video")

        elif "missav" in url:
            return fetch_with_client("mv_client", "missav", mv_Client, "get_video")

        elif "xhamster" in str(url) and "moments" in str(url) and not isinstance(url, xh_Video):
            return fetch_with_client("xh_client", "xhamster", xh_Client, "get_short")

        elif "xhamster" in url or "xhopen" in url:
            return fetch_with_client("xh_client", "xhamster", xh_Client, "get_video")

        elif "spankbang" in url:
            return fetch_with_client("sp_client", "spankbang", sp_Client, "get_video")

        elif "youporn" in url:
            return fetch_with_client("yp_client", "youporn", yp_Client, "get_video")

        elif "beeg.com" in str(url):
            return fetch_with_client("bg_client", "beeg", bg_Client, "get_video")

        elif "porntrex" in str(url):
            return fetch_with_client("pt_client", "porntrex", pt_Client, "get_video")

        elif "xfreehd" in str(url):
            return fetch_with_client("xf_client", "xfreehd", xf_Client, "get_video")

        elif "porngo" in str(url):
            return fetch_with_client("pg_client", "porngo", pg_Client, "get_video")

        else:
            return False

    return False


def get_available_qualities(video: Any) -> List[int]:
    """
    Returns sorted unique qualities worst->best as ints.
    Works for:
      - HLS videos: video.m3u8_base_url + video.core.list_available_qualities()
      - Legacy videos: video.video_qualities (e.g. ["360", "480", "720"])
    """
    # ---- HLS (m3u8) ----
    m3u8_url = _safe_getattr(video, "m3u8_base_url")
    if m3u8_url:
        try:
            client_core = _safe_getattr(video, "core")
            if client_core is None:
                client_core = _safe_getattr(_safe_getattr(video, "client"), "core")

            if client_core is None:
                return []

            heights = client_core.list_available_qualities(m3u8_url)  # your existing function
            return _normalize_quality_list(heights)
        except Exception:
            _log_exception("Failed to load available HLS qualities.")
            return []

    # ---- Legacy ----
    # Your legacy wrapper already exposes `video_qualities` as list[str]
    if isinstance(video, ep_Video):
        quals = _safe_call(video.video_qualities, default=[], context="Failed to load EPorner qualities.")

    else:
        quals = _safe_getattr(video, "video_qualities")

    if quals:
        try:
            return _normalize_quality_list(quals)
        except Exception:
            _log_exception("Failed to normalize quality list.")
            return []

    return []

def resolve_path(context: Dict[str, Any], path: str) -> Any:
    """
    Resolve 'title' or 'author.name' or 'video.some_attr' from context.
    """
    cur: Any = context
    for part in path.split("."):
        if isinstance(cur, dict):
            cur = cur.get(part)
        else:
            cur = _safe_getattr(cur, part)
        if cur is None:
            return None
    return cur

def render_name_template(
    template: str,
    context: Dict[str, Any],
    *,
    missing: str = "",
) -> str:
    """
    Supports:
      $title
      ${author.name}
      ${publish_date:%Y-%m-%d}
      ${length:0.1f}  (uses Python's format())
    """
    def repl(m: re.Match) -> str:
        simple = m.group(1)
        braced = m.group(2)

        if simple:
            value = resolve_path(context, simple)
            return missing if value is None else str(value)

        expr = (braced or "").strip()

        # optional format: path:format_spec
        path, fmt = expr, None
        if ":" in expr:
            # split on first ':' (good enough for your use-case)
            path, fmt = expr.split(":", 1)
            path, fmt = path.strip(), fmt.strip()

        value = resolve_path(context, path)
        if value is None:
            return missing

        if fmt:
            if isinstance(value, datetime):
                return value.strftime(fmt)
            try:
                return format(value, fmt)
            except Exception:
                return str(value)

        return str(value)

    try:
        return _TEMPLATE_RE.sub(repl, str(template))
    except Exception:
        _log_exception("Failed to render title template.")
        return ""

@dataclass
class VideoAttributes:
    title: str
    qualities: list[int]
    author: str
    length: Any
    tags: str
    publish_date: Any
    publish_dt_utc: Optional[datetime]
    thumbnail: str
    video_id: str
    # rendered output
    output_name: str
    index: int
    video: object

def _public_attr_snapshot(obj: Any) -> Dict[str, Any]:
    """
    Best-effort map of public attrs without calling methods.
    WARNING: some properties may still perform I/O when accessed.
    """
    out: Dict[str, Any] = {}
    try:
        names = dir(obj)
    except Exception:
        return out

    for name in names:
        if name.startswith("_"):
            continue
        # skip obvious methods/iterables by type check after getattr
        val = _safe_getattr(obj, name)
        if callable(val):
            continue
        out[name] = val
    return out

def load_video_attributes(video, name_template: str = "$title", *, now: Optional[datetime] = None) -> VideoAttributes:
    try:
        title = str(_coalesce(_safe_getattr(video, "title"), _safe_getattr(video, "video_id"), default="Unknown title"))
        qualities = get_available_qualities(video)  # [144, 240, 360, ...]

        def minutes_from_seconds(value: Any, default: Any = "Not available") -> Any:
            try:
                return round(int(value) // 60)
            except Exception:
                return default

        # --- your per-site extraction (unchanged logic, but isolated per field) ---
        if isinstance(video, ph_Video):
            author = _coalesce(
                _safe_getattr(_safe_getattr(video, "author"), "name"),
                _safe_first(_safe_getattr(video, "pornstars")),
                default="Not available",
            )
            duration_seconds = _safe_getattr(_safe_getattr(video, "duration"), "seconds")
            length = duration_seconds / 60 if isinstance(duration_seconds, (int, float)) else "Not available"
            tags = _safe_csv(_safe_getattr(video, "tags"), attr="name")
            publish_date = _coalesce(_safe_getattr(video, "date"), default="Not available")
            _safe_call(video.refresh, context=f"Failed to refresh video metadata for {title}.")
            thumbnail = _coalesce(_safe_getattr(_safe_getattr(video, "image"), "url"), default="Not available")
            video_id = _coalesce(_safe_getattr(video, "id"), title, default=title)

        elif isinstance(video, xn_Video):
            author = _coalesce(_safe_getattr(video, "author"), default="Not available")
            length = _coalesce(_safe_getattr(video, "length"), default="Not available")
            tags = _safe_csv(_safe_getattr(video, "tags"))
            publish_date = _coalesce(_safe_getattr(video, "publish_date"), default="Not available")
            thumbnail = _coalesce(_safe_first(_safe_getattr(video, "thumbnail_url")), default="Not available")
            video_id = _coalesce(_safe_getattr(video, "title"), title, default=title)

        elif isinstance(video, xv_Video):
            author = _coalesce(_safe_getattr(_safe_getattr(video, "author"), "name"), _safe_getattr(video, "author"), default="Not available")
            length = _coalesce(_safe_getattr(video, "length"), default="Not available")
            tags = _safe_csv(_safe_getattr(video, "tags"))
            publish_date = _coalesce(_safe_getattr(video, "publish_date"), default="Not available")
            thumbnail = _coalesce(_safe_getattr(video, "thumbnail_url"), default="Not available")
            video_id = _coalesce(_safe_getattr(video, "title"), title, default=title)

        elif isinstance(video, ep_Video):
            author = _coalesce(_safe_getattr(video, "author"), default="Not available")
            length = _coalesce(_safe_getattr(video, "length_minutes"), default="Not available")
            tags = _safe_csv(_safe_getattr(video, "tags"))
            publish_date = _coalesce(_safe_getattr(video, "publish_date"), default="Not available")
            thumbnail = _coalesce(_safe_getattr(video, "thumbnail"), default="Not available")
            video_id = _coalesce(_safe_getattr(video, "video_id"), title, default=title)

        elif isinstance(video, hq_Video):
            author = _coalesce(_safe_first(_safe_getattr(video, "pornstars")), default="No pornstars / author")
            length = _coalesce(_safe_getattr(video, "length"), default="Not available")
            tags = _safe_csv(_safe_getattr(video, "tags"))
            publish_date = _coalesce(_safe_getattr(video, "publish_date"), default="Not available")
            video_id = _coalesce(_safe_getattr(video, "title"), title, default=title)
            thumbnail = _coalesce(
                _safe_first(_safe_call(video.get_thumbnails, default=[], context=f"Failed to fetch HQ thumbnails for {title}.")),
                default="Not available",
            )

        elif isinstance(video, mv_Video):
            author = "Not available"
            length = "Not available"
            tags = "Not available"
            thumbnail = _coalesce(_safe_getattr(video, "thumbnail"), default="Not available")
            publish_date = _coalesce(_safe_getattr(video, "publish_date"), default="Not available")
            video_id = _coalesce(_safe_getattr(video, "video_code"), title, default=title)

        elif isinstance(video, yp_Video):
            author = _coalesce(_safe_getattr(_safe_getattr(video, "author"), "name"), _safe_getattr(video, "author"), default="Not available")
            length = minutes_from_seconds(_safe_getattr(video, "length"))
            tags = _safe_csv(_safe_getattr(video, "categories"))
            thumbnail = _coalesce(_safe_getattr(video, "thumbnail"), default="Not available")
            publish_date = _coalesce(_safe_getattr(video, "publish_date"), default="Not available")
            video_id = _coalesce(_safe_getattr(video, "title"), title, default=title)

        elif isinstance(video, xh_Video):
            author = _safe_csv(_safe_getattr(video, "pornstars"))
            length = "Not available"
            tags = "Not available"
            thumbnail = _coalesce(_safe_getattr(video, "thumbnail"), default="Not available")
            publish_date = "Not available"
            video_id = _coalesce(_safe_getattr(video, "title"), title, default=title)

        elif isinstance(video, sp_Video):
            author = _coalesce(_safe_getattr(video, "author"), default="Not available")
            length = minutes_from_seconds(_safe_getattr(video, "length"))
            tags = _safe_csv(_safe_getattr(video, "tags"))
            thumbnail = _coalesce(_safe_getattr(video, "thumbnail"), default="Not available")
            publish_date = "Not available"
            video_id = _coalesce(_safe_getattr(video, "title"), title, default=title)

        elif isinstance(video, bg_Video):
            author = "Not available"
            duration = _safe_getattr(video, "duration")
            length = minutes_from_seconds(duration)
            tags = "Not available"
            thumbnail = "Not available"
            publish_date = "Not available"
            video_id = _coalesce(_safe_getattr(video, "video_id"), title, default=title)

        elif isinstance(video, pt_Video):
            author = _coalesce(_safe_getattr(video, "author"), default="Not available")
            length = _coalesce(_safe_getattr(video, "duration"), default="Not available")
            tags = _safe_csv(_safe_getattr(video, "tags"))
            thumbnail = _coalesce(_safe_getattr(video, "thumbnail"), default="Not available")
            publish_date = _coalesce(_safe_getattr(video, "publish_date"), default="Not available")
            video_id = _coalesce(_safe_getattr(video, "video_id"), title, default=title)

        elif isinstance(video, xf_Video):
            author = _coalesce(_safe_getattr(video, "author"), default="Not available")
            length = _coalesce(_safe_getattr(video, "length"), default="Not available")
            tags = _safe_csv(_safe_getattr(video, "tags"))
            thumbnail = _coalesce(_safe_getattr(video, "thumbnail"), default="Not available")
            publish_date = _coalesce(_safe_getattr(video, "publish_date"), default="Not available")
            video_id = _coalesce(_safe_getattr(video, "title"), title, default=title)

        elif isinstance(video, pg_Video):
            author = _coalesce(_safe_getattr(video, "author"), default="Not available")
            length = "Not available"
            tags = _safe_csv(_safe_getattr(video, "categories"))
            thumbnail = _coalesce(_safe_getattr(video, "thumbnail"), default="Not available")
            publish_date = "Not available"
            video_id = _coalesce(_safe_getattr(video, "title"), title, default=title)

        else:
            # fallback if you ever add a new site and forget to implement it
            author = _coalesce(_safe_getattr(video, "author"), default="Not available")
            length = _coalesce(_safe_getattr(video, "length"), default="Not available")
            tags = _safe_csv(_safe_getattr(video, "tags"))
            publish_date = _coalesce(_safe_getattr(video, "publish_date"), default="Not available")
            thumbnail = _coalesce(_safe_getattr(video, "thumbnail"), default="Not available")
            video_id = _coalesce(_safe_getattr(video, "id"), title, default=title)

        # Normalize publish date into UTC datetime (optional extra field)
        publish_dt_utc = parse_publish_date(publish_date, now=now)

        # Build template context:
        # - normalized keys (stable)
        # - "video" for deep access: ${video.some_attr}
        # - raw snapshot so users can also do $some_attr if it exists
        normalized = {
            "title": title,
            "qualities": qualities,
            "qualities_csv": ",".join(map(str, qualities)),
            "author": author,
            "length": length,
            "tags": tags,
            "publish_date": publish_date,         # original
            "publish_dt": publish_dt_utc,         # parsed datetime (UTC)
            "thumbnail": thumbnail,
            "video_id": video_id,
        }
        raw = _public_attr_snapshot(video)

        context: Dict[str, Any] = {}
        context.update(raw)        # allow $publish_date if the object has it, etc.
        context.update(normalized) # normalized wins if same name
        context["video"] = video   # allow ${video.author.name} etc.

        rendered = render_name_template(name_template, context, missing="")
        rendered = _safe_strip_title(rendered or title)
        logger.debug("Rendered name for %s: %s", title, rendered)
        return VideoAttributes(
            title=title,
            qualities=qualities,
            author=str(author),
            length=length,
            tags=str(tags),
            publish_date=publish_date,
            publish_dt_utc=publish_dt_utc,
            thumbnail=str(thumbnail),
            video_id=str(video_id),
            output_name=rendered,
            index=0,
            video=video
        )

    except Exception:
        _log_exception("Failed to load video attributes; falling back to minimal attributes.")
        return _build_fallback_video_attributes(video, now=now)



def parse_publish_date(value: str, *, now: Optional[datetime] = None) -> Optional[datetime]:
    """
    Parse a publish-date string from various sites and return a timezone-aware datetime in UTC.

    Parameters
    ----------
    value : str
        Raw publish date text.
    now : datetime | None
        Reference time for relative strings like "7 days ago".
        Defaults to current time in UTC.

    Returns
    -------
    datetime | None
        A timezone-aware datetime in UTC, or None if not parseable / not available.
    """
    if value is None:
        return None

    s = str(value).strip()
    if _NOT_AVAILABLE_RE.match(s):
        return None

    now_utc = (now or datetime.now(timezone.utc))
    if now_utc.tzinfo is None:
        now_utc = now_utc.replace(tzinfo=timezone.utc)
    else:
        now_utc = now_utc.astimezone(timezone.utc)

    # 1) Relative: "7 days ago", "4 months ago", etc.
    m = _RELATIVE_RE.match(s)
    if m:
        num = int(m.group("num"))
        unit = m.group("unit").lower()

        if unit in ("second", "minute", "hour", "day", "week"):
            seconds = {
                "second": 1,
                "minute": 60,
                "hour": 3600,
                "day": 86400,
                "week": 7 * 86400,
            }[unit]
            return now_utc - timedelta(seconds=num * seconds)

        # month/year need calendar arithmetic
        if relativedelta is None:
            logger.warning("python-dateutil is unavailable, cannot parse relative month/year publish dates.")
            return None

        if unit == "month":
            return now_utc - relativedelta(months=num)
        if unit == "year":
            return now_utc - relativedelta(years=num)

    # 2) "Published on September 17, 2024"
    m = _PUBLISHED_ON_RE.match(s)
    if m:
        s = m.group("date").strip()

    # 3) Try ISO 8601 (handles "2025-10-17T22:56:30+00:00")
    # datetime.fromisoformat also accepts "YYYY-MM-DD" and "YYYY-MM-DD HH:MM:SS" in many cases.
    try:
        dt = datetime.fromisoformat(s.replace("Z", "+00:00"))
        if dt.tzinfo is None:
            # Assume naive timestamps are UTC. Change this if you prefer local time.
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)
    except ValueError:
        pass

    # 4) Try common long-form date (after stripping "Published on")
    # Example: "September 17, 2024"
    for fmt in ("%B %d, %Y", "%b %d, %Y"):
        try:
            dt = datetime.strptime(s, fmt).replace(tzinfo=timezone.utc)
            return dt
        except ValueError:
            continue

    return None


def download_android(url: str, quality="best", path="./", remux=False):
    """
    Downloads a video and reports progress back to Kotlin ProgressBridge.
    Note: This is intended to be used by the Android App, NOT the main gui in `main.py` nor the CLI!
    """
    video = check_video(url)
    if not video:
        return False

    try:
        from java import jclass
        ProgressBridge = jclass("me.echteralsfake.pornfetch.ProgressBridge")
    except Exception:
        _log_exception("Android bridge is unavailable.")
        return False

    def cb(current, total):
        try:
            ProgressBridge.onProgress(int(current), int(total))
        except Exception:
            pass

    try:
        return video.download(
            quality=quality,
            path=path,
            callback=cb,
            remux=remux,
            no_title=True
        )
    except Exception:
        _log_exception(f"Failed to download Android video: {url}")
        return False


def write_tags(path: str, data: VideoAttributes):
    """
    Writes the tags of the video into the file. This needs a correct MP4 header either from a remuxed mpeg-ts stream
    through PyAV or the stream is already an mp4 file e.g., from EPorner or HQPorner.
    """
    try:
        comment   = "Downloaded with Porn Fetch (GPLv3)"
        genre     = "Porn"
        title     = data.get("title") if isinstance(data, dict) else getattr(data, "title", None)
        artist    = data.get("author") if isinstance(data, dict) else getattr(data, "author", None)
        date      = data.get("publish_date") if isinstance(data, dict) else getattr(data, "publish_date", None)
        thumbnail = data.get("thumbnail_data") if isinstance(data, dict) else getattr(data, "thumbnail_data", None)
        logging.debug("Tags [1/3]")

        audio = MP4(path)

        # Ensure an 'ilst' tag container exists
        if audio.tags is None:
            try:
                audio.add_tags()          # preferred; creates empty MP4Tags
            except Exception:
                pass
        if audio.tags is None:
            audio.tags = MP4Tags()        # fallback for older/env-specific builds

        # Write basic text tags (skip Nones)
        if title  is not None:  audio.tags["\xa9nam"] = str(title)
        if artist is not None:  audio.tags["\xa9ART"] = str(artist)
        if comment is not None: audio.tags["\xa9cmt"] = str(comment)
        if genre  is not None:  audio.tags["\xa9gen"] = str(genre)
        if date   is not None:  audio.tags["\xa9day"] = str(date)

        logging.debug("Tags: [2/3] - Writing Thumbnail")

        # Optional: embed cover art if it's JPEG/PNG
        if thumbnail:
            try:
                # Heuristically choose cover format
                if thumbnail.startswith(b"\x89PNG\r\n\x1a\n"):
                    fmt = MP4Cover.FORMAT_PNG
                else:
                    # JPEG has many possible headers; default to JPEG if not PNG
                    fmt = MP4Cover.FORMAT_JPEG

                cover = MP4Cover(thumbnail, imageformat=fmt)
                audio.tags["covr"] = [cover]  # must be a list
            except Exception as e:
                logging.error(
                    "Could not embed thumbnail: %s - Image URL: %s", e, thumbnail
                )

        audio.save()
        logging.debug("Tags: [3/3] ✔")
        return True

    except Exception:
        _log_exception(f"Failed to write tags for file: {path}")
        return False


def parse_length(length, video_source=None):
    # DO NOT TOUCH THIS!!!!!!!!!!!!!!!!!!!!!!

    "Entirely written and copied from ChatGPT. My brain is not ready to fix that myself now, seriously..."
    """
    Parse a video length value and return its duration in minutes (rounded).

    Notes:
      - If length is already numeric (int/float), it is assumed to be in minutes.
      - If length is a string:
          * A string of the format "mm:ss" (e.g. "16:19") is parsed as minutes and seconds.
          * A digits-only string is treated based on the source:
              - If video_source contains "xnxx", then the value is already in minutes.
              - If video_source contains "eporner" or "phub", then the value is in seconds.
              - Otherwise, digits-only defaults to minutes.
          * A string with a decimal point is assumed to be a minute value.
          * If the string contains "min" (case-insensitive), the numeric part is extracted and used as minutes.
          * Otherwise, we try to extract components from mixed formats such as "59m 40s" or "24 seconds".
      - If no valid duration is found (or if the video source provides no length information),
        returns "Not available".

    In all conversions, if the computed minute value is > 0 but rounds to 0, returns 1 instead.
    """
    if length in (None, "", "Not available"):
        return "Not available"

    try:
        # If already numeric (non-string) assume minutes.
        if isinstance(length, (int, float)):
            # Ensure that a small positive value returns at least 1 minute.
            result = round(length)
            return result if result > 0 else (1 if length > 0 else 0)

        # Work with a stripped string.
        s = str(length).strip()
        s_lower = s.lower()

        # -------------------------------
        # Case 1: "mm:ss" format (e.g. "16:19")
        if ":" in s:
            parts = s.split(":")
            if len(parts) == 2 and parts[0].isdigit() and parts[1].isdigit():
                minutes = int(parts[0])
                seconds = int(parts[1])
                total = minutes + seconds / 60.0
                result = round(total)
                if result == 0 and total > 0:
                    result = 1
                return result

        # -------------------------------
        # Case 2: Digits-only string.
        if s.isdigit():
            num = int(s)
            if video_source:
                src = str(video_source).lower()
                if "xnxx" in src:
                    # xnxx provides minutes directly.
                    return num
                elif "eporner" in src or "phub" in src:
                    # These sites give seconds; convert to minutes.
                    result = round(num / 60)
                    if result == 0 and num > 0:
                        result = 1
                    return result
                else:
                    # Default: assume minutes.
                    return num
            else:
                # Without a source hint, default to minutes.
                return num

        # -------------------------------
        # Case 3: Value with a decimal point (assumed to be minutes).
        if '.' in s:
            try:
                val = float(s)
                result = round(val)
                if result == 0 and val > 0:
                    result = 1
                return result
            except ValueError:
                pass

        # -------------------------------
        # NEW Case 4a: "<value>min <value>sec/seconds" (e.g. "247min 02sec")
        # Supports: min|mins|minute|minutes and sec|secs|second|seconds (any case), spaces optional.
        m = re.search(
            r'(?i)\b(\d+(?:\.\d+)?)\s*(?:min|mins|minute|minutes)\s*(\d+(?:\.\d+)?)\s*(?:sec|secs|second|seconds)\b',
            s
        )
        if m:
            minutes = float(m.group(1))
            seconds = float(m.group(2))
            total = minutes + seconds / 60.0
            result = round(total)
            if result == 0 and total > 0:
                result = 1
            return result

        # -------------------------------
        # Case 4: Contains "min" (e.g. "9 Min")
        if "min" in s_lower:
            # Extract only the first contiguous number near 'min' to avoid picking up trailing seconds.
            # This keeps existing behavior for strings like "17 min".
            # If seconds are present, the regex case above will have returned already.
            num_str = ''.join(ch for ch in s if ch.isdigit() or ch == '.')
            if num_str:
                try:
                    val = float(num_str)
                    result = round(val)
                    if result == 0 and val > 0:
                        result = 1
                    return result
                except ValueError:
                    pass

        # -------------------------------
        # Case 5: Mixed time units such as "59m 40s" or "1h 2m 3s"
        # (Extended to accept long-form units too.)
        time_units = {
            's': 1 / 60, 'sec': 1 / 60, 'secs': 1 / 60, 'second': 1 / 60, 'seconds': 1 / 60,
            'm': 1, 'min': 1, 'mins': 1, 'minute': 1, 'minutes': 1,
            'h': 60, 'hr': 60, 'hrs': 60, 'hour': 60, 'hours': 60
        }
        total_minutes = 0.0
        for part in s.split():
            # Extract numeric (or decimal) part and letter part.
            value_str = ''.join(ch for ch in part if ch.isdigit() or ch == '.')
            unit_str = ''.join(ch for ch in part if ch.isalpha()).lower()
            if value_str and unit_str in time_units:
                try:
                    total_minutes += float(value_str) * time_units[unit_str]
                except ValueError:
                    continue
        if total_minutes > 0:
            result = round(total_minutes)
            if result == 0 and total_minutes > 0:
                result = 1
            return result

        # -------------------------------
        # Case 6: Formats like "24 seconds"
        if s_lower.endswith("second") or s_lower.endswith("seconds") or s_lower.endswith("sec") or s_lower.endswith(
                "secs"):
            num_str = ''.join(ch for ch in s if ch.isdigit() or ch == '.')
            if num_str:
                try:
                    sec = float(num_str)
                    result = round(sec / 60)
                    if result == 0 and sec > 0:
                        result = 1
                    return result
                except ValueError:
                    pass

        # -------------------------------
        # Case 7: Formats ending with "min" (e.g. "17 min")
        if s_lower.endswith("min") or s_lower.endswith("mins") or s_lower.endswith("minute") or s_lower.endswith(
                "minutes"):
            # Pull the leading number(s)
            m_only = re.search(r'(\d+(?:\.\d+)?)', s)
            if m_only:
                val = float(m_only.group(1))
                result = round(val)
                if result == 0 and val > 0:
                    result = 1
                return result

        # If nothing matches, return None.
        return None

    except Exception:
        return 0


class VideoData:
    """
    This class stores the video objects and their loaded data across Porn Fetch.
    It allows for re-fetching data if needed, update data if needed and handles caching thanks to
    a dictionary.

    (Okay, I am overhyping it a bit, but yeah, let's put that away xD)
    """

    data_objects = {}
    consistent_data = {}  # This dictionary stores other important data which will be re-used for the entire
    # run of Porn Fetch

    """
    If a video object isn't used anymore e.g., the video finished downloading or the tree widget was loaded with other
    videos, than those videos will be cleaned up in the dictionary, to be as memory and performance efficient as
    possible.
    """

    def clean_dict(self, video_titles):
        if not isinstance(video_titles, list):  # In case we only have one video title to delete
            video_titles = [video_titles]

        for video_title in video_titles:
            removed = self.data_objects.pop(video_title, None)
            if removed is None:
                logger.debug("VideoData.clean_dict skipped missing title: %s", video_title)


# EOF
