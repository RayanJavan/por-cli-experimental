"""
This file stores the main instance of Porn Fetch's configuration file,
so that only one instance is active, preventing memory errors and disk
overwriting when different classes hold their own instances and overwrite
each other.
"""
# config.py
import os.path
from configparser import ConfigParser

shared_config = ConfigParser()
shared_config.read("config.ini")
__license__ = "GPL 3"
__version__ = "3.8"
__author__ = "Johannes Habel"
__next_release__ = "3.9"
__type__ = "release"
__bundle_id__ = "me.echteralsfake.pornfetch"
__org__ = "EchterAlsFake"
PUBLIC_KEY_B64 = 'zGUmG8Z5InvoYIwnIokQi+SysjEodvfP8kLoCur3KjM=' # This is the public key for the license verification
IS_SOURCE_RUN = False

TEMP_DIRECTORY = ".temp"
TEMP_DIRECTORY_STATES = os.path.join(TEMP_DIRECTORY, "states")
TEMP_DIRECTORY_SEGMENTS = os.path.join(TEMP_DIRECTORY, "segments")
