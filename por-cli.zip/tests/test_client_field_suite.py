from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from porcli.config import OperationTemplate
from porcli.models.enums import ExternalSource
from porcli.models.raw import TransportRequest, TransportResponse
from porcli.probes.client_field_suite import (
    ClientFieldProbeCandidate,
    ClientFieldSourceConfig,
    ClientFieldSuiteConfig,
    ClientFieldSuiteRunner,
    SearchFieldProbeConfig,
    VideoFieldProbeConfig,
    _extract_external_ids_from_payload,
    build_default_client_field_suite_config,
)


class RecordingTransport:
    def __init__(self, payload: dict[str, object]) -> None:
        self.payload = payload
        self.requests: list[TransportRequest] = []

    async def send(self, request: TransportRequest) -> TransportResponse:
        self.requests.append(request)
        return TransportResponse(
            request=request,
            status_code=200,
            headers={"content-type": "application/json"},
            text=json.dumps(self.payload),
            json_payload=self.payload,
        )

    async def aclose(self) -> None:
        return None


class ClientFieldSuiteTests(unittest.IsolatedAsyncioTestCase):
    def test_default_suite_config_contains_both_sources(self) -> None:
        config = build_default_client_field_suite_config()

        self.assertEqual([source.source for source in config.sources], [ExternalSource.XHAMSTER, ExternalSource.EPORNER])
        self.assertGreaterEqual(len(config.sources[0].search.candidates), 1)  # type: ignore[union-attr]
        self.assertGreaterEqual(len(config.sources[1].video.candidates), 1)  # type: ignore[union-attr]

    def test_external_id_extraction_uses_source_specific_normalization(self) -> None:
        xhamster_ids = _extract_external_ids_from_payload(
            ExternalSource.XHAMSTER,
            {
                "data": [
                    {
                        "id": "valid-slug-xh123",
                        "link": "https://xhamster.com/videos/valid-slug-xh123",
                    }
                ]
            },
            max_count=3,
        )
        eporner_ids = _extract_external_ids_from_payload(
            ExternalSource.EPORNER,
            {
                "data": {
                    "id": "video-8NJrKjZNe1X/example",
                    "video": "https://www.eporner.com/embed/8NJrKjZNe1X/",
                }
            },
            max_count=3,
        )

        self.assertEqual(xhamster_ids, ["valid-slug-xh123"])
        self.assertEqual(eporner_ids, ["8NJrKjZNe1X"])

    async def test_runner_writes_search_artifacts(self) -> None:
        payload = {
            "source": "https://xhamster.example/search/milf?page=1",
            "data": [
                {
                    "id": "valid-slug-xh123",
                    "link": "https://xhamster.com/videos/valid-slug-xh123",
                    "title": "Valid title",
                }
            ],
        }
        transport = RecordingTransport(payload)
        config = ClientFieldSuiteConfig(
            sources=[
                ClientFieldSourceConfig(
                    source=ExternalSource.XHAMSTER,
                    base_url="https://xhamster.example",
                    search=SearchFieldProbeConfig(
                        queries=["milf"],
                        pages=[1],
                        candidates=[
                            ClientFieldProbeCandidate(
                                name="query-params",
                                template=OperationTemplate(
                                    path_template="/search",
                                    query_templates={"q": "{query}", "page": "{page}"},
                                ),
                            )
                        ],
                    ),
                    video=VideoFieldProbeConfig(enabled=False),
                )
            ]
        )

        with tempfile.TemporaryDirectory() as temp_dir:
            runner = ClientFieldSuiteRunner(
                config,
                output_directory=Path(temp_dir),
                transport_factory=lambda: transport,
            )

            report = await runner.run()

            self.assertEqual(report.case_count, 1)
            self.assertEqual(report.failed_case_count, 0)
            self.assertEqual(len(transport.requests), 1)
            self.assertEqual(transport.requests[0].query, {"q": "milf", "page": "1"})

            report_json = json.loads((Path(temp_dir) / "report.json").read_text(encoding="utf-8"))
            self.assertEqual(report_json["case_count"], 1)
            summary_path = (
                Path(temp_dir)
                / "artifacts"
                / "xhamster"
                / "search"
                / "query-params"
                / "query-milf__page-1"
                / "response-summary.json"
            )
            summary = json.loads(summary_path.read_text(encoding="utf-8"))
            self.assertEqual(summary["status_code"], 200)
            self.assertEqual(summary["extracted_external_ids"], ["valid-slug-xh123"])


if __name__ == "__main__":
    unittest.main()
