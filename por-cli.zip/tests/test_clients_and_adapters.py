from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from porcli.adapters.eporner import EpornerAdapter
from porcli.adapters.xhamster import XHamsterAdapter
from porcli.clients.xhamster import XHamsterClientStrategy
from porcli.config import OperationTemplate, SourceClientProfile
from porcli.models.enums import ClientOperation, ExternalSource
from porcli.models.raw import RawClientResponse, TransportRequest, TransportResponse
from porcli.models.requests import SearchRequest, VideoLookupRequest


class RecordingTransport:
    def __init__(self, response: TransportResponse | None = None) -> None:
        self.requests: list[TransportRequest] = []
        self.response = response

    async def send(self, request: TransportRequest) -> TransportResponse:
        self.requests.append(request)
        if self.response is not None:
            return self.response
        return TransportResponse(request=request, status_code=200, headers={}, text="")


class ClientAndAdapterTests(unittest.IsolatedAsyncioTestCase):
    async def test_client_strategy_builds_request_from_profile_templates(self) -> None:
        profile = SourceClientProfile(
            source=ExternalSource.XHAMSTER,
            base_url="https://xhamster.example",
            search=OperationTemplate(
                path_template="/search",
                query_templates={"q": "{query}", "page": "{page}"},
                headers={"x-test": "1"},
            ),
        )
        transport = RecordingTransport()
        client = XHamsterClientStrategy(profile=profile, transport=transport)

        response = await client.search(SearchRequest(query="milf", page=2))

        self.assertEqual(response.source, ExternalSource.XHAMSTER)
        self.assertEqual(response.operation, ClientOperation.SEARCH)
        self.assertEqual(len(transport.requests), 1)
        sent = transport.requests[0]
        self.assertEqual(sent.url, "https://xhamster.example/search")
        self.assertEqual(sent.query, {"q": "milf", "page": "2"})
        self.assertEqual(sent.headers["x-test"], "1")

    def test_xhamster_adapter_skips_unsupported_redirect_ids(self) -> None:
        adapter = XHamsterAdapter()
        response = RawClientResponse(
            source=ExternalSource.XHAMSTER,
            operation=ClientOperation.SEARCH,
            transport=TransportResponse(
                request=TransportRequest(url="https://xhamster.example/search"),
                status_code=200,
                headers={},
                text="",
                json_payload={
                    "source": "https://xhamster.example/search/milf?page=1",
                    "data": [
                        {
                            "id": "valid-slug-xh123",
                            "link": "https://xhamster.com/videos/valid-slug-xh123",
                            "title": "Valid title",
                            "image": "https://cdn.example/thumb.jpg",
                            "video": "https://xhamster.com/embed/xh123",
                        },
                        {
                            "id": "out?path=%2F",
                            "link": "https://xhamster.com/ff/out?path=%2F",
                            "title": "Ad row",
                        },
                    ],
                },
            ),
        )

        page = adapter.adapt_search(response, SearchRequest(query="milf", page=1))

        self.assertEqual(page.source, ExternalSource.XHAMSTER)
        self.assertEqual(len(page.items), 1)
        self.assertEqual(page.pagination.requested_page, 1)
        self.assertEqual(page.pagination.returned_count, 1)
        self.assertEqual(page.items[0].external_id, "valid-slug-xh123")
        self.assertTrue(page.items[0].capabilities.has_page_url)
        self.assertTrue(page.items[0].capabilities.has_embed_url)
        self.assertTrue(page.items[0].capabilities.has_thumbnail_url)

    def test_eporner_adapter_normalizes_lookup_id_from_video_path(self) -> None:
        adapter = EpornerAdapter()
        response = RawClientResponse(
            source=ExternalSource.EPORNER,
            operation=ClientOperation.VIDEO,
            transport=TransportResponse(
                request=TransportRequest(url="https://www.eporner.com/video"),
                status_code=200,
                headers={},
                text="",
                json_payload={
                    "source": "https://www.eporner.com/video-8NJrKjZNe1X/example/",
                    "data": {
                        "id": "video-8NJrKjZNe1X/example",
                        "title": "Example Title",
                        "image": "https://static.example/thumb.jpg",
                        "duration": "7:20",
                        "views": "123,456",
                        "rating": "92%",
                        "uploaded": "2025-04-01T08:47:43+02:00",
                        "models": ["Performer 1"],
                        "tags": ["Tag 1", "Tag 2"],
                    },
                    "assets": [
                        "https://www.eporner.com/embed/8NJrKjZNe1X/",
                        "https://static.example/thumb.jpg",
                    ],
                },
            ),
        )

        detail = adapter.adapt_video(response, VideoLookupRequest(external_id="fallback"))

        self.assertEqual(detail.reference.external_id, "8NJrKjZNe1X")
        self.assertEqual(detail.reference.embed_url, "https://www.eporner.com/embed/8NJrKjZNe1X/")
        self.assertEqual(detail.performers, ["Performer 1"])
        self.assertEqual(len(detail.assets), 3)
        self.assertTrue(detail.capabilities.has_page_url)
        self.assertTrue(detail.capabilities.has_embed_url)
        self.assertTrue(detail.capabilities.has_thumbnail_url)


if __name__ == "__main__":
    unittest.main()
