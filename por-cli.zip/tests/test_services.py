from __future__ import annotations

import sys
import unittest
from pathlib import Path

from pydantic import ValidationError

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from porcli.adapters.xhamster import XHamsterAdapter
from porcli.clients.xhamster import XHamsterClientStrategy
from porcli.config import OperationTemplate, SourceClientProfile
from porcli.models.canonical import (
    CanonicalCapabilities,
    CanonicalPagination,
    CanonicalSearchPage,
    CanonicalVideoDetail,
    CanonicalVideoReference,
)
from porcli.models.enums import ClientOperation, ExternalSource
from porcli.models.raw import RawClientResponse, TransportRequest, TransportResponse
from porcli.models.requests import SearchRequest, VideoLookupRequest
from porcli.services.catalog import CatalogService
from porcli.services.gateway import AdapterBackedSourceGateway
from porcli.services.models import SourceVideoSelector


class RecordingTransport:
    def __init__(self, response: TransportResponse) -> None:
        self.response = response
        self.requests: list[TransportRequest] = []

    async def send(self, request: TransportRequest) -> TransportResponse:
        self.requests.append(request)
        return self.response


class StubGateway:
    def __init__(self, source: ExternalSource, page: CanonicalSearchPage, detail: CanonicalVideoDetail) -> None:
        self.source = source
        self._page = page
        self._detail = detail

    async def search(self, request: SearchRequest) -> CanonicalSearchPage:
        return self._page

    async def get_video(self, request: VideoLookupRequest) -> CanonicalVideoDetail:
        return self._detail

    async def get_random(self, request=None) -> CanonicalVideoDetail:
        return self._detail


class ServiceLayerTests(unittest.IsolatedAsyncioTestCase):
    def test_strict_inter_layer_schema_rejects_blank_external_id(self) -> None:
        with self.assertRaises(ValidationError):
            SourceVideoSelector(source=ExternalSource.EPORNER, external_id="   ")

    async def test_adapter_backed_gateway_composes_client_and_adapter(self) -> None:
        transport = RecordingTransport(
            TransportResponse(
                request=TransportRequest(url="https://xhamster.example/search"),
                status_code=200,
                headers={},
                text="",
                json_payload={
                    "source": "https://xhamster.example/search/milf?page=1",
                    "data": [
                        {
                            "id": "valid-slug-xh123",
                            "link": "https://xhamster.com/videos/valid-slug-xh123",
                            "title": "Valid title",
                            "image": "https://cdn.example/thumb.jpg",
                            "video": "https://xhamster.com/embed/xh123",
                        }
                    ],
                },
            )
        )
        profile = SourceClientProfile(
            source=ExternalSource.XHAMSTER,
            base_url="https://xhamster.example",
            search=OperationTemplate(
                path_template="/search",
                query_templates={"q": "{query}", "page": "{page}"},
            ),
        )
        client = XHamsterClientStrategy(profile=profile, transport=transport)
        gateway = AdapterBackedSourceGateway(
            source=ExternalSource.XHAMSTER,
            client=type("Context", (), {"search": client.search, "get_video": client.get_video, "get_random": client.get_random})(),
            adapter=XHamsterAdapter(),
        )

        page = await gateway.search(SearchRequest(query="milf", page=1))

        self.assertEqual(page.source, ExternalSource.XHAMSTER)
        self.assertEqual(page.pagination.returned_count, 1)
        self.assertEqual(page.items[0].external_id, "valid-slug-xh123")

    async def test_catalog_service_aggregates_search_results_across_sources(self) -> None:
        xh_ref = CanonicalVideoReference(
            source=ExternalSource.XHAMSTER,
            external_id="xh-1",
            title="xh title",
            capabilities=CanonicalCapabilities(has_page_url=True),
        )
        ep_ref = CanonicalVideoReference(
            source=ExternalSource.EPORNER,
            external_id="ep-1",
            title="ep title",
            capabilities=CanonicalCapabilities(has_page_url=True),
        )
        xh_page = CanonicalSearchPage(
            source=ExternalSource.XHAMSTER,
            query="milf",
            page=1,
            pagination=CanonicalPagination(requested_page=1, returned_count=1),
            items=[xh_ref],
        )
        ep_page = CanonicalSearchPage(
            source=ExternalSource.EPORNER,
            query="milf",
            page=1,
            pagination=CanonicalPagination(requested_page=1, returned_count=1),
            items=[ep_ref],
        )
        xh_detail = CanonicalVideoDetail(
            source=ExternalSource.XHAMSTER,
            reference=xh_ref,
            capabilities=CanonicalCapabilities(has_page_url=True),
        )
        ep_detail = CanonicalVideoDetail(
            source=ExternalSource.EPORNER,
            reference=ep_ref,
            capabilities=CanonicalCapabilities(has_page_url=True),
        )
        service = CatalogService(
            [
                StubGateway(ExternalSource.XHAMSTER, xh_page, xh_detail),
                StubGateway(ExternalSource.EPORNER, ep_page, ep_detail),
            ]
        )

        result = await service.search_sources(
            SearchRequest(query="milf", page=1),
            sources=[ExternalSource.XHAMSTER, ExternalSource.EPORNER],
        )

        self.assertEqual(result.requested_sources, [ExternalSource.XHAMSTER, ExternalSource.EPORNER])
        self.assertEqual(len(result.pages), 2)
        self.assertEqual(len(result.items), 2)
        self.assertEqual(result.page_for(ExternalSource.EPORNER), ep_page)

    async def test_catalog_service_get_video_by_selector(self) -> None:
        reference = CanonicalVideoReference(
            source=ExternalSource.EPORNER,
            external_id="ep-9",
            title="ep title",
            capabilities=CanonicalCapabilities(has_page_url=True),
        )
        page = CanonicalSearchPage(
            source=ExternalSource.EPORNER,
            query="milf",
            page=1,
            pagination=CanonicalPagination(requested_page=1, returned_count=1),
            items=[reference],
        )
        detail = CanonicalVideoDetail(
            source=ExternalSource.EPORNER,
            reference=reference,
            capabilities=CanonicalCapabilities(has_page_url=True, has_embed_url=True),
        )
        service = CatalogService([StubGateway(ExternalSource.EPORNER, page, detail)])

        selected = await service.get_video_by_selector(
            SourceVideoSelector(source=ExternalSource.EPORNER, external_id="ep-9")
        )

        self.assertEqual(selected.reference.external_id, "ep-9")
        self.assertTrue(selected.capabilities.has_embed_url)


if __name__ == "__main__":
    unittest.main()
