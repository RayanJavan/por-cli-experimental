from __future__ import annotations

import io
import json
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from porcli.adapters.xhamster import XHamsterAdapter
from porcli.clients.base import ClientContext
from porcli.clients.xhamster import XHamsterClientStrategy
from porcli.config import OperationTemplate, SourceClientProfile
from porcli.logging import LoggingConfiguration, clear_context, configure_logging, get_logger
from porcli.models.enums import ExternalSource
from porcli.models.raw import TransportRequest, TransportResponse
from porcli.models.requests import SearchRequest
from porcli.services.gateway import AdapterBackedSourceGateway
from porcli.telemetry import (
    TelemetryConfiguration,
    configure_in_memory_telemetry,
    force_flush_telemetry,
    get_tracer,
    shutdown_telemetry,
)


class RecordingTransport:
    def __init__(self, response: TransportResponse) -> None:
        self.response = response
        self.requests: list[TransportRequest] = []

    async def send(self, request: TransportRequest) -> TransportResponse:
        self.requests.append(request)
        return self.response


class TelemetryTests(unittest.IsolatedAsyncioTestCase):
    def tearDown(self) -> None:
        clear_context()
        shutdown_telemetry()

    async def test_gateway_search_emits_one_trace_across_layers(self) -> None:
        harness = configure_in_memory_telemetry(
            TelemetryConfiguration(
                service_name="porcli-tests",
                trace_exporter="none",
                metric_exporter="none",
            )
        )
        transport = RecordingTransport(
            TransportResponse(
                request=TransportRequest(url="https://xhamster.example/search"),
                status_code=200,
                headers={},
                text="",
                json_payload={
                    "source": "https://xhamster.example/search/milf?page=1",
                    "data": [
                        {
                            "id": "valid-slug-xh123",
                            "link": "https://xhamster.com/videos/valid-slug-xh123",
                            "title": "Valid title",
                            "image": "https://cdn.example/thumb.jpg",
                            "video": "https://xhamster.com/embed/xh123",
                        }
                    ],
                },
            )
        )
        profile = SourceClientProfile(
            source=ExternalSource.XHAMSTER,
            base_url="https://xhamster.example",
            search=OperationTemplate(
                path_template="/search",
                query_templates={"q": "{query}", "page": "{page}"},
            ),
        )
        client = XHamsterClientStrategy(profile=profile, transport=transport)
        gateway = AdapterBackedSourceGateway(
            source=ExternalSource.XHAMSTER,
            client=ClientContext(strategy=client),
            adapter=XHamsterAdapter(),
        )

        result = await gateway.search(SearchRequest(query="milf", page=1))

        self.assertEqual(result.pagination.returned_count, 1)
        force_flush_telemetry()
        spans = harness.span_exporter.get_finished_spans()
        span_by_name = {span.name: span for span in spans}

        self.assertIn("gateway.search", span_by_name)
        self.assertIn("client_context.search", span_by_name)
        self.assertIn("client.search", span_by_name)
        self.assertIn("adapter.search", span_by_name)
        self.assertEqual({span.context.trace_id for span in spans}, {span_by_name["gateway.search"].context.trace_id})
        self.assertEqual(
            span_by_name["client_context.search"].parent.span_id,
            span_by_name["gateway.search"].context.span_id,
        )
        self.assertEqual(
            span_by_name["client.search"].parent.span_id,
            span_by_name["client_context.search"].context.span_id,
        )
        self.assertEqual(
            span_by_name["adapter.search"].parent.span_id,
            span_by_name["gateway.search"].context.span_id,
        )

        metric_names = _collect_metric_names(harness.metric_reader.get_metrics_data())
        self.assertIn("porcli.gateway.operations", metric_names)
        self.assertIn("porcli.client_context.dispatches", metric_names)
        self.assertIn("porcli.client.operations", metric_names)
        self.assertIn("porcli.adapter.operations", metric_names)

    async def test_logging_includes_trace_context_when_span_is_active(self) -> None:
        configure_in_memory_telemetry(
            TelemetryConfiguration(
                service_name="porcli-tests",
                trace_exporter="none",
                metric_exporter="none",
            )
        )
        stream = io.StringIO()
        configure_logging(
            LoggingConfiguration(level="INFO", renderer="json"),
            stream=stream,
        )

        tracer = get_tracer("porcli.test")
        with tracer.start_as_current_span("test.span") as span:
            get_logger("porcli.test").info("telemetry.log_probe")

        payload = json.loads(stream.getvalue().strip())
        context = span.get_span_context()
        self.assertEqual(payload["trace_id"], f"{context.trace_id:032x}")
        self.assertEqual(payload["span_id"], f"{context.span_id:016x}")
        self.assertIn("trace_sampled", payload)


def _collect_metric_names(metrics_data: object) -> set[str]:
    names: set[str] = set()
    resource_metrics = getattr(metrics_data, "resource_metrics", [])
    for resource_metric in resource_metrics:
        for scope_metric in getattr(resource_metric, "scope_metrics", []):
            for metric in getattr(scope_metric, "metrics", []):
                names.add(metric.name)
    return names


if __name__ == "__main__":
    unittest.main()
