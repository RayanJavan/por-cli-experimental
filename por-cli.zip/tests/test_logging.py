from __future__ import annotations

import io
import json
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from porcli.logging import LoggingConfiguration, bind_context, bound_context, clear_context, configure_logging, get_logger


class LoggingTests(unittest.TestCase):
    def tearDown(self) -> None:
        clear_context()

    def test_structlog_configuration_renders_bound_context_as_json(self) -> None:
        stream = io.StringIO()
        configure_logging(
            LoggingConfiguration(level="DEBUG", renderer="json"),
            stream=stream,
        )

        bind_context(request_id="req-42", source="xhamster")
        get_logger("porcli.test").bind(component="unit").info("logging.smoke", action="write")

        payload = json.loads(stream.getvalue().strip())
        self.assertEqual(payload["event"], "logging.smoke")
        self.assertEqual(payload["request_id"], "req-42")
        self.assertEqual(payload["source"], "xhamster")
        self.assertEqual(payload["component"], "unit")
        self.assertEqual(payload["action"], "write")
        self.assertEqual(payload["level"], "info")
        self.assertEqual(payload["logger"], "porcli.test")

    def test_bound_context_is_scoped_to_context_manager(self) -> None:
        stream = io.StringIO()
        configure_logging(
            LoggingConfiguration(level="INFO", renderer="json"),
            stream=stream,
        )

        logger = get_logger("porcli.test")
        with bound_context(correlation_id="corr-7"):
            logger.info("logging.with_context")
        logger.info("logging.without_context")

        lines = [json.loads(line) for line in stream.getvalue().splitlines() if line.strip()]
        self.assertEqual(lines[0]["correlation_id"], "corr-7")
        self.assertNotIn("correlation_id", lines[1])


if __name__ == "__main__":
    unittest.main()
