from __future__ import annotations

import sys
import unittest
from pathlib import Path

from pydantic import ValidationError

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from porcli.models.canonical import CanonicalCapabilities, CanonicalVideoReference
from porcli.models.enums import ExternalSource
from porcli.models.raw import TransportRequest, TransportResponse


class SchemaModelTests(unittest.TestCase):
    def test_transport_response_accepts_nested_structured_json(self) -> None:
        response = TransportResponse(
            request=TransportRequest(url="https://example.test/search"),
            status_code=200,
            json_payload={
                "data": [
                    {
                        "id": "abc",
                        "flags": [True, None],
                        "nested": {"rank": 1, "label": "ok"},
                    }
                ]
            },
        )

        self.assertEqual(response.json_payload["data"][0]["nested"]["rank"], 1)

    def test_transport_response_rejects_scalar_json_payload(self) -> None:
        with self.assertRaises(ValidationError):
            TransportResponse(
                request=TransportRequest(url="https://example.test/search"),
                status_code=200,
                json_payload="not-structured",
            )

    def test_canonical_metadata_accepts_recursive_json_values(self) -> None:
        reference = CanonicalVideoReference(
            source=ExternalSource.XHAMSTER,
            external_id="xh-1",
            title="example",
            capabilities=CanonicalCapabilities(has_page_url=True),
            source_metadata={
                "metrics": {"views": 123, "rating": 91.4},
                "flags": [True, None, "sample"],
            },
        )

        self.assertEqual(reference.source_metadata["metrics"]["views"], 123)
        self.assertEqual(reference.source_metadata["flags"][2], "sample")


if __name__ == "__main__":
    unittest.main()
