# Service Layer Architecture

The service layer depends only on canonical source gateways and canonical
adapter outputs. Logging stays cross-cutting and flows through `porcli.logging`
without changing the service boundary itself. Telemetry stays cross-cutting and
flows through `porcli.telemetry` the same way.

## Canonical Adapter Outputs

The adapter layer now emits:

- `CanonicalVideoReference`
- `CanonicalSearchPage`
- `CanonicalVideoDetail`
- `CanonicalAsset`
- `CanonicalPagination`
- `CanonicalCapabilities`

These are intentionally high-level:

- they identify a source and external ID
- they expose normalized URLs and asset inventories
- they expose pagination state without assuming source-specific paging rules
- they expose capability signals without forcing service logic to inspect raw
  source fields
- they are Pydantic schemas with strict validation for inter-layer flow

## Service Boundary

The service layer does not consume:

- raw HTTP responses
- raw source DTOs
- client configuration details
- source-specific normalization rules

The service layer consumes `SourceGateway`.

## `SourceGateway`

`SourceGateway` is the service-facing port for one source.

Operations:

- `search(SearchRequest) -> CanonicalSearchPage`
- `get_video(VideoLookupRequest) -> CanonicalVideoDetail`
- `get_random(RandomRequest | None) -> CanonicalVideoDetail`

The default implementation is `AdapterBackedSourceGateway`, which composes:

- Client strategy
- Adapter

This means the service layer stays generic while the source-specific behavior
remains below the boundary.

## Initial Service

`CatalogService` is the initial service-layer implementation.

Responsibilities:

- manage a collection of canonical source gateways
- search one source or many sources
- fetch a video by source and external ID
- fetch a video from a canonical reference
- fetch a random video per source

Convenience models:

- `SourceVideoSelector`
- `MultiSourceSearchResult`

This is intentionally small and extendable. It is enough to pin down how later
service workflows interact with source integrations without locking the project
into premature domain-specific orchestration.
