# Client / Adapter Architecture

This scaffold treats the project as a direct-source integration system.

## Client Layer

Pattern: Strategy

- `ClientContext` is the strategy context.
- Each concrete source client is a strategy.
- `Transport` is separate from the source strategy so request execution can be
  tested and swapped independently.
- `SourceClientProfile` keeps endpoint details configurable instead of hardcoded
  where the direct-source contract is not pinned down yet.

Responsibilities:

- communicate with the external source
- build and execute requests
- return raw transport responses
- avoid canonical formatting and service logic

## Adapter Layer

Pattern: Adapter

- `SourceAdapter` defines the canonical adapter contract.
- Each concrete source adapter adapts source-dependent raw data into canonical
  DTOs.
- Source-specific raw DTO outlines are intentionally separate from canonical
  DTOs.

Responsibilities:

- parse raw client payloads
- normalize source-specific identifiers
- map source fields into canonical models
- keep source-specific transformation logic isolated

## Shared Models

- transport envelopes live in `porcli.models.raw`
- canonical outputs live in `porcli.models.canonical`
- request DTOs live in `porcli.models.requests`
- shared schema bases and typed JSON/metadata aliases live in `porcli.models.schema`
- shared structlog configuration and context helpers live in `porcli.logging`
- shared OpenTelemetry tracing/metrics helpers live in `porcli.telemetry`
- enums live in `porcli.models.enums`

## Current Limits

- direct-source endpoint details are configurable, not fully pinned down
- HTML/document parsing is intentionally left abstract where source details are
  still unknown
- service layer is now defined separately in `docs/service-layer-architecture.md`
