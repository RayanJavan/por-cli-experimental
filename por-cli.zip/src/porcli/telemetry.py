"""Shared OpenTelemetry configuration and helpers."""

from __future__ import annotations

from collections.abc import Iterator, Mapping, Sequence
from contextlib import contextmanager, suppress
from dataclasses import dataclass
from time import perf_counter
from typing import Literal

from opentelemetry import metrics, trace
from opentelemetry.metrics import Meter
from opentelemetry.sdk.metrics import MeterProvider
from opentelemetry.sdk.metrics.export import ConsoleMetricExporter, InMemoryMetricReader, MetricReader
from opentelemetry.sdk.metrics.export import PeriodicExportingMetricReader
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import (
    BatchSpanProcessor,
    ConsoleSpanExporter,
    SimpleSpanProcessor,
    SpanExporter,
)
from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter
from opentelemetry.trace import Span, SpanKind, Status, StatusCode, Tracer
from opentelemetry.util.types import AttributeValue
from pydantic import Field

from porcli.models.schema import NonEmptyString, OptionalNormalizedString, StrictSchemaModel

TraceExporterKind = Literal["console", "none"]
MetricExporterKind = Literal["console", "none"]
SpanProcessorKind = Literal["simple", "batch"]
ScalarAttribute = str | bool | int | float


class TelemetryConfiguration(StrictSchemaModel):
    """Application telemetry configuration for OpenTelemetry tracing and metrics."""

    service_name: NonEmptyString = "porcli"
    service_version: OptionalNormalizedString | None = None
    deployment_environment: OptionalNormalizedString | None = None
    service_namespace: OptionalNormalizedString | None = None
    traces_enabled: bool = True
    metrics_enabled: bool = True
    trace_exporter: TraceExporterKind = "console"
    metric_exporter: MetricExporterKind = "console"
    span_processor: SpanProcessorKind = "simple"
    metric_export_interval_millis: int = Field(default=60000, ge=1000)


@dataclass(slots=True)
class TelemetryRuntime:
    """Configured OpenTelemetry runtime for the package."""

    config: TelemetryConfiguration
    tracer_provider: TracerProvider | None = None
    meter_provider: MeterProvider | None = None
    span_exporter: SpanExporter | None = None
    metric_reader: MetricReader | None = None
    configured: bool = False

    def get_tracer(self, name: str | None = None) -> Tracer:
        if self.tracer_provider is not None:
            return self.tracer_provider.get_tracer(name or __name__)
        return trace.get_tracer(name or __name__)

    def get_meter(self, name: str | None = None) -> Meter:
        if self.meter_provider is not None:
            return self.meter_provider.get_meter(name or __name__)
        return metrics.get_meter(name or __name__)


@dataclass(slots=True)
class InMemoryTelemetryHarness:
    """Testing-oriented telemetry harness with in-memory exporters."""

    runtime: TelemetryRuntime
    span_exporter: InMemorySpanExporter
    metric_reader: InMemoryMetricReader


_DEFAULT_CONFIG = TelemetryConfiguration(
    service_name="porcli",
    traces_enabled=False,
    metrics_enabled=False,
    trace_exporter="none",
    metric_exporter="none",
)
_RUNTIME = TelemetryRuntime(config=_DEFAULT_CONFIG, configured=False)


def configure_telemetry(
    config: TelemetryConfiguration | None = None,
    *,
    span_exporter: SpanExporter | None = None,
    metric_reader: MetricReader | None = None,
    force: bool = True,
) -> TelemetryRuntime:
    """Configure package-local OpenTelemetry providers.

    This module intentionally manages its own providers instead of replacing the
    process-global providers. That keeps test isolation simple and allows
    repeated offline reconfiguration in one Python process.
    """

    global _RUNTIME

    if force:
        shutdown_telemetry()
    elif _RUNTIME.configured:
        return _RUNTIME

    resolved = config or TelemetryConfiguration()
    resource = _build_resource(resolved)

    tracer_provider: TracerProvider | None = None
    resolved_span_exporter = span_exporter
    if resolved.traces_enabled:
        tracer_provider = TracerProvider(resource=resource)
        resolved_span_exporter = resolved_span_exporter or _build_span_exporter(resolved)
        if resolved_span_exporter is not None:
            span_processor = _build_span_processor(resolved, resolved_span_exporter)
            tracer_provider.add_span_processor(span_processor)

    meter_provider: MeterProvider | None = None
    resolved_metric_reader = metric_reader
    if resolved.metrics_enabled:
        resolved_metric_reader = resolved_metric_reader or _build_metric_reader(resolved)
        metric_readers = []
        if resolved_metric_reader is not None:
            metric_readers.append(resolved_metric_reader)
        meter_provider = MeterProvider(resource=resource, metric_readers=metric_readers)

    _RUNTIME = TelemetryRuntime(
        config=resolved,
        tracer_provider=tracer_provider,
        meter_provider=meter_provider,
        span_exporter=resolved_span_exporter,
        metric_reader=resolved_metric_reader,
        configured=True,
    )
    return _RUNTIME


def configure_in_memory_telemetry(
    config: TelemetryConfiguration | None = None,
    *,
    force: bool = True,
) -> InMemoryTelemetryHarness:
    """Configure telemetry with in-memory exporters for tests and probes."""

    resolved = config or TelemetryConfiguration(
        service_name="porcli-tests",
        trace_exporter="none",
        metric_exporter="none",
    )
    span_exporter = InMemorySpanExporter()
    metric_reader = InMemoryMetricReader()
    runtime = configure_telemetry(
        resolved,
        span_exporter=span_exporter,
        metric_reader=metric_reader,
        force=force,
    )
    return InMemoryTelemetryHarness(
        runtime=runtime,
        span_exporter=span_exporter,
        metric_reader=metric_reader,
    )


def shutdown_telemetry() -> None:
    """Shutdown active telemetry providers and restore no-op defaults."""

    global _RUNTIME

    if _RUNTIME.meter_provider is not None:
        with suppress(Exception):
            _RUNTIME.meter_provider.shutdown()
    if _RUNTIME.tracer_provider is not None:
        with suppress(Exception):
            _RUNTIME.tracer_provider.shutdown()

    _RUNTIME = TelemetryRuntime(config=_DEFAULT_CONFIG, configured=False)


def force_flush_telemetry() -> None:
    """Flush active telemetry providers when supported."""

    if _RUNTIME.meter_provider is not None:
        with suppress(Exception):
            _RUNTIME.meter_provider.force_flush()
    if _RUNTIME.tracer_provider is not None:
        with suppress(Exception):
            _RUNTIME.tracer_provider.force_flush()


def get_tracer(name: str | None = None) -> Tracer:
    """Return a tracer from the active telemetry runtime."""

    return _RUNTIME.get_tracer(name)


def get_meter(name: str | None = None) -> Meter:
    """Return a meter from the active telemetry runtime."""

    return _RUNTIME.get_meter(name)


def get_current_trace_context() -> dict[str, str | bool]:
    """Return the active trace/span IDs for log correlation when available."""

    span = trace.get_current_span()
    span_context = span.get_span_context()
    if not span_context.is_valid:
        return {}
    return {
        "trace_id": f"{span_context.trace_id:032x}",
        "span_id": f"{span_context.span_id:016x}",
        "trace_sampled": span_context.trace_flags.sampled,
    }


def normalize_attributes(
    attributes: Mapping[str, object] | None = None,
    /,
    **extra: object,
) -> dict[str, AttributeValue]:
    """Filter values into OpenTelemetry-compatible attributes."""

    merged: dict[str, object] = {}
    if attributes:
        merged.update(attributes)
    merged.update(extra)

    normalized: dict[str, AttributeValue] = {}
    for key, value in merged.items():
        if value is None:
            continue
        if isinstance(value, (str, bool, int, float)):
            normalized[key] = value
            continue
        if isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
            items = list(value)
            if not items:
                normalized[key] = tuple()
                continue
            if all(isinstance(item, (str, bool, int, float)) for item in items):
                normalized[key] = tuple(items)
    return normalized


def set_span_attributes(
    span: Span,
    attributes: Mapping[str, object] | None = None,
    /,
    **extra: object,
) -> None:
    """Set normalized attributes on a span."""

    for key, value in normalize_attributes(attributes, **extra).items():
        span.set_attribute(key, value)


def add_counter(
    counter: object | None,
    amount: int | float = 1,
    attributes: Mapping[str, object] | None = None,
    /,
    **extra: object,
) -> None:
    """Increment a metric counter when available."""

    if counter is None:
        return
    counter.add(amount, normalize_attributes(attributes, **extra))


def record_histogram(
    histogram: object | None,
    value: int | float,
    attributes: Mapping[str, object] | None = None,
    /,
    **extra: object,
) -> None:
    """Record a histogram value when available."""

    if histogram is None:
        return
    histogram.record(value, normalize_attributes(attributes, **extra))


@contextmanager
def observe_operation(
    tracer: Tracer,
    *,
    name: str,
    counter: object | None = None,
    duration_histogram: object | None = None,
    metric_attributes: Mapping[str, object] | None = None,
    span_attributes: Mapping[str, object] | None = None,
    kind: SpanKind = SpanKind.INTERNAL,
) -> Iterator[Span]:
    """Start a span and record standard operation metrics around one block."""

    add_counter(counter, attributes=metric_attributes)
    start = perf_counter()
    with tracer.start_as_current_span(
        name,
        kind=kind,
        attributes=normalize_attributes(span_attributes),
    ) as span:
        try:
            yield span
        except Exception as exc:
            span.record_exception(exc)
            span.set_status(Status(StatusCode.ERROR, str(exc)))
            record_histogram(
                duration_histogram,
                perf_counter() - start,
                metric_attributes,
                **{"porcli.status": "error"},
            )
            raise
        record_histogram(
            duration_histogram,
            perf_counter() - start,
            metric_attributes,
            **{"porcli.status": "ok"},
        )


def _build_resource(config: TelemetryConfiguration) -> Resource:
    resource_attributes = normalize_attributes(
        {
            "service.name": config.service_name,
            "service.version": config.service_version,
            "deployment.environment": config.deployment_environment,
            "service.namespace": config.service_namespace,
        }
    )
    return Resource.create(resource_attributes)


def _build_span_exporter(config: TelemetryConfiguration) -> SpanExporter | None:
    if config.trace_exporter == "console":
        return ConsoleSpanExporter()
    return None


def _build_metric_reader(config: TelemetryConfiguration) -> MetricReader | None:
    if config.metric_exporter == "console":
        return PeriodicExportingMetricReader(
            ConsoleMetricExporter(),
            export_interval_millis=config.metric_export_interval_millis,
        )
    return None


def _build_span_processor(
    config: TelemetryConfiguration,
    exporter: SpanExporter,
):
    if config.span_processor == "batch":
        return BatchSpanProcessor(exporter)
    return SimpleSpanProcessor(exporter)
