"""Shared structured logging configuration and helpers."""

from __future__ import annotations

import logging as std_logging
import sys
from contextlib import contextmanager
from typing import Literal, TextIO

import structlog
from pydantic import field_validator
from structlog.stdlib import BoundLogger

from porcli.models.schema import StrictSchemaModel
from porcli.telemetry import get_current_trace_context

LogRenderer = Literal["console", "json"]
_PACKAGE_LOGGER_NAME = "porcli"
_LIBRARY_DEFAULTS_CONFIGURED = False


class LoggingConfiguration(StrictSchemaModel):
    """Application logging configuration for structlog + stdlib logging."""

    level: str = "INFO"
    renderer: LogRenderer = "console"
    include_timestamp: bool = True
    include_logger_name: bool = True
    include_stack_info: bool = False
    utc_timestamps: bool = False
    cache_loggers: bool = True
    root_logger_name: str = ""
    event_key: str = "event"
    passthrough_stdlib_logs: bool = True
    include_trace_context: bool = True

    @field_validator("level")
    @classmethod
    def validate_level(cls, value: str) -> str:
        normalized = value.strip().upper()
        if normalized not in std_logging.getLevelNamesMapping():
            raise ValueError(f"Unsupported logging level: {value}")
        return normalized


def configure_logging(
    config: LoggingConfiguration | None = None,
    *,
    stream: TextIO | None = None,
    force: bool = True,
) -> None:
    """Configure structlog for the application.

    The package does not configure logging on import. Applications should call
    this explicitly at startup so all layers share one predictable renderer and
    one context propagation setup.
    """

    resolved = config or LoggingConfiguration()
    shared_processors = _build_shared_processors(resolved)
    renderer = _build_renderer(resolved)

    structlog.reset_defaults()
    structlog.configure(
        processors=[
            *shared_processors,
            structlog.stdlib.ProcessorFormatter.wrap_for_formatter,
        ],
        wrapper_class=BoundLogger,
        logger_factory=structlog.stdlib.LoggerFactory(),
        cache_logger_on_first_use=resolved.cache_loggers,
    )

    formatter = structlog.stdlib.ProcessorFormatter(
        foreign_pre_chain=shared_processors if resolved.passthrough_stdlib_logs else [],
        processors=[
            structlog.stdlib.ProcessorFormatter.remove_processors_meta,
            renderer,
        ],
    )

    handler = std_logging.StreamHandler(stream or sys.stderr)
    handler.setFormatter(formatter)

    root_logger = std_logging.getLogger(resolved.root_logger_name)
    if force:
        root_logger.handlers.clear()
    root_logger.addHandler(handler)
    root_logger.setLevel(_resolve_stdlib_level(resolved.level))

    global _LIBRARY_DEFAULTS_CONFIGURED
    _LIBRARY_DEFAULTS_CONFIGURED = True


def get_logger(name: str | None = None, **bindings: object) -> BoundLogger:
    """Return a structlog logger with optional pre-bound context."""

    _ensure_library_defaults()
    logger = structlog.stdlib.get_logger(name)
    if bindings:
        return logger.bind(**bindings)
    return logger


def bind_context(**values: object) -> None:
    """Bind contextvars that will flow through subsequent log events."""

    if values:
        structlog.contextvars.bind_contextvars(**values)


def unbind_context(*keys: str) -> None:
    """Remove selected context keys from the active logging context."""

    if keys:
        structlog.contextvars.unbind_contextvars(*keys)


def clear_context() -> None:
    """Clear all active structlog contextvars."""

    structlog.contextvars.clear_contextvars()


@contextmanager
def bound_context(**values: object):
    """Temporarily bind contextvars for one logical operation scope."""

    with structlog.contextvars.bound_contextvars(**values):
        yield


def _build_shared_processors(config: LoggingConfiguration) -> list[structlog.types.Processor]:
    processors: list[structlog.types.Processor] = [
        structlog.contextvars.merge_contextvars,
    ]

    if config.include_trace_context:
        processors.append(_add_trace_context)

    if config.include_logger_name:
        processors.append(structlog.stdlib.add_logger_name)

    processors.extend(
        [
            structlog.stdlib.add_log_level,
            structlog.stdlib.PositionalArgumentsFormatter(),
        ]
    )

    if config.include_timestamp:
        processors.append(structlog.processors.TimeStamper(fmt="iso", utc=config.utc_timestamps))

    if config.include_stack_info:
        processors.append(structlog.processors.StackInfoRenderer())

    if config.event_key != "event":
        processors.append(structlog.processors.EventRenamer(config.event_key))

    processors.extend(
        [
            structlog.processors.format_exc_info,
        ]
    )
    return processors


def _build_renderer(config: LoggingConfiguration) -> structlog.types.Processor:
    if config.renderer == "json":
        return structlog.processors.JSONRenderer(sort_keys=True)

    return structlog.dev.ConsoleRenderer(colors=False, event_key=config.event_key)


def _resolve_stdlib_level(level_name: str) -> int:
    return std_logging.getLevelNamesMapping()[level_name]


def _ensure_library_defaults() -> None:
    """Install quiet library defaults until the application configures logging."""

    global _LIBRARY_DEFAULTS_CONFIGURED
    if _LIBRARY_DEFAULTS_CONFIGURED:
        return

    structlog.configure(
        processors=[
            structlog.contextvars.merge_contextvars,
            _add_trace_context,
            structlog.stdlib.add_logger_name,
            structlog.stdlib.add_log_level,
            structlog.processors.format_exc_info,
            structlog.stdlib.render_to_log_kwargs,
        ],
        wrapper_class=BoundLogger,
        logger_factory=structlog.stdlib.LoggerFactory(),
        cache_logger_on_first_use=True,
    )
    std_logging.getLogger(_PACKAGE_LOGGER_NAME).addHandler(std_logging.NullHandler())
    _LIBRARY_DEFAULTS_CONFIGURED = True


def _add_trace_context(
    _: object,
    __: str,
    event_dict: dict[str, object],
) -> dict[str, object]:
    event_dict.update(get_current_trace_context())
    return event_dict
