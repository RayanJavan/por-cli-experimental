"""Configurable field probe suite for the client layer."""

from __future__ import annotations

import argparse
import asyncio
import json
import platform
import re
import sys
import traceback
from collections.abc import Callable, Mapping, Sequence
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, unquote, urlparse

from pydantic import AnyHttpUrl, Field, PositiveFloat

from porcli.clients.base import BaseSourceClientStrategy
from porcli.clients.contracts import Transport
from porcli.clients.http import HTTPXTransport
from porcli.clients.eporner import EpornerClientStrategy
from porcli.clients.xhamster import XHamsterClientStrategy
from porcli.config import OperationTemplate, SourceClientProfile
from porcli.logging import LoggingConfiguration, bind_context, clear_context, configure_logging, get_logger
from porcli.models.enums import ClientOperation, ExternalSource
from porcli.models.raw import RawClientResponse
from porcli.models.requests import RandomRequest, SearchRequest, VideoLookupRequest
from porcli.models.schema import NonEmptyString, StrictSchemaModel, StructuredJson
from porcli.telemetry import (
    TelemetryConfiguration,
    configure_in_memory_telemetry,
    force_flush_telemetry,
    shutdown_telemetry,
)

TransportFactory = Callable[[], Transport]


class ClientFieldProbeCandidate(StrictSchemaModel):
    """One heuristic or explicit operation-template probe case."""

    name: NonEmptyString
    template: OperationTemplate
    enabled: bool = True
    notes: str | None = None


class SearchFieldProbeConfig(StrictSchemaModel):
    """Search probe configuration for one source."""

    enabled: bool = True
    queries: list[NonEmptyString] = Field(default_factory=lambda: ["milf"])
    pages: list[int] = Field(default_factory=lambda: [1])
    candidates: list[ClientFieldProbeCandidate] = Field(default_factory=list)
    max_discovered_external_ids: int = Field(default=3, ge=0)


class VideoFieldProbeConfig(StrictSchemaModel):
    """Video-detail probe configuration for one source."""

    enabled: bool = True
    external_ids: list[NonEmptyString] = Field(default_factory=list)
    use_discovered_external_ids: bool = True
    max_discovered_external_ids: int = Field(default=3, ge=0)
    candidates: list[ClientFieldProbeCandidate] = Field(default_factory=list)


class RandomFieldProbeConfig(StrictSchemaModel):
    """Random-operation probe configuration for one source."""

    enabled: bool = False
    filters: list[dict[str, str]] = Field(default_factory=lambda: [{}])
    candidates: list[ClientFieldProbeCandidate] = Field(default_factory=list)


class ClientFieldSourceConfig(StrictSchemaModel):
    """Field-probe configuration for one source client."""

    source: ExternalSource
    base_url: AnyHttpUrl
    timeout_seconds: PositiveFloat = 20.0
    default_headers: dict[str, str] = Field(default_factory=dict)
    search: SearchFieldProbeConfig | None = None
    video: VideoFieldProbeConfig | None = None
    random: RandomFieldProbeConfig | None = None


class ClientFieldSuiteConfig(StrictSchemaModel):
    """Top-level client-layer field probe configuration."""

    sources: list[ClientFieldSourceConfig]


class ClientFieldProbeResult(StrictSchemaModel):
    """Recorded result for one field-probe case invocation."""

    source: ExternalSource
    operation: ClientOperation
    case_name: NonEmptyString
    request_descriptor: NonEmptyString
    success: bool
    status_code: int | None = None
    has_json_payload: bool | None = None
    content_type: str | None = None
    extracted_external_ids: list[str] = Field(default_factory=list)
    output_directory: NonEmptyString
    error_type: str | None = None
    error_message: str | None = None


class ClientFieldProbeReport(StrictSchemaModel):
    """Top-level report for a full client field-suite run."""

    started_at: NonEmptyString
    completed_at: NonEmptyString
    output_directory: NonEmptyString
    config_path: str | None = None
    source_count: int
    case_count: int
    failed_case_count: int
    results: list[ClientFieldProbeResult] = Field(default_factory=list)


class ClientFieldSuiteRunner:
    """Runs a configurable field suite directly against client strategies."""

    def __init__(
        self,
        config: ClientFieldSuiteConfig,
        *,
        output_directory: Path,
        config_path: Path | None = None,
        log_level: str = "DEBUG",
        fail_on_case_error: bool = False,
        transport_factory: TransportFactory | None = None,
    ) -> None:
        self.config = config
        self.output_directory = output_directory
        self.config_path = config_path
        self.log_level = log_level
        self.fail_on_case_error = fail_on_case_error
        self.transport_factory = transport_factory or HTTPXTransport
        self.logger = get_logger(__name__).bind(layer="probe", component=type(self).__name__)
        self._log_stream = None
        self._results: list[ClientFieldProbeResult] = []
        self._discovered_external_ids: dict[ExternalSource, list[str]] = {
            source.source: [] for source in config.sources
        }

    async def run(self) -> ClientFieldProbeReport:
        started_at = _timestamp()
        self._prepare_output_layout()
        self._configure_logging()
        harness = configure_in_memory_telemetry(
            TelemetryConfiguration(
                service_name="porcli-client-field-probe",
                trace_exporter="none",
                metric_exporter="none",
            )
        )
        bind_context(probe_run_started_at=started_at, probe_output_dir=str(self.output_directory))
        self.logger.info("probe.run.start", source_count=len(self.config.sources))

        try:
            self._write_environment_snapshot()
            self._write_resolved_config()

            for source_config in self.config.sources:
                await self._run_source(source_config)

            force_flush_telemetry()
            self._write_telemetry_artifacts(harness)
        finally:
            clear_context()
            shutdown_telemetry()
            if self._log_stream is not None:
                self._log_stream.flush()
            if sys.exc_info()[1] is not None:
                self._release_log_stream()

        completed_at = _timestamp()
        report = ClientFieldProbeReport(
            started_at=started_at,
            completed_at=completed_at,
            output_directory=str(self.output_directory),
            config_path=str(self.config_path) if self.config_path is not None else None,
            source_count=len(self.config.sources),
            case_count=len(self._results),
            failed_case_count=sum(1 for result in self._results if not result.success),
            results=self._results,
        )
        self._write_report(report)
        self.logger.info(
            "probe.run.complete",
            case_count=report.case_count,
            failed_case_count=report.failed_case_count,
        )
        self._release_log_stream()
        return report

    async def _run_source(self, source_config: ClientFieldSourceConfig) -> None:
        source_logger = self.logger.bind(source=source_config.source.value)
        bind_context(source=source_config.source.value)
        transport = self.transport_factory()
        source_logger.info("probe.source.start")
        try:
            if source_config.search is not None and source_config.search.enabled:
                await self._run_search_probes(source_config, transport)
            if source_config.video is not None and source_config.video.enabled:
                await self._run_video_probes(source_config, transport)
            if source_config.random is not None and source_config.random.enabled:
                await self._run_random_probes(source_config, transport)
            self._write_discovered_ids(source_config.source)
        finally:
            await self._maybe_aclose(transport)
            source_logger.info("probe.source.complete")
            clear_context()

    async def _run_search_probes(self, source_config: ClientFieldSourceConfig, transport: Transport) -> None:
        assert source_config.search is not None
        for candidate in source_config.search.candidates:
            if not candidate.enabled:
                continue
            for query in source_config.search.queries:
                for page in source_config.search.pages:
                    request = SearchRequest(query=query, page=page)
                    descriptor = f"query-{_slugify(query)}__page-{page}"
                    result = await self._execute_probe_case(
                        source_config=source_config,
                        operation=ClientOperation.SEARCH,
                        candidate=candidate,
                        request=request,
                        request_descriptor=descriptor,
                        transport=transport,
                    )
                    self._results.append(result)
                    if result.extracted_external_ids:
                        self._extend_discovered_ids(
                            source=source_config.source,
                            values=result.extracted_external_ids,
                            limit=source_config.search.max_discovered_external_ids,
                        )

    async def _run_video_probes(self, source_config: ClientFieldSourceConfig, transport: Transport) -> None:
        assert source_config.video is not None
        external_ids = list(source_config.video.external_ids)
        if source_config.video.use_discovered_external_ids:
            discovered_ids = self._discovered_external_ids.get(source_config.source, [])
            if source_config.video.max_discovered_external_ids > 0:
                discovered_ids = discovered_ids[: source_config.video.max_discovered_external_ids]
            else:
                discovered_ids = []
            external_ids.extend(discovered_ids)
        external_ids = _dedupe_strings(external_ids)
        if not external_ids:
            self.logger.warning("probe.video.skipped_no_external_ids", source=source_config.source.value)
            return

        for candidate in source_config.video.candidates:
            if not candidate.enabled:
                continue
            for external_id in external_ids:
                request = VideoLookupRequest(external_id=external_id)
                descriptor = f"external-id-{_slugify(external_id)}"
                result = await self._execute_probe_case(
                    source_config=source_config,
                    operation=ClientOperation.VIDEO,
                    candidate=candidate,
                    request=request,
                    request_descriptor=descriptor,
                    transport=transport,
                )
                self._results.append(result)

    async def _run_random_probes(self, source_config: ClientFieldSourceConfig, transport: Transport) -> None:
        assert source_config.random is not None
        for candidate in source_config.random.candidates:
            if not candidate.enabled:
                continue
            for index, filters in enumerate(source_config.random.filters, start=1):
                request = RandomRequest(filters=filters)
                descriptor = f"filters-{index}"
                result = await self._execute_probe_case(
                    source_config=source_config,
                    operation=ClientOperation.RANDOM,
                    candidate=candidate,
                    request=request,
                    request_descriptor=descriptor,
                    transport=transport,
                )
                self._results.append(result)

    async def _execute_probe_case(
        self,
        *,
        source_config: ClientFieldSourceConfig,
        operation: ClientOperation,
        candidate: ClientFieldProbeCandidate,
        request: SearchRequest | VideoLookupRequest | RandomRequest,
        request_descriptor: str,
        transport: Transport,
    ) -> ClientFieldProbeResult:
        case_output_directory = (
            self.output_directory
            / "artifacts"
            / source_config.source.value
            / operation.value
            / _slugify(candidate.name)
            / request_descriptor
        )
        case_output_directory.mkdir(parents=True, exist_ok=True)
        case_logger = self.logger.bind(
            source=source_config.source.value,
            operation=operation.value,
            case_name=candidate.name,
            request_descriptor=request_descriptor,
        )
        bind_context(
            operation=operation.value,
            case_name=candidate.name,
            request_descriptor=request_descriptor,
        )

        profile = _build_probe_profile(source_config, operation, candidate.template)
        client = _build_strategy(source_config.source, profile, transport)
        self._write_json(case_output_directory / "candidate-template.json", candidate.model_dump(mode="json"))
        self._write_json(case_output_directory / "request-dto.json", request.model_dump(mode="json"))

        try:
            case_logger.info("probe.case.start")
            response = await _invoke_client_operation(client, operation, request)
            extracted_external_ids = _extract_external_ids_from_payload(
                source_config.source,
                response.transport.json_payload,
                max_count=_max_discovered_id_count(source_config, operation),
            )
            summary = _build_response_summary(response)
            summary["extracted_external_ids"] = extracted_external_ids
            self._write_raw_response_artifacts(case_output_directory, response, summary)

            success = 200 <= response.transport.status_code < 400
            case_logger.info(
                "probe.case.complete",
                success=success,
                status_code=response.transport.status_code,
                has_json_payload=response.transport.json_payload is not None,
                extracted_external_id_count=len(extracted_external_ids),
            )
            return ClientFieldProbeResult(
                source=source_config.source,
                operation=operation,
                case_name=candidate.name,
                request_descriptor=request_descriptor,
                success=success,
                status_code=response.transport.status_code,
                has_json_payload=response.transport.json_payload is not None,
                content_type=response.transport.headers.get("content-type"),
                extracted_external_ids=extracted_external_ids,
                output_directory=str(case_output_directory),
            )
        except Exception as exc:
            case_logger.exception("probe.case.failed")
            error_summary = {
                "error_type": type(exc).__name__,
                "error_message": str(exc),
                "traceback": traceback.format_exc(),
            }
            self._write_json(case_output_directory / "error.json", error_summary)
            result = ClientFieldProbeResult(
                source=source_config.source,
                operation=operation,
                case_name=candidate.name,
                request_descriptor=request_descriptor,
                success=False,
                output_directory=str(case_output_directory),
                error_type=type(exc).__name__,
                error_message=str(exc),
            )
            if self.fail_on_case_error:
                raise
            return result
        finally:
            clear_context()

    def _prepare_output_layout(self) -> None:
        for relative_path in ("artifacts", "logs", "telemetry"):
            (self.output_directory / relative_path).mkdir(parents=True, exist_ok=True)

    def _configure_logging(self) -> None:
        log_path = self.output_directory / "logs" / "suite.log.jsonl"
        self._log_stream = log_path.open("a", encoding="utf-8")
        configure_logging(
            LoggingConfiguration(level=self.log_level, renderer="json"),
            stream=self._log_stream,
        )

    def _write_environment_snapshot(self) -> None:
        snapshot = {
            "python": sys.version,
            "platform": platform.platform(),
            "executable": sys.executable,
            "argv": sys.argv,
            "timestamp": _timestamp(),
        }
        self._write_json(self.output_directory / "environment.json", snapshot)

    def _write_resolved_config(self) -> None:
        self._write_json(
            self.output_directory / "suite-config.resolved.json",
            self.config.model_dump(mode="json"),
        )

    def _write_discovered_ids(self, source: ExternalSource) -> None:
        self._write_json(
            self.output_directory / "artifacts" / source.value / "discovered-external-ids.json",
            {
                "source": source.value,
                "external_ids": self._discovered_external_ids.get(source, []),
            },
        )

    def _write_raw_response_artifacts(
        self,
        output_directory: Path,
        response: RawClientResponse,
        summary: dict[str, object],
    ) -> None:
        request = response.transport.request
        self._write_json(
            output_directory / "transport-request.json",
            request.model_dump(mode="json"),
        )
        self._write_json(output_directory / "response-summary.json", summary)
        self._write_json(output_directory / "response-headers.json", response.transport.headers)
        self._write_text(output_directory / "response-text.txt", response.transport.text)
        if response.transport.json_payload is not None:
            self._write_json(output_directory / "response-json-payload.json", response.transport.json_payload)

    def _write_telemetry_artifacts(self, harness: object) -> None:
        span_exporter = getattr(harness, "span_exporter")
        metric_reader = getattr(harness, "metric_reader")
        spans = [_serialize_span(span) for span in span_exporter.get_finished_spans()]
        metrics = _serialize_metrics(metric_reader.get_metrics_data())
        self._write_json(self.output_directory / "telemetry" / "spans.json", spans)
        self._write_json(self.output_directory / "telemetry" / "metrics.json", metrics)

    def _write_report(self, report: ClientFieldProbeReport) -> None:
        self._write_json(self.output_directory / "report.json", report.model_dump(mode="json"))
        markdown_lines = [
            "# Client Field Probe Report",
            "",
            f"- started_at: `{report.started_at}`",
            f"- completed_at: `{report.completed_at}`",
            f"- output_directory: `{report.output_directory}`",
            f"- case_count: `{report.case_count}`",
            f"- failed_case_count: `{report.failed_case_count}`",
            "",
            "## Results",
            "",
        ]
        for result in report.results:
            markdown_lines.append(
                f"- `{result.source.value}` `{result.operation.value}` `{result.case_name}` `{result.request_descriptor}` "
                f"success=`{int(result.success)}` status_code=`{result.status_code}` output=`{result.output_directory}`"
            )
            if result.error_message:
                markdown_lines.append(f"  error: `{result.error_type}` `{result.error_message}`")
        self._write_text(self.output_directory / "report.md", "\n".join(markdown_lines) + "\n")

    def _write_json(self, path: Path, payload: object) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(payload, indent=2, sort_keys=True, ensure_ascii=True) + "\n", encoding="utf-8")

    def _write_text(self, path: Path, text: str) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding="utf-8")

    def _release_log_stream(self) -> None:
        if self._log_stream is None:
            return
        log_stream = self._log_stream
        configure_logging(
            LoggingConfiguration(level="WARNING", renderer="console"),
            stream=sys.stderr,
        )
        log_stream.close()
        self._log_stream = None

    async def _maybe_aclose(self, transport: Transport) -> None:
        aclose = getattr(transport, "aclose", None)
        if callable(aclose):
            await aclose()

    def _extend_discovered_ids(self, *, source: ExternalSource, values: Sequence[str], limit: int) -> None:
        current = self._discovered_external_ids.setdefault(source, [])
        current.extend(values)
        deduped = _dedupe_strings(current)
        self._discovered_external_ids[source] = deduped[:limit] if limit > 0 else []


def build_default_client_field_suite_config() -> ClientFieldSuiteConfig:
    """Return a heuristic default field-probe configuration."""

    return ClientFieldSuiteConfig(
        sources=[
            ClientFieldSourceConfig(
                source=ExternalSource.XHAMSTER,
                base_url="https://xhamster.com",
                search=SearchFieldProbeConfig(
                    candidates=[
                        ClientFieldProbeCandidate(
                            name="search-query-params",
                            template=OperationTemplate(
                                path_template="/search",
                                query_templates={"q": "{query}", "page": "{page}"},
                            ),
                            notes="Common query-parameter style search route.",
                        ),
                        ClientFieldProbeCandidate(
                            name="search-query-path",
                            template=OperationTemplate(
                                path_template="/search/{query}",
                                query_templates={"page": "{page}"},
                            ),
                            notes="Common path-based search route with explicit page query.",
                        ),
                    ],
                ),
                video=VideoFieldProbeConfig(
                    candidates=[
                        ClientFieldProbeCandidate(
                            name="videos-path",
                            template=OperationTemplate(path_template="/videos/{external_id}"),
                            notes="Canonical page-path guess for xHamster video pages.",
                        ),
                        ClientFieldProbeCandidate(
                            name="embed-path",
                            template=OperationTemplate(path_template="/embed/{external_id}"),
                            notes="Embed-path fallback to validate external-id path compatibility.",
                        ),
                    ],
                ),
                random=RandomFieldProbeConfig(
                    enabled=False,
                    candidates=[
                        ClientFieldProbeCandidate(
                            name="random-root",
                            template=OperationTemplate(path_template="/random"),
                            notes="Heuristic random page route.",
                        )
                    ],
                ),
            ),
            ClientFieldSourceConfig(
                source=ExternalSource.EPORNER,
                base_url="https://www.eporner.com",
                search=SearchFieldProbeConfig(
                    candidates=[
                        ClientFieldProbeCandidate(
                            name="search-query-page-path",
                            template=OperationTemplate(path_template="/search/{query}/{page}"),
                            notes="Common path-based search route with page segment.",
                        ),
                        ClientFieldProbeCandidate(
                            name="search-query-path-page-query",
                            template=OperationTemplate(
                                path_template="/search/{query}",
                                query_templates={"page": "{page}"},
                            ),
                            notes="Path-based query route with explicit page query.",
                        ),
                        ClientFieldProbeCandidate(
                            name="search-query-params",
                            template=OperationTemplate(
                                path_template="/search",
                                query_templates={"q": "{query}", "page": "{page}"},
                            ),
                            notes="Query-parameter fallback if path routes are not correct.",
                        ),
                    ],
                ),
                video=VideoFieldProbeConfig(
                    candidates=[
                        ClientFieldProbeCandidate(
                            name="video-prefix-path",
                            template=OperationTemplate(path_template="/video-{external_id}/"),
                            notes="Heuristic page-path guess for Eporner detail pages.",
                        ),
                        ClientFieldProbeCandidate(
                            name="embed-path",
                            template=OperationTemplate(path_template="/embed/{external_id}/"),
                            notes="Embed-path fallback for raw detail probing.",
                        ),
                    ],
                ),
                random=RandomFieldProbeConfig(
                    enabled=False,
                    candidates=[
                        ClientFieldProbeCandidate(
                            name="random-root",
                            template=OperationTemplate(path_template="/random"),
                            notes="Heuristic random page route.",
                        )
                    ],
                ),
            ),
        ]
    )


def load_client_field_suite_config(path: Path | None) -> ClientFieldSuiteConfig:
    """Load a field-suite config from disk or return the heuristic default."""

    if path is None:
        return build_default_client_field_suite_config()
    return ClientFieldSuiteConfig.model_validate_json(path.read_text(encoding="utf-8"))


def write_example_config(path: Path) -> None:
    """Write the heuristic default config to disk for customization."""

    config = build_default_client_field_suite_config()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(config.model_dump(mode="json"), indent=2, sort_keys=True) + "\n", encoding="utf-8")


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Run a field probe suite against the client layer.")
    parser.add_argument("--config", type=Path, default=None, help="Optional JSON config path.")
    parser.add_argument("--output-dir", type=Path, required=False, help="Output directory for logs and artifacts.")
    parser.add_argument(
        "--write-example-config",
        type=Path,
        default=None,
        help="Write the default heuristic config to the given path and exit.",
    )
    parser.add_argument(
        "--sources",
        nargs="*",
        choices=[source.value for source in ExternalSource],
        default=None,
        help="Optional subset of sources to probe.",
    )
    parser.add_argument("--log-level", default="DEBUG", help="Structlog level for the suite log file.")
    parser.add_argument(
        "--fail-on-case-error",
        action="store_true",
        help="Exit non-zero on the first case exception instead of only reporting it.",
    )
    args = parser.parse_args(argv)

    if args.write_example_config is not None:
        write_example_config(args.write_example_config)
        print(f"wrote example config to {args.write_example_config}")
        return 0

    config = load_client_field_suite_config(args.config)
    if args.sources:
        selected = {ExternalSource(source) for source in args.sources}
        config = ClientFieldSuiteConfig(
            sources=[source for source in config.sources if source.source in selected]
        )
    if not config.sources:
        raise SystemExit("no sources selected for the client field probe")

    output_directory = args.output_dir or Path.cwd() / "client-field-probe-output" / datetime.now(timezone.utc).strftime(
        "%Y%m%dT%H%M%SZ"
    )
    runner = ClientFieldSuiteRunner(
        config,
        output_directory=output_directory,
        config_path=args.config,
        log_level=args.log_level,
        fail_on_case_error=args.fail_on_case_error,
    )
    report = asyncio.run(runner.run())
    print(f"client field probe output: {output_directory}")
    print(f"cases: {report.case_count}")
    print(f"failed_cases: {report.failed_case_count}")
    return 1 if args.fail_on_case_error and report.failed_case_count > 0 else 0


def _build_probe_profile(
    source_config: ClientFieldSourceConfig,
    operation: ClientOperation,
    template: OperationTemplate,
) -> SourceClientProfile:
    search_template = template if operation is ClientOperation.SEARCH else None
    video_template = template if operation is ClientOperation.VIDEO else None
    random_template = template if operation is ClientOperation.RANDOM else None
    return SourceClientProfile(
        source=source_config.source,
        base_url=source_config.base_url,
        timeout_seconds=source_config.timeout_seconds,
        default_headers=source_config.default_headers,
        search=search_template,
        video=video_template,
        random=random_template,
    )


def _build_strategy(
    source: ExternalSource,
    profile: SourceClientProfile,
    transport: Transport,
) -> BaseSourceClientStrategy:
    if source is ExternalSource.XHAMSTER:
        return XHamsterClientStrategy(profile=profile, transport=transport)
    if source is ExternalSource.EPORNER:
        return EpornerClientStrategy(profile=profile, transport=transport)
    raise ValueError(f"unsupported source: {source.value}")


async def _invoke_client_operation(
    client: BaseSourceClientStrategy,
    operation: ClientOperation,
    request: SearchRequest | VideoLookupRequest | RandomRequest,
) -> RawClientResponse:
    if operation is ClientOperation.SEARCH:
        assert isinstance(request, SearchRequest)
        return await client.search(request)
    if operation is ClientOperation.VIDEO:
        assert isinstance(request, VideoLookupRequest)
        return await client.get_video(request)
    assert isinstance(request, RandomRequest)
    return await client.get_random(request)


def _build_response_summary(response: RawClientResponse) -> dict[str, object]:
    payload = response.transport.json_payload
    headers = response.transport.headers
    return {
        "source": response.source.value,
        "operation": response.operation.value,
        "status_code": response.transport.status_code,
        "content_type": headers.get("content-type"),
        "header_count": len(headers),
        "text_length": len(response.transport.text),
        "has_json_payload": payload is not None,
        "json_summary": _summarize_json_payload(payload),
        "request": response.transport.request.model_dump(mode="json"),
    }


def _summarize_json_payload(payload: StructuredJson | None) -> dict[str, object] | None:
    if payload is None:
        return None
    if isinstance(payload, dict):
        return {
            "type": "object",
            "top_level_keys": sorted(payload.keys())[:50],
        }
    first_item_type = type(payload[0]).__name__ if payload else None
    return {
        "type": "array",
        "length": len(payload),
        "first_item_type": first_item_type,
    }


def _extract_external_ids_from_payload(
    source: ExternalSource,
    payload: StructuredJson | None,
    *,
    max_count: int,
) -> list[str]:
    if payload is None or max_count <= 0:
        return []

    discovered: list[str] = []

    def visit(node: object, depth: int = 0) -> None:
        if len(discovered) >= max_count or depth > 5:
            return
        if isinstance(node, Mapping):
            _collect_candidates_from_mapping(source, node, discovered, max_count)
            for value in list(node.values())[:50]:
                visit(value, depth + 1)
            return
        if isinstance(node, list):
            for item in node[:50]:
                visit(item, depth + 1)

    visit(payload)
    return _dedupe_strings(discovered)[:max_count]


def _collect_candidates_from_mapping(
    source: ExternalSource,
    node: Mapping[str, object],
    discovered: list[str],
    max_count: int,
) -> None:
    for key in ("id", "video_id", "videoId", "slug"):
        candidate = _normalize_external_id_candidate(source, node.get(key))
        if candidate:
            discovered.append(candidate)
            if len(discovered) >= max_count:
                return

    for key in ("link", "url", "href", "page_url", "video", "embed", "embed_url", "player_url", "source"):
        candidate = _normalize_external_id_candidate(source, node.get(key))
        if candidate:
            discovered.append(candidate)
            if len(discovered) >= max_count:
                return


def _normalize_external_id_candidate(source: ExternalSource, value: object) -> str | None:
    if not isinstance(value, str):
        return None
    if source is ExternalSource.XHAMSTER:
        return _normalize_xhamster_candidate(value)
    if source is ExternalSource.EPORNER:
        return _normalize_eporner_candidate(value)
    return None


def _normalize_xhamster_candidate(value: str) -> str | None:
    value = _normalize_text(value)
    if not value:
        return None
    query_id = _extract_query_id(value)
    if query_id:
        value = unquote(query_id)

    if value.startswith(("http://", "https://")):
        path = urlparse(value).path.lstrip("/")
    else:
        path = value.lstrip("/")

    path = path.split("?", 1)[0].split("#", 1)[0]
    if path.startswith("embed/"):
        path = path.removeprefix("embed/")
    if path.startswith("videos/"):
        path = path.removeprefix("videos/")
    lowered = path.lower()
    if lowered in {"", "out", "ff", "ff/out", "search"}:
        return None
    if lowered.startswith(("out/", "ff/out/", "search/")):
        return None
    if any(token in path for token in ("=", "&", "%")):
        return None
    return path or None


def _normalize_eporner_candidate(value: str) -> str | None:
    value = _normalize_text(value)
    if not value:
        return None
    query_id = _extract_query_id(value)
    if query_id:
        return _normalize_text(unquote(query_id))

    if value.startswith(("http://", "https://")):
        path = urlparse(value).path
    else:
        path = value
    path = path.split("?", 1)[0].split("#", 1)[0]
    segments = [segment for segment in path.split("/") if segment]
    if not segments:
        return None
    if segments[0].startswith("video-"):
        return segments[0].removeprefix("video-") or None
    if len(segments) >= 2 and segments[0] in {"hd-porn", "embed"}:
        return segments[1]
    if value.isascii() and value.replace("-", "").replace("_", "").isalnum():
        return value
    return None


def _extract_query_id(url: str) -> str | None:
    values = parse_qs(urlparse(url).query).get("id", [])
    if values:
        return values[0]
    return None


def _normalize_text(value: str | None) -> str | None:
    if value is None:
        return None
    cleaned = " ".join(value.replace("\t", " ").replace("\r", " ").replace("\n", " ").split())
    return cleaned or None


def _slugify(value: str) -> str:
    value = value.strip().lower()
    value = re.sub(r"[^a-z0-9]+", "-", value)
    value = value.strip("-")
    return value or "value"


def _timestamp() -> str:
    return datetime.now(timezone.utc).isoformat()


def _dedupe_strings(values: Sequence[str]) -> list[str]:
    seen: set[str] = set()
    ordered: list[str] = []
    for value in values:
        if value in seen:
            continue
        seen.add(value)
        ordered.append(value)
    return ordered


def _max_discovered_id_count(source_config: ClientFieldSourceConfig, operation: ClientOperation) -> int:
    if operation is ClientOperation.SEARCH and source_config.search is not None:
        return source_config.search.max_discovered_external_ids
    if operation is ClientOperation.VIDEO and source_config.video is not None:
        return source_config.video.max_discovered_external_ids
    return 0


def _serialize_span(span: object) -> dict[str, object]:
    context = getattr(span, "context")
    parent = getattr(span, "parent")
    return {
        "name": getattr(span, "name"),
        "trace_id": f"{context.trace_id:032x}",
        "span_id": f"{context.span_id:016x}",
        "parent_span_id": f"{parent.span_id:016x}" if parent is not None else None,
        "start_time_unix_nano": getattr(span, "start_time"),
        "end_time_unix_nano": getattr(span, "end_time"),
        "attributes": dict(getattr(span, "attributes", {}) or {}),
        "events": [
            {
                "name": event.name,
                "timestamp": event.timestamp,
                "attributes": dict(event.attributes or {}),
            }
            for event in getattr(span, "events", [])
        ],
        "status": {
            "status_code": getattr(getattr(span, "status", None), "status_code", None).name
            if getattr(span, "status", None) is not None
            else None,
            "description": getattr(getattr(span, "status", None), "description", None),
        },
    }


def _serialize_metrics(metrics_data: object) -> dict[str, object]:
    serialized: list[dict[str, object]] = []
    for resource_metrics in getattr(metrics_data, "resource_metrics", []):
        resource_attributes = dict(getattr(resource_metrics.resource, "attributes", {}) or {})
        scope_metrics_payload: list[dict[str, object]] = []
        for scope_metrics in getattr(resource_metrics, "scope_metrics", []):
            metrics_payload: list[dict[str, object]] = []
            for metric in getattr(scope_metrics, "metrics", []):
                metrics_payload.append(
                    {
                        "name": metric.name,
                        "description": metric.description,
                        "unit": metric.unit,
                        "data_points": [
                            {
                                "attributes": dict(data_point.attributes or {}),
                                "value": getattr(data_point, "value", None),
                                "count": getattr(data_point, "count", None),
                                "sum": getattr(data_point, "sum", None),
                            }
                            for data_point in getattr(metric.data, "data_points", [])
                        ],
                    }
                )
            scope_metrics_payload.append(
                {
                    "scope_name": getattr(scope_metrics.scope, "name", None),
                    "metrics": metrics_payload,
                }
            )
        serialized.append(
            {
                "resource_attributes": resource_attributes,
                "scope_metrics": scope_metrics_payload,
            }
        )
    return {"resource_metrics": serialized}


if __name__ == "__main__":
    raise SystemExit(main())
