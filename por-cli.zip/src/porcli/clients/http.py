"""HTTP transport implementation."""

from __future__ import annotations

import json
from urllib.parse import urlparse

import httpx
from opentelemetry.trace import SpanKind

from porcli.exceptions import ClientTransportError
from porcli.logging import get_logger
from porcli.models.raw import TransportRequest, TransportResponse
from porcli.models.schema import StructuredJson
from porcli.telemetry import get_meter, get_tracer, observe_operation, set_span_attributes


class HTTPXTransport:
    """Minimal async HTTP transport used by client strategies."""

    def __init__(self) -> None:
        self._client = httpx.AsyncClient(follow_redirects=True)
        self.logger = get_logger(__name__).bind(layer="transport", component=type(self).__name__)
        self.tracer = get_tracer(__name__)
        meter = get_meter(__name__)
        self.request_counter = meter.create_counter(
            "porcli.transport.requests",
            unit="1",
            description="Count of outgoing transport requests.",
        )
        self.request_duration = meter.create_histogram(
            "porcli.transport.request.duration",
            unit="s",
            description="Duration of outgoing transport requests in seconds.",
        )

    async def send(self, request: TransportRequest) -> TransportResponse:
        parsed_url = urlparse(request.url)
        metric_attributes = {
            "porcli.layer": "transport",
            "porcli.component": type(self).__name__,
            "http.request.method": request.method,
            "server.address": parsed_url.hostname,
        }
        span_attributes = {
            **metric_attributes,
            "url.full": request.url,
            "server.port": parsed_url.port,
            "porcli.transport.query_key_count": len(request.query),
        }
        request_logger = self.logger.bind(
            method=request.method,
            url=request.url,
            query=request.query,
            timeout_seconds=request.timeout_seconds,
        )
        try:
            with observe_operation(
                self.tracer,
                name="transport.http.request",
                counter=self.request_counter,
                duration_histogram=self.request_duration,
                metric_attributes=metric_attributes,
                span_attributes=span_attributes,
                kind=SpanKind.CLIENT,
            ) as span:
                request_logger.debug("transport.request.start")
                response = await self._client.request(
                    method=request.method,
                    url=request.url,
                    headers=request.headers,
                    params=request.query,
                    content=request.body,
                    timeout=request.timeout_seconds,
                )
                parsed_payload: StructuredJson | None = None
                content_type = response.headers.get("content-type", "")
                if "json" in content_type.lower():
                    try:
                        candidate = response.json()
                        if isinstance(candidate, (dict, list)):
                            parsed_payload = candidate
                            span.add_event(
                                "transport.response.json_parsed",
                                {"porcli.payload.type": type(candidate).__name__},
                            )
                            request_logger.debug(
                                "transport.response.json_parsed",
                                payload_type=type(candidate).__name__,
                            )
                    except json.JSONDecodeError:
                        parsed_payload = None
                        span.add_event(
                            "transport.response.json_decode_failed",
                            {"http.response.content_type": content_type},
                        )
                        request_logger.warning(
                            "transport.response.json_decode_failed",
                            content_type=content_type,
                        )

                set_span_attributes(
                    span,
                    {
                        "http.response.status_code": response.status_code,
                        "http.response.content_type": content_type,
                        "porcli.transport.has_json_payload": parsed_payload is not None,
                        "porcli.transport.response_text_length": len(response.text),
                    },
                )
                request_logger.debug(
                    "transport.request.complete",
                    status_code=response.status_code,
                    content_type=content_type,
                    text_length=len(response.text),
                    has_json_payload=parsed_payload is not None,
                )

                return TransportResponse(
                    request=request,
                    status_code=response.status_code,
                    headers={key: value for key, value in response.headers.items()},
                    text=response.text,
                    json_payload=parsed_payload,
                )
        except httpx.HTTPError as exc:
            request_logger.exception("transport.request.failed")
            raise ClientTransportError(str(exc)) from exc

    async def aclose(self) -> None:
        self.logger.debug("transport.client.close")
        await self._client.aclose()
