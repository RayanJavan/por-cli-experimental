"""Base client strategy implementation and context."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from opentelemetry.trace import SpanKind

from porcli.clients.contracts import ClientStrategy, Transport
from porcli.config import OperationTemplate, SourceClientProfile
from porcli.exceptions import ClientConfigurationError
from porcli.logging import get_logger
from porcli.models.enums import ClientOperation, ExternalSource
from porcli.models.raw import RawClientResponse, TransportRequest
from porcli.models.requests import RandomRequest, SearchRequest, VideoLookupRequest
from porcli.telemetry import get_meter, get_tracer, observe_operation, set_span_attributes


class BaseSourceClientStrategy(ClientStrategy):
    """Config-driven strategy for one direct external source."""

    source: ExternalSource

    def __init__(self, profile: SourceClientProfile, transport: Transport) -> None:
        if profile.source != self.source:
            raise ClientConfigurationError(
                f"Profile source {profile.source!s} does not match strategy source {self.source!s}"
            )
        self.profile = profile
        self.transport = transport
        self.logger = get_logger(__name__).bind(
            layer="client",
            component=type(self).__name__,
            source=self.source.value,
        )
        self.tracer = get_tracer(__name__)
        meter = get_meter(__name__)
        self.operation_counter = meter.create_counter(
            "porcli.client.operations",
            unit="1",
            description="Count of client operations by source and operation.",
        )
        self.operation_duration = meter.create_histogram(
            "porcli.client.operation.duration",
            unit="s",
            description="Duration of client operations in seconds.",
        )

    async def search(self, request: SearchRequest) -> RawClientResponse:
        return await self._execute_operation(
            operation=ClientOperation.SEARCH,
            template=self.profile.search,
            context={"query": request.query, "page": request.page},
            log_context={"query": request.query, "page": request.page},
        )

    async def get_video(self, request: VideoLookupRequest) -> RawClientResponse:
        return await self._execute_operation(
            operation=ClientOperation.VIDEO,
            template=self.profile.video,
            context={"external_id": request.external_id},
            log_context={"external_id": request.external_id},
        )

    async def get_random(self, request: RandomRequest | None = None) -> RawClientResponse:
        filters = {} if request is None else dict(request.filters)
        return await self._execute_operation(
            operation=ClientOperation.RANDOM,
            template=self.profile.random,
            context=filters,
            log_context={"filters": filters},
        )

    async def _execute_operation(
        self,
        *,
        operation: ClientOperation,
        template: OperationTemplate | None,
        context: dict[str, Any],
        log_context: dict[str, Any],
    ) -> RawClientResponse:
        operation_logger = self.logger.bind(operation=operation.value, **log_context)
        metric_attributes = {
            "porcli.layer": "client",
            "porcli.component": type(self).__name__,
            "porcli.source": self.source.value,
            "porcli.operation": operation.value,
        }
        span_attributes = {
            **metric_attributes,
            "porcli.request.page": context.get("page") if isinstance(context.get("page"), int) else None,
            "porcli.request.query_length": len(context["query"]) if isinstance(context.get("query"), str) else None,
            "porcli.request.filter_count": len(context) if operation is ClientOperation.RANDOM else None,
        }

        with observe_operation(
            self.tracer,
            name=f"client.{operation.value}",
            counter=self.operation_counter,
            duration_histogram=self.operation_duration,
            metric_attributes=metric_attributes,
            span_attributes=span_attributes,
            kind=SpanKind.INTERNAL,
        ) as span:
            operation_logger.info("client.operation.start")

            try:
                transport_request = self._build_request(
                    operation=operation,
                    template=template,
                    context=context,
                )
            except Exception:
                operation_logger.exception("client.transport_request.build_failed")
                raise
            set_span_attributes(
                span,
                {
                    "http.request.method": transport_request.method,
                    "url.full": transport_request.url,
                    "porcli.transport.query_key_count": len(transport_request.query),
                },
            )
            span.add_event(
                "client.transport_request.built",
                {
                    "http.request.method": transport_request.method,
                    "url.full": transport_request.url,
                    "porcli.transport.query_key_count": len(transport_request.query),
                },
            )
            operation_logger.debug(
                "client.transport_request.built",
                method=transport_request.method,
                url=transport_request.url,
                query=transport_request.query,
                timeout_seconds=transport_request.timeout_seconds,
            )

            transport_response = await self.transport.send(transport_request)
            set_span_attributes(
                span,
                {
                    "http.response.status_code": transport_response.status_code,
                    "porcli.transport.has_json_payload": transport_response.json_payload is not None,
                },
            )
            span.add_event(
                "client.operation.complete",
                {
                    "http.response.status_code": transport_response.status_code,
                    "porcli.transport.has_json_payload": transport_response.json_payload is not None,
                    "porcli.transport.response_text_length": len(transport_response.text),
                },
            )
            operation_logger.info(
                "client.operation.complete",
                status_code=transport_response.status_code,
                has_json_payload=transport_response.json_payload is not None,
                response_text_length=len(transport_response.text),
            )

            return RawClientResponse(
                source=self.source,
                operation=operation,
                transport=transport_response,
            )

    def _build_request(
        self,
        operation: ClientOperation,
        template: OperationTemplate | None,
        context: dict[str, Any],
    ) -> TransportRequest:
        if template is None:
            raise ClientConfigurationError(
                f"No {operation.value} operation template configured for source {self.source.value}"
            )

        path = template.path_template.format_map(SafeFormatMap(context))
        if path.startswith("http://") or path.startswith("https://"):
            url = path
        else:
            url = f"{str(self.profile.base_url).rstrip('/')}/{path.lstrip('/')}"

        query = {
            key: value.format_map(SafeFormatMap(context))
            for key, value in template.query_templates.items()
        }
        headers = dict(self.profile.default_headers)
        headers.update(template.headers)

        return TransportRequest(
            method=template.method.upper(),
            url=url,
            headers=headers,
            query=query,
            timeout_seconds=self.profile.timeout_seconds,
        )


@dataclass(slots=True)
class ClientContext:
    """Strategy context for source clients."""

    strategy: ClientStrategy
    logger: Any = field(init=False, repr=False)
    tracer: Any = field(init=False, repr=False)
    dispatch_counter: Any = field(init=False, repr=False)
    dispatch_duration: Any = field(init=False, repr=False)

    def __post_init__(self) -> None:
        self.logger = get_logger(__name__).bind(
            layer="client",
            component=type(self).__name__,
            strategy=type(self.strategy).__name__,
        )
        self.tracer = get_tracer(__name__)
        meter = get_meter(__name__)
        self.dispatch_counter = meter.create_counter(
            "porcli.client_context.dispatches",
            unit="1",
            description="Count of client-context dispatches.",
        )
        self.dispatch_duration = meter.create_histogram(
            "porcli.client_context.dispatch.duration",
            unit="s",
            description="Duration of client-context dispatches in seconds.",
        )

    def set_strategy(self, strategy: ClientStrategy) -> None:
        previous_strategy = type(self.strategy).__name__
        self.strategy = strategy
        self.logger = self.logger.bind(strategy=type(strategy).__name__)
        self.logger.info(
            "client_context.strategy.updated",
            previous_strategy=previous_strategy,
            current_strategy=type(strategy).__name__,
        )

    async def search(self, request: SearchRequest) -> RawClientResponse:
        with observe_operation(
            self.tracer,
            name="client_context.search",
            counter=self.dispatch_counter,
            duration_histogram=self.dispatch_duration,
            metric_attributes={
                "porcli.layer": "client",
                "porcli.component": type(self).__name__,
                "porcli.operation": "search",
            },
            span_attributes={
                "porcli.layer": "client",
                "porcli.component": type(self).__name__,
                "porcli.operation": "search",
                "porcli.request.page": request.page,
                "porcli.request.query_length": len(request.query),
            },
        ):
            self.logger.debug("client_context.search.dispatch", page=request.page, query=request.query)
            return await self.strategy.search(request)

    async def get_video(self, request: VideoLookupRequest) -> RawClientResponse:
        with observe_operation(
            self.tracer,
            name="client_context.video",
            counter=self.dispatch_counter,
            duration_histogram=self.dispatch_duration,
            metric_attributes={
                "porcli.layer": "client",
                "porcli.component": type(self).__name__,
                "porcli.operation": "video",
            },
            span_attributes={
                "porcli.layer": "client",
                "porcli.component": type(self).__name__,
                "porcli.operation": "video",
            },
        ):
            self.logger.debug("client_context.video.dispatch", external_id=request.external_id)
            return await self.strategy.get_video(request)

    async def get_random(self, request: RandomRequest | None = None) -> RawClientResponse:
        filters = {} if request is None else dict(request.filters)
        with observe_operation(
            self.tracer,
            name="client_context.random",
            counter=self.dispatch_counter,
            duration_histogram=self.dispatch_duration,
            metric_attributes={
                "porcli.layer": "client",
                "porcli.component": type(self).__name__,
                "porcli.operation": "random",
            },
            span_attributes={
                "porcli.layer": "client",
                "porcli.component": type(self).__name__,
                "porcli.operation": "random",
                "porcli.request.filter_count": len(filters),
            },
        ):
            self.logger.debug("client_context.random.dispatch", filters=filters)
            return await self.strategy.get_random(request)


class SafeFormatMap(dict[str, Any]):
    """Format map that fails clearly on missing placeholders."""

    def __missing__(self, key: str) -> str:
        raise ClientConfigurationError(f"Missing template variable: {key}")
