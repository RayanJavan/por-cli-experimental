"""Client contracts, transports, and concrete source strategies."""

from porcli.clients.base import BaseSourceClientStrategy, ClientContext
from porcli.clients.eporner import EpornerClientStrategy
from porcli.clients.http import HTTPXTransport
from porcli.clients.xhamster import XHamsterClientStrategy

__all__ = [
    "BaseSourceClientStrategy",
    "ClientContext",
    "EpornerClientStrategy",
    "HTTPXTransport",
    "XHamsterClientStrategy",
]
