"""XHamster client strategy."""

from __future__ import annotations

from porcli.clients.base import BaseSourceClientStrategy
from porcli.config import SourceClientProfile
from porcli.models.enums import ExternalSource


class XHamsterClientStrategy(BaseSourceClientStrategy):
    source = ExternalSource.XHAMSTER

    @staticmethod
    def default_profile() -> SourceClientProfile:
        return SourceClientProfile(
            source=ExternalSource.XHAMSTER,
            base_url="https://xhamster.com",
            default_headers={},
        )
