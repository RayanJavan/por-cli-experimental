"""Client-side transport and strategy contracts."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Protocol

from porcli.models.raw import RawClientResponse, TransportRequest, TransportResponse
from porcli.models.requests import RandomRequest, SearchRequest, VideoLookupRequest


class Transport(Protocol):
    async def send(self, request: TransportRequest) -> TransportResponse:
        """Execute a raw transport request."""


class ClientStrategy(ABC):
    """Strategy contract for direct-source communication."""

    @abstractmethod
    async def search(self, request: SearchRequest) -> RawClientResponse:
        """Fetch a raw search response from a source."""

    @abstractmethod
    async def get_video(self, request: VideoLookupRequest) -> RawClientResponse:
        """Fetch a raw video/detail response from a source."""

    @abstractmethod
    async def get_random(self, request: RandomRequest | None = None) -> RawClientResponse:
        """Fetch a raw random-video response from a source."""
