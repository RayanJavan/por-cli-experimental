"""Eporner client strategy."""

from __future__ import annotations

from porcli.clients.base import BaseSourceClientStrategy
from porcli.config import SourceClientProfile
from porcli.models.enums import ExternalSource


class EpornerClientStrategy(BaseSourceClientStrategy):
    source = ExternalSource.EPORNER

    @staticmethod
    def default_profile() -> SourceClientProfile:
        return SourceClientProfile(
            source=ExternalSource.EPORNER,
            base_url="https://www.eporner.com",
            default_headers={},
        )
