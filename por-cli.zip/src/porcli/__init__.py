"""Core package for the Python rewrite scaffold."""

from porcli.logging import (
    LoggingConfiguration,
    bind_context,
    bound_context,
    clear_context,
    configure_logging,
    get_logger,
    unbind_context,
)
from porcli.registry import (
    SourceRuntime,
    build_catalog_service,
    build_source_gateway,
    build_source_runtime,
)
from porcli.services.catalog import CatalogService
from porcli.services.gateway import AdapterBackedSourceGateway
from porcli.services.models import MultiSourceSearchResult, SourceVideoSelector
from porcli.telemetry import (
    InMemoryTelemetryHarness,
    TelemetryConfiguration,
    TelemetryRuntime,
    configure_in_memory_telemetry,
    configure_telemetry,
    force_flush_telemetry,
    get_meter,
    get_tracer,
    shutdown_telemetry,
)

__all__ = [
    "AdapterBackedSourceGateway",
    "CatalogService",
    "configure_in_memory_telemetry",
    "LoggingConfiguration",
    "MultiSourceSearchResult",
    "SourceRuntime",
    "SourceVideoSelector",
    "TelemetryConfiguration",
    "TelemetryRuntime",
    "InMemoryTelemetryHarness",
    "bind_context",
    "bound_context",
    "build_catalog_service",
    "build_source_gateway",
    "build_source_runtime",
    "clear_context",
    "configure_logging",
    "configure_telemetry",
    "force_flush_telemetry",
    "get_logger",
    "get_meter",
    "get_tracer",
    "shutdown_telemetry",
    "unbind_context",
]
