"""Source runtime composition helpers."""

from __future__ import annotations

from dataclasses import dataclass

from porcli.adapters.contracts import SourceAdapter
from porcli.adapters.eporner import EpornerAdapter
from porcli.adapters.xhamster import XHamsterAdapter
from porcli.clients.base import ClientContext
from porcli.clients.contracts import Transport
from porcli.clients.eporner import EpornerClientStrategy
from porcli.clients.xhamster import XHamsterClientStrategy
from porcli.config import SourceClientProfile
from porcli.exceptions import ClientConfigurationError
from porcli.logging import get_logger
from porcli.models.enums import ExternalSource
from porcli.services.catalog import CatalogService
from porcli.services.gateway import AdapterBackedSourceGateway
from porcli.telemetry import get_meter, get_tracer, observe_operation, set_span_attributes

logger = get_logger(__name__).bind(layer="composition", component="registry")


@dataclass(slots=True)
class SourceRuntime:
    source: ExternalSource
    client: ClientContext
    adapter: SourceAdapter


def build_source_runtime(
    source: ExternalSource,
    transport: Transport,
    profile: SourceClientProfile | None = None,
) -> SourceRuntime:
    tracer, operation_counter, operation_duration = _observability()
    runtime_logger = logger.bind(source=source.value)
    with observe_operation(
        tracer,
        name="registry.build_source_runtime",
        counter=operation_counter,
        duration_histogram=operation_duration,
        metric_attributes=_metric_attributes("build_source_runtime", source=source),
        span_attributes=_metric_attributes("build_source_runtime", source=source),
    ) as span:
        if source is ExternalSource.XHAMSTER:
            strategy = XHamsterClientStrategy(profile or XHamsterClientStrategy.default_profile(), transport)
            adapter = XHamsterAdapter()
        elif source is ExternalSource.EPORNER:
            strategy = EpornerClientStrategy(profile or EpornerClientStrategy.default_profile(), transport)
            adapter = EpornerAdapter()
        else:
            raise ClientConfigurationError(f"Unsupported source runtime: {source!s}")

        runtime = SourceRuntime(
            source=source,
            client=ClientContext(strategy=strategy),
            adapter=adapter,
        )
        set_span_attributes(
            span,
            {
                "porcli.registry.strategy": type(strategy).__name__,
                "porcli.registry.adapter": type(adapter).__name__,
            },
        )
        runtime_logger.info(
            "registry.source_runtime.built",
            strategy=type(strategy).__name__,
            adapter=type(adapter).__name__,
        )
        return runtime


def build_source_gateway(
    source: ExternalSource,
    transport: Transport,
    profile: SourceClientProfile | None = None,
) -> AdapterBackedSourceGateway:
    tracer, operation_counter, operation_duration = _observability()
    with observe_operation(
        tracer,
        name="registry.build_source_gateway",
        counter=operation_counter,
        duration_histogram=operation_duration,
        metric_attributes=_metric_attributes("build_source_gateway", source=source),
        span_attributes=_metric_attributes("build_source_gateway", source=source),
    ) as span:
        runtime = build_source_runtime(source=source, transport=transport, profile=profile)
        gateway = AdapterBackedSourceGateway(
            source=runtime.source,
            client=runtime.client,
            adapter=runtime.adapter,
        )
        set_span_attributes(span, {"porcli.registry.gateway": type(gateway).__name__})
        logger.info(
            "registry.source_gateway.built",
            source=source.value,
            gateway=type(gateway).__name__,
        )
        return gateway


def build_catalog_service(
    sources: list[ExternalSource],
    transport: Transport,
    profiles: dict[ExternalSource, SourceClientProfile] | None = None,
) -> CatalogService:
    tracer, operation_counter, operation_duration = _observability()
    with observe_operation(
        tracer,
        name="registry.build_catalog_service",
        counter=operation_counter,
        duration_histogram=operation_duration,
        metric_attributes=_metric_attributes("build_catalog_service"),
        span_attributes={
            **_metric_attributes("build_catalog_service"),
            "porcli.registry.source_count": len(sources),
            "porcli.sources": [source.value for source in sources],
        },
    ) as span:
        gateways = [
            build_source_gateway(
                source=source,
                transport=transport,
                profile=(profiles or {}).get(source),
            )
            for source in sources
        ]
        service = CatalogService(gateways)
        set_span_attributes(span, {"porcli.registry.gateway_count": len(gateways)})
        logger.info(
            "registry.catalog_service.built",
            source_count=len(sources),
            sources=[source.value for source in sources],
        )
        return service


def _observability() -> tuple[object, object, object]:
    tracer = get_tracer(__name__)
    meter = get_meter(__name__)
    operation_counter = meter.create_counter(
        "porcli.registry.operations",
        unit="1",
        description="Count of registry composition operations.",
    )
    operation_duration = meter.create_histogram(
        "porcli.registry.operation.duration",
        unit="s",
        description="Duration of registry composition operations in seconds.",
    )
    return tracer, operation_counter, operation_duration


def _metric_attributes(
    operation: str,
    *,
    source: ExternalSource | None = None,
) -> dict[str, object]:
    return {
        "porcli.layer": "composition",
        "porcli.component": "registry",
        "porcli.operation": operation,
        "porcli.source": source.value if source is not None else None,
    }
