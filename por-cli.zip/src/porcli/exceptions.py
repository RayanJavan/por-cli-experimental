"""Project exceptions."""

from __future__ import annotations


class PorCliError(Exception):
    """Base exception for the Python rewrite."""


class ClientConfigurationError(PorCliError):
    """Raised when a client strategy is missing required configuration."""


class ClientTransportError(PorCliError):
    """Raised when transport execution fails."""


class AdapterError(PorCliError):
    """Raised when a source adapter cannot adapt a raw response."""


class ServiceError(PorCliError):
    """Raised when a service operation cannot be completed."""


class SourceGatewayNotConfiguredError(ServiceError):
    """Raised when the service layer has no gateway for a requested source."""
