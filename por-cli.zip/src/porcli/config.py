"""Configuration models for source clients."""

from __future__ import annotations

from pydantic import AnyHttpUrl, Field, PositiveFloat

from porcli.models.enums import ExternalSource
from porcli.models.schema import StrictSchemaModel


class OperationTemplate(StrictSchemaModel):
    """Config-driven request template for one client operation."""

    method: str = "GET"
    path_template: str
    query_templates: dict[str, str] = Field(default_factory=dict)
    headers: dict[str, str] = Field(default_factory=dict)


class SourceClientProfile(StrictSchemaModel):
    """Direct-source client profile.

    The profile stays intentionally generic because source-specific endpoint
    details are not pinned down yet.
    """

    source: ExternalSource
    base_url: AnyHttpUrl
    timeout_seconds: PositiveFloat = 20.0
    default_headers: dict[str, str] = Field(default_factory=dict)
    search: OperationTemplate | None = None
    video: OperationTemplate | None = None
    random: OperationTemplate | None = None
