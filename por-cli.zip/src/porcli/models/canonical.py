"""Canonical adapter output models."""

from __future__ import annotations

from pydantic import Field

from porcli.models.enums import AssetKind, ExternalSource
from porcli.models.schema import MetadataMap, NonEmptyString, StrictSchemaModel


class CanonicalPagination(StrictSchemaModel):
    """Canonical pagination schema passed from adapter layer upward."""

    requested_page: int
    returned_count: int = 0
    next_page: int | None = None
    has_more: bool | None = None


class CanonicalCapabilities(StrictSchemaModel):
    """Capability flags that services can inspect without parsing assets."""

    has_page_url: bool = False
    has_embed_url: bool = False
    has_thumbnail_url: bool = False
    has_stream_asset: bool = False
    has_download_asset: bool = False
    has_unknown_asset: bool = False

    def has_any_media(self) -> bool:
        return self.has_embed_url or self.has_stream_asset or self.has_download_asset

    def has_any_visual_target(self) -> bool:
        return self.has_page_url or self.has_embed_url or self.has_thumbnail_url


class CanonicalVideoReference(StrictSchemaModel):
    """Canonical lightweight reference for one source video."""

    source: ExternalSource
    external_id: NonEmptyString
    title: str | None = None
    page_url: str | None = None
    embed_url: str | None = None
    thumbnail_url: str | None = None
    capabilities: CanonicalCapabilities = Field(default_factory=CanonicalCapabilities)
    source_metadata: MetadataMap = Field(default_factory=dict)


class CanonicalAsset(StrictSchemaModel):
    """Canonical asset inventory item."""

    kind: AssetKind
    url: NonEmptyString
    field_name: str | None = None
    source_metadata: MetadataMap = Field(default_factory=dict)


class CanonicalSearchPage(StrictSchemaModel):
    """Canonical search result page passed from adapter/gateway to service."""

    source: ExternalSource
    query: NonEmptyString
    page: int
    pagination: CanonicalPagination
    source_url: str | None = None
    items: list[CanonicalVideoReference] = Field(default_factory=list)
    source_metadata: MetadataMap = Field(default_factory=dict)


class CanonicalVideoDetail(StrictSchemaModel):
    """Canonical detailed video record passed from adapter/gateway to service."""

    source: ExternalSource
    reference: CanonicalVideoReference
    source_url: str | None = None
    duration_label: str | None = None
    views_label: str | None = None
    rating_label: str | None = None
    uploaded_label: str | None = None
    uploader: str | None = None
    performers: list[str] = Field(default_factory=list)
    tags: list[str] = Field(default_factory=list)
    assets: list[CanonicalAsset] = Field(default_factory=list)
    capabilities: CanonicalCapabilities = Field(default_factory=CanonicalCapabilities)
    source_metadata: MetadataMap = Field(default_factory=dict)
