"""Shared schema primitives and base models."""

from __future__ import annotations

from typing import TypeAlias

from pydantic import BaseModel, ConfigDict, StringConstraints
from typing_extensions import Annotated, TypeAliasType

JsonScalar: TypeAlias = str | int | float | bool | None
JsonValue = TypeAliasType(
    "JsonValue",
    dict[str, "JsonValue"] | list["JsonValue"] | JsonScalar,
)
JsonObject = TypeAliasType("JsonObject", dict[str, JsonValue])
JsonArray = TypeAliasType("JsonArray", list[JsonValue])
StructuredJson = TypeAliasType("StructuredJson", JsonObject | JsonArray)
MetadataMap = TypeAliasType("MetadataMap", dict[str, JsonValue])

NonEmptyString = Annotated[str, StringConstraints(strip_whitespace=True, min_length=1)]
OptionalNormalizedString = Annotated[str, StringConstraints(strip_whitespace=True)]


class StrictSchemaModel(BaseModel):
    """Strict base model for stable inter-layer communication."""

    model_config = ConfigDict(
        extra="forbid",
        validate_assignment=True,
        str_strip_whitespace=True,
        use_enum_values=False,
    )


class FlexibleSchemaModel(BaseModel):
    """Flexible base model for source-dependent raw DTO outlines."""

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
        validate_assignment=True,
        str_strip_whitespace=True,
        use_enum_values=False,
    )
