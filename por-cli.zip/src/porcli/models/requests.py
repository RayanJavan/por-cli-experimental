"""Request DTOs shared by client strategies and adapters."""

from __future__ import annotations

from pydantic import Field

from porcli.models.schema import NonEmptyString, StrictSchemaModel


class SearchRequest(StrictSchemaModel):
    """Canonical search request passed across layers."""

    query: NonEmptyString
    page: int = Field(default=1, ge=1)


class VideoLookupRequest(StrictSchemaModel):
    """Canonical single-video lookup request passed across layers."""

    external_id: NonEmptyString


class RandomRequest(StrictSchemaModel):
    """Canonical random-selection request passed across layers."""

    filters: dict[str, str] = Field(default_factory=dict)
