"""Enum models shared by clients and adapters."""

from __future__ import annotations

from enum import StrEnum


class ExternalSource(StrEnum):
    XHAMSTER = "xhamster"
    EPORNER = "eporner"


class ClientOperation(StrEnum):
    SEARCH = "search"
    VIDEO = "video"
    RANDOM = "random"


class AssetKind(StrEnum):
    PAGE = "page"
    EMBED = "embed"
    THUMBNAIL = "thumbnail"
    STREAM = "stream"
    DOWNLOAD = "download"
    UNKNOWN = "unknown"
