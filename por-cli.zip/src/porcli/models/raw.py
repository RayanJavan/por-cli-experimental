"""Raw transport and source DTO outlines."""

from __future__ import annotations

from typing import Literal

from pydantic import Field

from porcli.models.enums import ClientOperation, ExternalSource
from porcli.models.schema import FlexibleSchemaModel, StructuredJson, StrictSchemaModel


class LooseModel(FlexibleSchemaModel):
    """Base model for source-dependent raw DTO outlines."""


class TransportRequest(StrictSchemaModel):
    """Stable transport request schema from client strategy to transport."""

    method: str = "GET"
    url: str
    headers: dict[str, str] = Field(default_factory=dict)
    query: dict[str, str] = Field(default_factory=dict)
    body: str | bytes | None = None
    timeout_seconds: float | None = None


class TransportResponse(StrictSchemaModel):
    """Stable transport response schema from transport back to client strategy."""

    request: TransportRequest
    status_code: int
    headers: dict[str, str] = Field(default_factory=dict)
    text: str = ""
    json_payload: StructuredJson | None = None


class RawClientResponse(StrictSchemaModel):
    """Stable client-to-adapter response envelope."""

    source: ExternalSource
    operation: ClientOperation
    transport: TransportResponse


class SourceSearchDocument(LooseModel):
    """Adapter-facing raw search document outline."""

    source: ExternalSource
    document_type: Literal["search"] = "search"
    payload: StructuredJson | None = None


class SourceVideoDocument(LooseModel):
    """Adapter-facing raw video document outline."""

    source: ExternalSource
    document_type: Literal["video"] = "video"
    payload: StructuredJson | None = None


class XHamsterRawSearchRecord(LooseModel):
    raw_id: str | None = None
    raw_page_url: str | None = None
    raw_title: str | None = None
    raw_thumbnail_url: str | None = None
    raw_embed_url: str | None = None
    raw_views_label: str | None = None


class XHamsterRawVideoRecord(LooseModel):
    raw_lookup_id: str | None = None
    raw_page_url: str | None = None
    raw_title: str | None = None
    raw_thumbnail_url: str | None = None
    raw_embed_url: str | None = None
    raw_duration_label: str | None = None
    raw_views_label: str | None = None
    raw_rating_label: str | None = None
    raw_uploaded_label: str | None = None
    raw_performers: list[str] = Field(default_factory=list)
    raw_tags: list[str] = Field(default_factory=list)
    raw_assets: list[str] = Field(default_factory=list)


class EpornerRawSearchRecord(LooseModel):
    raw_id: str | None = None
    raw_page_url: str | None = None
    raw_title: str | None = None
    raw_thumbnail_url: str | None = None
    raw_embed_url: str | None = None
    raw_duration_label: str | None = None
    raw_views_label: str | None = None
    raw_rating_label: str | None = None
    raw_uploader: str | None = None


class EpornerRawVideoRecord(LooseModel):
    raw_lookup_id: str | None = None
    raw_page_url: str | None = None
    raw_title: str | None = None
    raw_thumbnail_url: str | None = None
    raw_embed_url: str | None = None
    raw_duration_label: str | None = None
    raw_views_label: str | None = None
    raw_rating_label: str | None = None
    raw_uploaded_label: str | None = None
    raw_uploader: str | None = None
    raw_performers: list[str] = Field(default_factory=list)
    raw_tags: list[str] = Field(default_factory=list)
    raw_assets: list[str] = Field(default_factory=list)
