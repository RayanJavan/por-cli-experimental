"""Initial generic service layer."""

from __future__ import annotations

from collections.abc import Iterable, Sequence

from porcli.exceptions import SourceGatewayNotConfiguredError
from porcli.logging import get_logger
from porcli.models.canonical import CanonicalSearchPage, CanonicalVideoDetail, CanonicalVideoReference
from porcli.models.enums import ExternalSource
from porcli.models.requests import RandomRequest, SearchRequest, VideoLookupRequest
from porcli.services.contracts import SourceGateway
from porcli.services.models import MultiSourceSearchResult, SourceVideoSelector
from porcli.telemetry import get_meter, get_tracer, observe_operation, record_histogram, set_span_attributes


class CatalogService:
    """Generic service layer over canonical source gateways.

    The service layer is intentionally source-agnostic. All source-specific
    knowledge remains below the service boundary in the client/adapters.
    """

    def __init__(self, gateways: Iterable[SourceGateway]) -> None:
        self._gateways: dict[ExternalSource, SourceGateway] = {}
        for gateway in gateways:
            self._gateways[gateway.source] = gateway
        self.logger = get_logger(__name__).bind(layer="service", component=type(self).__name__)
        self.tracer = get_tracer(__name__)
        meter = get_meter(__name__)
        self.operation_counter = meter.create_counter(
            "porcli.service.operations",
            unit="1",
            description="Count of service operations.",
        )
        self.operation_duration = meter.create_histogram(
            "porcli.service.operation.duration",
            unit="s",
            description="Duration of service operations in seconds.",
        )
        self.output_size = meter.create_histogram(
            "porcli.service.output.size",
            unit="1",
            description="Count of records emitted by service operations.",
        )
        self.logger.info(
            "service.catalog.initialized",
            configured_sources=[source.value for source in self._gateways],
        )

    def list_sources(self) -> tuple[ExternalSource, ...]:
        return tuple(self._gateways.keys())

    def has_source(self, source: ExternalSource) -> bool:
        return source in self._gateways

    def get_gateway(self, source: ExternalSource) -> SourceGateway:
        try:
            return self._gateways[source]
        except KeyError as exc:
            self.logger.error("service.gateway.missing", source=source.value)
            raise SourceGatewayNotConfiguredError(f"No source gateway configured for {source.value}") from exc

    async def search_source(self, source: ExternalSource, request: SearchRequest) -> CanonicalSearchPage:
        with observe_operation(
            self.tracer,
            name="service.search_source",
            counter=self.operation_counter,
            duration_histogram=self.operation_duration,
            metric_attributes=self._metric_attributes("search_source", source=source),
            span_attributes=self._span_attributes(
                "search_source",
                source=source,
                **{
                    "porcli.request.page": request.page,
                    "porcli.request.query_length": len(request.query),
                },
            ),
        ) as span:
            self.logger.info("service.search_source.start", source=source.value, query=request.query, page=request.page)
            gateway = self.get_gateway(source)
            result = await gateway.search(request)
            set_span_attributes(span, {"porcli.service.returned_count": result.pagination.returned_count})
            record_histogram(
                self.output_size,
                result.pagination.returned_count,
                self._metric_attributes("search_source", source=source),
            )
            self.logger.info(
                "service.search_source.complete",
                source=source.value,
                query=request.query,
                page=request.page,
                returned_count=result.pagination.returned_count,
            )
            return result

    async def search_sources(
        self,
        request: SearchRequest,
        sources: Sequence[ExternalSource] | None = None,
    ) -> MultiSourceSearchResult:
        selected_sources = list(sources or self.list_sources())
        with observe_operation(
            self.tracer,
            name="service.search_sources",
            counter=self.operation_counter,
            duration_histogram=self.operation_duration,
            metric_attributes=self._metric_attributes("search_sources"),
            span_attributes=self._span_attributes(
                "search_sources",
                **{
                    "porcli.request.page": request.page,
                    "porcli.request.query_length": len(request.query),
                    "porcli.request.source_count": len(selected_sources),
                    "porcli.sources": [source.value for source in selected_sources],
                },
            ),
        ) as span:
            self.logger.info(
                "service.search_sources.start",
                query=request.query,
                page=request.page,
                requested_sources=[source.value for source in selected_sources],
            )
            pages: list[CanonicalSearchPage] = []
            items: list[CanonicalVideoReference] = []

            for source in selected_sources:
                page = await self.search_source(source, request)
                pages.append(page)
                items.extend(page.items)

            result = MultiSourceSearchResult(
                query=request.query,
                requested_page=request.page,
                requested_sources=selected_sources,
                pages=pages,
                items=items,
            )
            set_span_attributes(
                span,
                {
                    "porcli.service.page_count": len(result.pages),
                    "porcli.service.item_count": len(result.items),
                },
            )
            record_histogram(
                self.output_size,
                len(result.items),
                self._metric_attributes("search_sources"),
            )
            self.logger.info(
                "service.search_sources.complete",
                query=request.query,
                page=request.page,
                page_count=len(result.pages),
                item_count=len(result.items),
            )
            return result

    async def get_video(self, source: ExternalSource, request: VideoLookupRequest) -> CanonicalVideoDetail:
        with observe_operation(
            self.tracer,
            name="service.get_video",
            counter=self.operation_counter,
            duration_histogram=self.operation_duration,
            metric_attributes=self._metric_attributes("get_video", source=source),
            span_attributes=self._span_attributes("get_video", source=source),
        ) as span:
            self.logger.info("service.get_video.start", source=source.value, external_id=request.external_id)
            gateway = self.get_gateway(source)
            result = await gateway.get_video(request)
            set_span_attributes(span, {"porcli.service.asset_count": len(result.assets)})
            record_histogram(
                self.output_size,
                len(result.assets),
                self._metric_attributes("get_video", source=source),
            )
            self.logger.info(
                "service.get_video.complete",
                source=source.value,
                external_id=result.reference.external_id,
                asset_count=len(result.assets),
            )
            return result

    async def get_video_by_selector(self, selector: SourceVideoSelector) -> CanonicalVideoDetail:
        self.logger.debug(
            "service.get_video_by_selector.dispatch",
            source=selector.source.value,
            external_id=selector.external_id,
        )
        return await self.get_video(
            selector.source,
            VideoLookupRequest(external_id=selector.external_id),
        )

    async def get_video_for_reference(self, reference: CanonicalVideoReference) -> CanonicalVideoDetail:
        self.logger.debug(
            "service.get_video_for_reference.dispatch",
            source=reference.source.value,
            external_id=reference.external_id,
        )
        return await self.get_video(
            reference.source,
            VideoLookupRequest(external_id=reference.external_id),
        )

    async def get_random(
        self,
        source: ExternalSource,
        request: RandomRequest | None = None,
    ) -> CanonicalVideoDetail:
        filters = {} if request is None else dict(request.filters)
        with observe_operation(
            self.tracer,
            name="service.get_random",
            counter=self.operation_counter,
            duration_histogram=self.operation_duration,
            metric_attributes=self._metric_attributes("get_random", source=source),
            span_attributes=self._span_attributes(
                "get_random",
                source=source,
                **{"porcli.request.filter_count": len(filters)},
            ),
        ) as span:
            self.logger.info("service.get_random.start", source=source.value, filters=filters)
            gateway = self.get_gateway(source)
            result = await gateway.get_random(request)
            set_span_attributes(span, {"porcli.service.asset_count": len(result.assets)})
            record_histogram(
                self.output_size,
                len(result.assets),
                self._metric_attributes("get_random", source=source),
            )
            self.logger.info(
                "service.get_random.complete",
                source=source.value,
                external_id=result.reference.external_id,
                asset_count=len(result.assets),
            )
            return result

    def _metric_attributes(
        self,
        operation: str,
        *,
        source: ExternalSource | None = None,
    ) -> dict[str, object]:
        return {
            "porcli.layer": "service",
            "porcli.component": type(self).__name__,
            "porcli.operation": operation,
            "porcli.source": source.value if source is not None else None,
        }

    def _span_attributes(
        self,
        operation: str,
        *,
        source: ExternalSource | None = None,
        **extra: object,
    ) -> dict[str, object]:
        return {
            **self._metric_attributes(operation, source=source),
            **extra,
        }
