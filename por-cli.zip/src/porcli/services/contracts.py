"""Service-facing gateway contracts."""

from __future__ import annotations

from typing import Protocol

from porcli.models.canonical import CanonicalSearchPage, CanonicalVideoDetail
from porcli.models.enums import ExternalSource
from porcli.models.requests import RandomRequest, SearchRequest, VideoLookupRequest


class SourceGateway(Protocol):
    """Canonical source gateway consumed by the service layer.

    Gateways hide raw client responses and source DTOs. By the time the service
    layer receives data, the adapter boundary has already been crossed.
    """

    source: ExternalSource

    async def search(self, request: SearchRequest) -> CanonicalSearchPage:
        """Fetch a canonical search page for one source."""

    async def get_video(self, request: VideoLookupRequest) -> CanonicalVideoDetail:
        """Fetch a canonical video detail for one source."""

    async def get_random(self, request: RandomRequest | None = None) -> CanonicalVideoDetail:
        """Fetch a canonical random video for one source."""
