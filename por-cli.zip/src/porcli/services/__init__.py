"""Service-layer contracts and implementations."""

from porcli.services.catalog import CatalogService
from porcli.services.gateway import AdapterBackedSourceGateway
from porcli.services.models import MultiSourceSearchResult, SourceVideoSelector

__all__ = [
    "AdapterBackedSourceGateway",
    "CatalogService",
    "MultiSourceSearchResult",
    "SourceVideoSelector",
]
