"""Service-layer request and aggregation models."""

from __future__ import annotations

from pydantic import Field

from porcli.models.canonical import CanonicalSearchPage, CanonicalVideoReference
from porcli.models.enums import ExternalSource
from porcli.models.schema import NonEmptyString, StrictSchemaModel


class SourceVideoSelector(StrictSchemaModel):
    """Service-level video selector.

    The service layer uses this as the stable source/external-id handle without
    depending on any source-specific identifier structure.
    """

    source: ExternalSource
    external_id: NonEmptyString


class MultiSourceSearchResult(StrictSchemaModel):
    """Aggregated service result for one search request across many sources."""

    query: NonEmptyString
    requested_page: int
    requested_sources: list[ExternalSource] = Field(default_factory=list)
    pages: list[CanonicalSearchPage] = Field(default_factory=list)
    items: list[CanonicalVideoReference] = Field(default_factory=list)

    def page_for(self, source: ExternalSource) -> CanonicalSearchPage | None:
        for page in self.pages:
            if page.source is source:
                return page
        return None
