"""Gateway implementation that composes client and adapter layers."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from porcli.adapters.contracts import SourceAdapter
from porcli.clients.base import ClientContext
from porcli.logging import get_logger
from porcli.models.canonical import CanonicalSearchPage, CanonicalVideoDetail
from porcli.models.enums import ExternalSource
from porcli.models.requests import RandomRequest, SearchRequest, VideoLookupRequest
from porcli.telemetry import get_meter, get_tracer, observe_operation, record_histogram, set_span_attributes


@dataclass(slots=True)
class AdapterBackedSourceGateway:
    """Canonical source gateway backed by one client strategy and one adapter."""

    source: ExternalSource
    client: ClientContext
    adapter: SourceAdapter
    logger: Any = field(init=False, repr=False)
    tracer: Any = field(init=False, repr=False)
    operation_counter: Any = field(init=False, repr=False)
    operation_duration: Any = field(init=False, repr=False)
    output_size: Any = field(init=False, repr=False)

    def __post_init__(self) -> None:
        self.logger = get_logger(__name__).bind(
            layer="gateway",
            component=type(self).__name__,
            source=self.source.value,
        )
        self.tracer = get_tracer(__name__)
        meter = get_meter(__name__)
        self.operation_counter = meter.create_counter(
            "porcli.gateway.operations",
            unit="1",
            description="Count of source-gateway operations.",
        )
        self.operation_duration = meter.create_histogram(
            "porcli.gateway.operation.duration",
            unit="s",
            description="Duration of source-gateway operations in seconds.",
        )
        self.output_size = meter.create_histogram(
            "porcli.gateway.output.size",
            unit="1",
            description="Count of records emitted by source-gateway operations.",
        )

    async def search(self, request: SearchRequest) -> CanonicalSearchPage:
        with observe_operation(
            self.tracer,
            name="gateway.search",
            counter=self.operation_counter,
            duration_histogram=self.operation_duration,
            metric_attributes={
                "porcli.layer": "gateway",
                "porcli.component": type(self).__name__,
                "porcli.source": self.source.value,
                "porcli.operation": "search",
            },
            span_attributes={
                "porcli.layer": "gateway",
                "porcli.component": type(self).__name__,
                "porcli.source": self.source.value,
                "porcli.operation": "search",
                "porcli.request.page": request.page,
                "porcli.request.query_length": len(request.query),
            },
        ) as span:
            self.logger.info("gateway.search.start", query=request.query, page=request.page)
            raw_response = await self.client.search(request)
            result = self.adapter.adapt_search(raw_response, request)
            set_span_attributes(span, {"porcli.gateway.returned_count": result.pagination.returned_count})
            record_histogram(
                self.output_size,
                result.pagination.returned_count,
                {
                    "porcli.layer": "gateway",
                    "porcli.component": type(self).__name__,
                    "porcli.source": self.source.value,
                    "porcli.operation": "search",
                },
            )
            self.logger.info(
                "gateway.search.complete",
                query=request.query,
                page=request.page,
                returned_count=result.pagination.returned_count,
            )
            return result

    async def get_video(self, request: VideoLookupRequest) -> CanonicalVideoDetail:
        with observe_operation(
            self.tracer,
            name="gateway.video",
            counter=self.operation_counter,
            duration_histogram=self.operation_duration,
            metric_attributes={
                "porcli.layer": "gateway",
                "porcli.component": type(self).__name__,
                "porcli.source": self.source.value,
                "porcli.operation": "video",
            },
            span_attributes={
                "porcli.layer": "gateway",
                "porcli.component": type(self).__name__,
                "porcli.source": self.source.value,
                "porcli.operation": "video",
            },
        ) as span:
            self.logger.info("gateway.video.start", external_id=request.external_id)
            raw_response = await self.client.get_video(request)
            result = self.adapter.adapt_video(raw_response, request)
            set_span_attributes(span, {"porcli.gateway.asset_count": len(result.assets)})
            record_histogram(
                self.output_size,
                len(result.assets),
                {
                    "porcli.layer": "gateway",
                    "porcli.component": type(self).__name__,
                    "porcli.source": self.source.value,
                    "porcli.operation": "video",
                },
            )
            self.logger.info(
                "gateway.video.complete",
                external_id=result.reference.external_id,
                asset_count=len(result.assets),
            )
            return result

    async def get_random(self, request: RandomRequest | None = None) -> CanonicalVideoDetail:
        filters = {} if request is None else dict(request.filters)
        with observe_operation(
            self.tracer,
            name="gateway.random",
            counter=self.operation_counter,
            duration_histogram=self.operation_duration,
            metric_attributes={
                "porcli.layer": "gateway",
                "porcli.component": type(self).__name__,
                "porcli.source": self.source.value,
                "porcli.operation": "random",
            },
            span_attributes={
                "porcli.layer": "gateway",
                "porcli.component": type(self).__name__,
                "porcli.source": self.source.value,
                "porcli.operation": "random",
                "porcli.request.filter_count": len(filters),
            },
        ) as span:
            self.logger.info("gateway.random.start", filters=filters)
            raw_response = await self.client.get_random(request)
            result = self.adapter.adapt_random(raw_response, request)
            set_span_attributes(span, {"porcli.gateway.asset_count": len(result.assets)})
            record_histogram(
                self.output_size,
                len(result.assets),
                {
                    "porcli.layer": "gateway",
                    "porcli.component": type(self).__name__,
                    "porcli.source": self.source.value,
                    "porcli.operation": "random",
                },
            )
            self.logger.info(
                "gateway.random.complete",
                external_id=result.reference.external_id,
                asset_count=len(result.assets),
            )
            return result
