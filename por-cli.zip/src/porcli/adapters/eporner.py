"""Eporner adapter."""

from __future__ import annotations

from urllib.parse import unquote, urlparse

from porcli.adapters.base import BaseSourceAdapter
from porcli.models.canonical import CanonicalAsset, CanonicalSearchPage, CanonicalVideoDetail
from porcli.models.enums import AssetKind, ExternalSource
from porcli.models.raw import EpornerRawSearchRecord, EpornerRawVideoRecord, RawClientResponse
from porcli.models.requests import RandomRequest, SearchRequest, VideoLookupRequest
from porcli.models.schema import JsonObject
from porcli.telemetry import observe_operation, record_histogram, set_span_attributes


class EpornerAdapter(BaseSourceAdapter):
    source = ExternalSource.EPORNER

    def adapt_search(self, response: RawClientResponse, request: SearchRequest) -> CanonicalSearchPage:
        with observe_operation(
            self.tracer,
            name="adapter.search",
            counter=self.operation_counter,
            duration_histogram=self.operation_duration,
            metric_attributes={
                "porcli.layer": "adapter",
                "porcli.component": type(self).__name__,
                "porcli.source": self.source.value,
                "porcli.operation": "search",
            },
            span_attributes={
                "porcli.layer": "adapter",
                "porcli.component": type(self).__name__,
                "porcli.source": self.source.value,
                "porcli.operation": "search",
                "porcli.request.page": request.page,
                "porcli.request.query_length": len(request.query),
            },
        ) as span:
            self.logger.info("adapter.search.start", operation=response.operation.value, query=request.query, page=request.page)
            payload = self._require_payload(response)
            items: list[EpornerRawSearchRecord] = []

            for node in self._choose_collection(payload):
                record = EpornerRawSearchRecord(
                    raw_id=self._pick_text(node, ("id", "video_id", "videoId", "slug")),
                    raw_page_url=self._pick_text(node, ("link", "url", "href", "page_url")),
                    raw_title=self._pick_text(node, ("title", "name", "caption")),
                    raw_thumbnail_url=self._pick_text(node, ("image", "thumbnail", "thumb", "poster", "preview")),
                    raw_embed_url=self._pick_text(node, ("video", "embed", "embed_url", "player_url")),
                    raw_duration_label=self._pick_text(node, ("duration", "duration_label")),
                    raw_views_label=self._pick_text(node, ("views", "view_count")),
                    raw_rating_label=self._pick_text(node, ("rating", "rating_label")),
                    raw_uploader=self._pick_text(node, ("uploader", "author", "username")),
                )
                items.append(record)

            canonical_items = []
            skipped_count = 0
            for record in items:
                external_id = self._normalize_lookup_id(record.raw_id, record.raw_page_url, record.raw_embed_url)
                if external_id is None:
                    skipped_count += 1
                    continue
                canonical_items.append(
                    self._build_reference(
                        source=self.source,
                        external_id=external_id,
                        title=record.raw_title,
                        page_url=record.raw_page_url,
                        embed_url=record.raw_embed_url,
                        thumbnail_url=record.raw_thumbnail_url,
                        capabilities=self._build_capabilities(
                            page_url=record.raw_page_url,
                            embed_url=record.raw_embed_url,
                            thumbnail_url=record.raw_thumbnail_url,
                        ),
                        source_metadata={
                            "duration_label": record.raw_duration_label,
                            "views_label": record.raw_views_label,
                            "rating_label": record.raw_rating_label,
                            "uploader": record.raw_uploader,
                        },
                    )
                )

            source_url = payload.get("source") if isinstance(payload, dict) and isinstance(payload.get("source"), str) else None
            result = CanonicalSearchPage(
                source=self.source,
                query=request.query,
                page=request.page,
                pagination=self._build_pagination(requested_page=request.page, returned_count=len(canonical_items)),
                source_url=self._normalize_text(source_url),
                items=canonical_items,
            )
            set_span_attributes(
                span,
                {
                    "porcli.adapter.raw_record_count": len(items),
                    "porcli.adapter.skipped_record_count": skipped_count,
                    "porcli.adapter.returned_count": result.pagination.returned_count,
                },
            )
            record_histogram(
                self.output_size,
                result.pagination.returned_count,
                {
                    "porcli.layer": "adapter",
                    "porcli.component": type(self).__name__,
                    "porcli.source": self.source.value,
                    "porcli.operation": "search",
                },
            )
            self.logger.info(
                "adapter.search.complete",
                query=request.query,
                page=request.page,
                raw_record_count=len(items),
                skipped_record_count=skipped_count,
                returned_count=result.pagination.returned_count,
            )
            return result

    def adapt_video(self, response: RawClientResponse, request: VideoLookupRequest) -> CanonicalVideoDetail:
        with observe_operation(
            self.tracer,
            name="adapter.video",
            counter=self.operation_counter,
            duration_histogram=self.operation_duration,
            metric_attributes={
                "porcli.layer": "adapter",
                "porcli.component": type(self).__name__,
                "porcli.source": self.source.value,
                "porcli.operation": "video",
            },
            span_attributes={
                "porcli.layer": "adapter",
                "porcli.component": type(self).__name__,
                "porcli.source": self.source.value,
                "porcli.operation": "video",
            },
        ) as span:
            self.logger.info(
                "adapter.video.start",
                operation=response.operation.value,
                external_id=request.external_id,
            )
            payload = self._choose_mapping(self._require_payload(response))
            data = payload.get("data")
            if isinstance(data, dict):
                data_node = data
            else:
                data_node = {}

            raw_assets = self._extract_assets(payload)
            embed_url = next((asset for asset in raw_assets if "/embed/" in asset.lower()), None)
            record = EpornerRawVideoRecord(
                raw_lookup_id=self._normalize_lookup_id(
                    self._pick_text(data_node, ("id", "video_id", "videoId", "slug")),
                    self._pick_text(payload, ("source",)),
                    embed_url,
                )
                or request.external_id,
                raw_page_url=self._pick_text(payload, ("source", "page_url")),
                raw_title=self._pick_text(data_node, ("title", "name", "caption")),
                raw_thumbnail_url=self._pick_text(data_node, ("image", "thumbnail", "thumb", "poster", "preview")),
                raw_embed_url=embed_url,
                raw_duration_label=self._pick_text(data_node, ("duration", "duration_label")),
                raw_views_label=self._pick_text(data_node, ("views", "view_count")),
                raw_rating_label=self._pick_text(data_node, ("rating", "rating_label")),
                raw_uploaded_label=self._pick_text(data_node, ("uploaded", "published_at")),
                raw_uploader=self._pick_text(data_node, ("uploader", "author", "username")),
                raw_performers=self._pick_list(data_node, ("models", "performers", "actors")),
                raw_tags=self._pick_list(data_node, ("tags",)),
                raw_assets=raw_assets,
            )

            reference = self._build_reference(
                source=self.source,
                external_id=record.raw_lookup_id or request.external_id,
                title=record.raw_title,
                page_url=record.raw_page_url,
                embed_url=record.raw_embed_url,
                thumbnail_url=record.raw_thumbnail_url,
                capabilities=self._build_capabilities(
                    page_url=record.raw_page_url,
                    embed_url=record.raw_embed_url,
                    thumbnail_url=record.raw_thumbnail_url,
                ),
            )

            assets = self._build_assets(record)
            detail = CanonicalVideoDetail(
                source=self.source,
                reference=reference,
                source_url=record.raw_page_url,
                duration_label=record.raw_duration_label,
                views_label=record.raw_views_label,
                rating_label=record.raw_rating_label,
                uploaded_label=record.raw_uploaded_label,
                uploader=record.raw_uploader,
                performers=record.raw_performers,
                tags=record.raw_tags,
                assets=assets,
                capabilities=self._build_capabilities(
                    page_url=record.raw_page_url,
                    embed_url=record.raw_embed_url,
                    thumbnail_url=record.raw_thumbnail_url,
                    assets=assets,
                ),
            )
            set_span_attributes(
                span,
                {
                    "porcli.adapter.asset_count": len(detail.assets),
                    "porcli.adapter.performer_count": len(detail.performers),
                    "porcli.adapter.tag_count": len(detail.tags),
                },
            )
            record_histogram(
                self.output_size,
                len(detail.assets),
                {
                    "porcli.layer": "adapter",
                    "porcli.component": type(self).__name__,
                    "porcli.source": self.source.value,
                    "porcli.operation": "video",
                },
            )
            self.logger.info(
                "adapter.video.complete",
                external_id=detail.reference.external_id,
                asset_count=len(detail.assets),
                performer_count=len(detail.performers),
                tag_count=len(detail.tags),
            )
            return detail

    def adapt_random(
        self,
        response: RawClientResponse,
        request: RandomRequest | None = None,
    ) -> CanonicalVideoDetail:
        filters = {} if request is None else dict(request.filters)
        with observe_operation(
            self.tracer,
            name="adapter.random",
            counter=self.operation_counter,
            duration_histogram=self.operation_duration,
            metric_attributes={
                "porcli.layer": "adapter",
                "porcli.component": type(self).__name__,
                "porcli.source": self.source.value,
                "porcli.operation": "random",
            },
            span_attributes={
                "porcli.layer": "adapter",
                "porcli.component": type(self).__name__,
                "porcli.source": self.source.value,
                "porcli.operation": "random",
                "porcli.request.filter_count": len(filters),
            },
        ):
            self.logger.debug("adapter.random.delegate", operation=response.operation.value, filters=filters)
            lookup = VideoLookupRequest(external_id="random")
            return self.adapt_video(response, lookup)

    def _normalize_lookup_id(
        self,
        raw_id: str | None,
        raw_page_url: str | None,
        raw_embed_url: str | None,
    ) -> str | None:
        for candidate in (raw_id, raw_embed_url, raw_page_url):
            normalized = self._extract_lookup_id(candidate)
            if normalized:
                return normalized
        return None

    def _extract_lookup_id(self, value: str | None) -> str | None:
        value = self._normalize_text(value)
        if not value:
            return None

        query_id = self._extract_query_id(value)
        if query_id:
            return self._normalize_text(unquote(query_id))

        if value.startswith(("http://", "https://")):
            parsed = urlparse(value)
            path = parsed.path
        else:
            path = value

        path = path.split("?", 1)[0].split("#", 1)[0]
        segments = [segment for segment in path.split("/") if segment]
        if not segments:
            return None

        if segments[0].startswith("video-"):
            return segments[0].removeprefix("video-") or None
        if len(segments) >= 2 and segments[0] == "hd-porn":
            return segments[1]
        if len(segments) >= 2 and segments[0] == "embed":
            return segments[1]
        if value.isascii() and value.replace("-", "").replace("_", "").isalnum():
            return value
        return None

    def _extract_assets(self, payload: JsonObject) -> list[str]:
        assets: list[str] = []
        raw_assets = payload.get("assets")
        if isinstance(raw_assets, list):
            for item in raw_assets:
                if isinstance(item, str):
                    normalized = self._normalize_text(item)
                    if normalized:
                        assets.append(normalized)
        return assets

    def _build_assets(self, record: EpornerRawVideoRecord) -> list[CanonicalAsset]:
        assets: list[CanonicalAsset] = []
        if record.raw_page_url and self._is_probable_url(record.raw_page_url):
            assets.append(CanonicalAsset(kind=AssetKind.PAGE, url=record.raw_page_url, field_name="source"))
        if record.raw_thumbnail_url and self._is_probable_url(record.raw_thumbnail_url):
            assets.append(
                CanonicalAsset(kind=AssetKind.THUMBNAIL, url=record.raw_thumbnail_url, field_name="data.image")
            )
        for index, asset_url in enumerate(record.raw_assets):
            if not self._is_probable_url(asset_url):
                continue
            assets.append(
                CanonicalAsset(
                    kind=self._asset_kind_from_url(asset_url, field_name=f"assets.{index}"),
                    url=asset_url,
                    field_name=f"assets.{index}",
                )
            )
        return self._dedupe_assets(assets)
