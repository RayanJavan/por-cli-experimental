"""Base adapter helpers."""

from __future__ import annotations

from abc import ABC
from collections.abc import Iterable, Mapping
from urllib.parse import parse_qs, urlparse

from porcli.adapters.contracts import SourceAdapter
from porcli.exceptions import AdapterError
from porcli.logging import get_logger
from porcli.models.canonical import (
    CanonicalAsset,
    CanonicalCapabilities,
    CanonicalPagination,
    CanonicalVideoReference,
)
from porcli.models.enums import AssetKind, ExternalSource
from porcli.models.raw import RawClientResponse
from porcli.models.schema import JsonObject, JsonValue, MetadataMap, StructuredJson
from porcli.telemetry import get_meter, get_tracer


class BaseSourceAdapter(SourceAdapter, ABC):
    """Common adapter helpers for source-specific adapters."""

    source: ExternalSource

    def __init__(self) -> None:
        self.logger = get_logger(__name__).bind(
            layer="adapter",
            component=type(self).__name__,
            source=self.source.value,
        )
        self.tracer = get_tracer(__name__)
        meter = get_meter(__name__)
        self.operation_counter = meter.create_counter(
            "porcli.adapter.operations",
            unit="1",
            description="Count of adapter operations by source and operation.",
        )
        self.operation_duration = meter.create_histogram(
            "porcli.adapter.operation.duration",
            unit="s",
            description="Duration of adapter operations in seconds.",
        )
        self.output_size = meter.create_histogram(
            "porcli.adapter.output.size",
            unit="1",
            description="Count of canonical records emitted by adapter operations.",
        )

    def _require_payload(self, response: RawClientResponse) -> StructuredJson:
        payload = response.transport.json_payload
        if payload is None:
            self.logger.error(
                "adapter.payload.missing",
                operation=response.operation.value,
                status_code=response.transport.status_code,
            )
            raise AdapterError(
                f"{self.source.value} adapter requires a structured payload; HTML/text parsing is not defined yet"
            )
        self.logger.debug(
            "adapter.payload.received",
            operation=response.operation.value,
            payload_type=type(payload).__name__,
            status_code=response.transport.status_code,
        )
        return payload

    @staticmethod
    def _choose_collection(payload: StructuredJson) -> list[JsonObject]:
        if isinstance(payload, list):
            return [dict(item) for item in payload if isinstance(item, Mapping)]

        for key in ("data", "results", "items", "videos", "entries", "list"):
            value = payload.get(key)
            if isinstance(value, list):
                return [dict(item) for item in value if isinstance(item, Mapping)]
            if isinstance(value, Mapping):
                for nested_key in ("data", "results", "items", "videos", "entries", "list"):
                    nested = value.get(nested_key)
                    if isinstance(nested, list):
                        return [dict(item) for item in nested if isinstance(item, Mapping)]
        return []

    @staticmethod
    def _choose_mapping(payload: StructuredJson) -> JsonObject:
        if isinstance(payload, Mapping):
            return dict(payload)
        raise AdapterError("Expected mapping payload for detail adaptation")

    @staticmethod
    def _pick_text(node: Mapping[str, JsonValue], keys: Iterable[str]) -> str | None:
        for key in keys:
            value = node.get(key)
            if isinstance(value, str):
                cleaned = BaseSourceAdapter._normalize_text(value)
                if cleaned:
                    return cleaned
        return None

    @staticmethod
    def _pick_list(node: Mapping[str, JsonValue], keys: Iterable[str]) -> list[str]:
        for key in keys:
            value = node.get(key)
            if isinstance(value, list):
                cleaned = [BaseSourceAdapter._normalize_text(item) for item in value if isinstance(item, str)]
                return [item for item in cleaned if item]
        return []

    @staticmethod
    def _normalize_text(value: str | None) -> str | None:
        if value is None:
            return None
        cleaned = " ".join(value.replace("\t", " ").replace("\r", " ").replace("\n", " ").split())
        return cleaned or None

    @staticmethod
    def _is_probable_url(value: str | None) -> bool:
        if not value:
            return False
        return value.startswith(("http://", "https://"))

    @staticmethod
    def _asset_kind_from_url(url: str, field_name: str | None = None) -> AssetKind:
        field_name = (field_name or "").lower()
        url_lower = url.lower()

        if "/embed/" in url_lower or "embed" in field_name:
            return AssetKind.EMBED
        if any(url_lower.endswith(ext) or ext in url_lower for ext in (".jpg", ".jpeg", ".png", ".gif", ".webp", ".svg")):
            return AssetKind.THUMBNAIL
        if any(ext in url_lower for ext in (".m3u8", ".mpd")):
            return AssetKind.STREAM
        if any(ext in url_lower for ext in (".mp4", ".webm", ".mkv", ".mov", ".avi")):
            return AssetKind.DOWNLOAD
        if "page" in field_name or "source" in field_name:
            return AssetKind.PAGE
        return AssetKind.UNKNOWN

    @staticmethod
    def _dedupe_assets(assets: Iterable[CanonicalAsset]) -> list[CanonicalAsset]:
        seen: set[tuple[AssetKind, str]] = set()
        ordered: list[CanonicalAsset] = []
        for asset in assets:
            key = (asset.kind, asset.url)
            if key in seen:
                continue
            seen.add(key)
            ordered.append(asset)
        return ordered

    @staticmethod
    def _build_reference(
        source: ExternalSource,
        external_id: str,
        title: str | None,
        page_url: str | None,
        embed_url: str | None,
        thumbnail_url: str | None,
        capabilities: CanonicalCapabilities | None = None,
        source_metadata: MetadataMap | None = None,
    ) -> CanonicalVideoReference:
        return CanonicalVideoReference(
            source=source,
            external_id=external_id,
            title=title,
            page_url=page_url,
            embed_url=embed_url,
            thumbnail_url=thumbnail_url,
            capabilities=capabilities or CanonicalCapabilities(),
            source_metadata=source_metadata or {},
        )

    @staticmethod
    def _extract_query_id(url: str) -> str | None:
        parsed = urlparse(url)
        values = parse_qs(parsed.query).get("id", [])
        if values:
            return values[0]
        return None

    @staticmethod
    def _build_pagination(
        requested_page: int,
        returned_count: int,
        has_more: bool | None = None,
        next_page: int | None = None,
    ) -> CanonicalPagination:
        return CanonicalPagination(
            requested_page=requested_page,
            returned_count=returned_count,
            has_more=has_more,
            next_page=next_page,
        )

    @classmethod
    def _build_capabilities(
        cls,
        *,
        page_url: str | None = None,
        embed_url: str | None = None,
        thumbnail_url: str | None = None,
        assets: Iterable[CanonicalAsset] = (),
    ) -> CanonicalCapabilities:
        capabilities = CanonicalCapabilities(
            has_page_url=cls._is_probable_url(page_url),
            has_embed_url=cls._is_probable_url(embed_url),
            has_thumbnail_url=cls._is_probable_url(thumbnail_url),
        )

        for asset in assets:
            match asset.kind:
                case AssetKind.STREAM:
                    capabilities.has_stream_asset = True
                case AssetKind.DOWNLOAD:
                    capabilities.has_download_asset = True
                case AssetKind.UNKNOWN:
                    capabilities.has_unknown_asset = True
                case _:
                    continue

        return capabilities
