"""Adapter contracts and source-specific adapters."""

from porcli.adapters.eporner import EpornerAdapter
from porcli.adapters.xhamster import XHamsterAdapter

__all__ = ["EpornerAdapter", "XHamsterAdapter"]
