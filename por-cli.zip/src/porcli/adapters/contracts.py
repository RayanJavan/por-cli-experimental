"""Adapter contracts."""

from __future__ import annotations

from abc import ABC, abstractmethod

from porcli.models.canonical import CanonicalSearchPage, CanonicalVideoDetail
from porcli.models.raw import RawClientResponse
from porcli.models.requests import RandomRequest, SearchRequest, VideoLookupRequest


class SourceAdapter(ABC):
    """Adapter interface for canonicalizing source-specific raw responses."""

    @abstractmethod
    def adapt_search(self, response: RawClientResponse, request: SearchRequest) -> CanonicalSearchPage:
        """Adapt a raw search response into a canonical search page."""

    @abstractmethod
    def adapt_video(self, response: RawClientResponse, request: VideoLookupRequest) -> CanonicalVideoDetail:
        """Adapt a raw video response into a canonical video detail."""

    @abstractmethod
    def adapt_random(
        self,
        response: RawClientResponse,
        request: RandomRequest | None = None,
    ) -> CanonicalVideoDetail:
        """Adapt a raw random-video response into a canonical video detail."""
