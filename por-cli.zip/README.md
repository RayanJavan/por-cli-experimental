# por-cli

This repository now contains a Python rewrite scaffold focused on a layered
architecture for direct external-source integrations.

Current scope:

- `Client` layer: source-specific communication strategies
- `Adapter` layer: source-specific adapters that map raw source responses into a
  canonical model
- `Service` layer: source-agnostic orchestration over canonical source gateways

Not in scope yet:

- service orchestration
- CLI/UI behavior
- full source scraping details

The package uses:

- Strategy pattern for source clients
- Adapter pattern for source adapters

Project layout:

- `src/porcli/models`: shared enums, requests, raw transport envelopes, and
  canonical DTOs
- `src/porcli/clients`: client contracts, HTTP transport, and source strategies
- `src/porcli/adapters`: adapter contracts and source-specific adapters
- `src/porcli/probes`: field probe tools for direct runtime investigation
- `src/porcli/services`: canonical gateways and source-agnostic service logic
- `src/porcli/registry.py`: source runtime factories and composition helpers
- `scripts/`: runnable shell helpers for field execution on Linux/Ubuntu
- `tests/`: offline tests for contracts, strategies, and adapters

The inter-layer request/response flow is modeled with Pydantic schemas so the
Client, Adapter, and Service boundaries stay explicit and validated.

Logging:

- `porcli.logging` configures `structlog` on top of stdlib logging
- logging is explicit and library-safe: imports do not auto-configure handlers
- contextvars are supported through `bind_context`, `bound_context`,
  `unbind_context`, and `clear_context`
- the client, transport, adapter, gateway, service, and registry layers bind
  source and operation context into their log events
- active OpenTelemetry trace context is added to logs automatically when spans
  are present

Telemetry:

- `porcli.telemetry` configures package-local OpenTelemetry tracing and metrics
- telemetry configuration is explicit and test-friendly; providers are not
  forced into the process-global OpenTelemetry state
- `configure_in_memory_telemetry()` provides in-memory exporters for offline
  testing and future development probes
- the client, transport, adapter, gateway, service, and registry layers emit
  spans and operation metrics around their main execution boundaries

Client field probe:

- run `bash scripts/run-client-field-suite.sh` on the Ubuntu VM after uploading
  the repo
- the wrapper stores artifacts under `client-field-probe-output/<timestamp>/`
  unless `PORCLI_CLIENT_FIELD_OUTPUT_DIR` overrides it
- structured logs go to `logs/suite.log.jsonl`
- launcher stdout/stderr are captured in `logs/runner.stdout.log` and
  `logs/runner.stderr.log`
- per-case request/response artifacts go under `artifacts/<source>/<operation>/`
- in-memory telemetry is dumped to `telemetry/spans.json` and
  `telemetry/metrics.json`
- the suite uses heuristic default operation templates; if those need tuning,
  generate an editable config with:
  `python3 -m porcli.probes.client_field_suite --write-example-config client-field-suite.example.json`
- then rerun with:
  `bash scripts/run-client-field-suite.sh --config client-field-suite.example.json`
