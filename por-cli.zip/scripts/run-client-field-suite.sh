#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd -- "$SCRIPT_DIR/.." && pwd)"
TIMESTAMP="$(date -u +%Y%m%dT%H%M%SZ)"

OUTPUT_DIR="${PORCLI_CLIENT_FIELD_OUTPUT_DIR:-$REPO_DIR/client-field-probe-output/$TIMESTAMP}"
CONFIG_PATH="${PORCLI_CLIENT_FIELD_CONFIG:-}"
LOG_LEVEL="${PORCLI_CLIENT_FIELD_LOG_LEVEL:-DEBUG}"
PYTHON_BIN="${PORCLI_CLIENT_FIELD_PYTHON_BIN:-python3}"

mkdir -p "$OUTPUT_DIR/logs"

COMMAND=(
  "$PYTHON_BIN"
  -m
  porcli.probes.client_field_suite
  --output-dir
  "$OUTPUT_DIR"
  --log-level
  "$LOG_LEVEL"
)

if [[ -n "$CONFIG_PATH" ]]; then
  COMMAND+=(--config "$CONFIG_PATH")
fi

if [[ "${PORCLI_CLIENT_FIELD_FAIL_ON_CASE_ERROR:-0}" == "1" ]]; then
  COMMAND+=(--fail-on-case-error)
fi

if [[ $# -gt 0 ]]; then
  COMMAND+=("$@")
fi

export PYTHONPATH="$REPO_DIR/src${PYTHONPATH:+:$PYTHONPATH}"

{
  echo "timestamp=$TIMESTAMP"
  echo "repo_dir=$REPO_DIR"
  echo "output_dir=$OUTPUT_DIR"
  echo "python_bin=$PYTHON_BIN"
  echo "config_path=${CONFIG_PATH:-<heuristic-default>}"
  printf 'command='
  printf '%q ' "${COMMAND[@]}"
  echo
} > "$OUTPUT_DIR/logs/launcher.env"

"${COMMAND[@]}" \
  > >(tee "$OUTPUT_DIR/logs/runner.stdout.log") \
  2> >(tee "$OUTPUT_DIR/logs/runner.stderr.log" >&2)

echo "client field probe output stored in: $OUTPUT_DIR"
