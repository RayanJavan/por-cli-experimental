#!/usr/bin/env bash
set -euo pipefail

DOMAIN='testt00.rayanjavanparast2004-vmern.arvanedge.ir'
ORIGIN_TLS_MODE='http_only'
DNS_CHECK_MODE='resolve_only'
EMAIL='tt@ttt.com'
SERVER_PUBLIC_IP='91.107.250.124'
XRAY_WS_LISTEN='32109'
GENERATED_AT_UTC='2026-04-26T22:49:42Z'

if [[ "$(id -u)" -ne 0 ]]; then
  if command -v sudo >/dev/null 2>&1; then
    exec sudo -E bash "$0" "$@"
  fi
  printf 'error: this script must run as root or through sudo\n' >&2
  exit 1
fi

SCRIPT_DIR=$(cd -- "$(dirname "${BASH_SOURCE[0]}")" && pwd)

log() {
  printf '[%s] %s\n' "$(date +'%F %T')" "$*"
}

require_cmd() {
  command -v "$1" >/dev/null 2>&1 || {
    printf 'error: missing command: %s\n' "$1" >&2
    exit 1
  }
}

require_cmd apt
require_cmd install
require_cmd ln
require_cmd rm

log "Generated pack timestamp: $GENERATED_AT_UTC"
log "Origin TLS mode: $ORIGIN_TLS_MODE"
log "Installing base packages"
export DEBIAN_FRONTEND=noninteractive
apt update
if [[ "$ORIGIN_TLS_MODE" == "letsencrypt" ]]; then
  apt install -y nginx certbot curl ca-certificates unzip python3 openssl
else
  apt install -y nginx curl ca-certificates unzip python3 openssl
fi

log "Checking DNS for $DOMAIN (mode: $DNS_CHECK_MODE)"
if [[ "$DNS_CHECK_MODE" != "skip" ]] && command -v getent >/dev/null 2>&1; then
  resolved_ipv4=$(getent ahostsv4 "$DOMAIN" | awk '{print $1}' | sort -u | paste -sd ',' -)
  if [[ -z "$resolved_ipv4" ]]; then
    printf 'error: %s does not resolve to an IPv4 address on this server\n' "$DOMAIN" >&2
    exit 1
  fi

  if [[ "$DNS_CHECK_MODE" == "direct" && ",$resolved_ipv4," != *",$SERVER_PUBLIC_IP,"* ]]; then
    printf 'error: DNS mismatch for %s. Expected IPv4 %s, got %s\n' "$DOMAIN" "$SERVER_PUBLIC_IP" "$resolved_ipv4" >&2
    exit 1
  fi

  log "Resolved public IPv4s for $DOMAIN: $resolved_ipv4"
elif [[ "$DNS_CHECK_MODE" == "skip" ]]; then
  log "Skipping public DNS validation by configuration"
fi

log "Installing Xray-core via the official installer"
bash -c "$(curl -L https://github.com/XTLS/Xray-install/raw/main/install-release.sh)" @ install

log "Preparing web and log directories"
mkdir -p /var/www/html
mkdir -p /var/log/xray
if [[ "$ORIGIN_TLS_MODE" == "letsencrypt" ]]; then
  mkdir -p /var/www/certbot/.well-known/acme-challenge
fi

log "Installing rendered Xray and Nginx files"
install -D -m 644 "$SCRIPT_DIR/usr/local/etc/xray/config.json" /usr/local/etc/xray/config.json
install -D -m 644 "$SCRIPT_DIR/etc/nginx/conf.d/20-vless-wss-logging.conf" /etc/nginx/conf.d/20-vless-wss-logging.conf
install -D -m 644 "$SCRIPT_DIR/etc/nginx/sites-available/00-bootstrap-http.conf" /etc/nginx/sites-available/vless-wss-bootstrap.conf
install -D -m 644 "$SCRIPT_DIR/etc/nginx/sites-available/10-vless-wss.conf" /etc/nginx/sites-available/vless-wss.conf
install -D -m 644 "$SCRIPT_DIR/etc/nginx/sites-available/11-vless-wss-origin-http.conf" /etc/nginx/sites-available/vless-wss-origin-http.conf
install -D -m 644 "$SCRIPT_DIR/etc/logrotate.d/xray" /etc/logrotate.d/xray
install -D -m 644 "$SCRIPT_DIR/var/www/html/index.html" /var/www/html/index.html

rm -f /etc/nginx/sites-enabled/default
systemctl enable nginx

if [[ "$ORIGIN_TLS_MODE" == "letsencrypt" ]]; then
  log "Enabling bootstrap HTTP site for ACME"
  ln -sf /etc/nginx/sites-available/vless-wss-bootstrap.conf /etc/nginx/sites-enabled/vless-wss-bootstrap.conf
  nginx -t
  systemctl restart nginx

  log "Requesting Let's Encrypt certificate for $DOMAIN"
  certbot certonly \
    --webroot \
    -w /var/www/certbot \
    -d "$DOMAIN" \
    --email "$EMAIL" \
    --agree-tos \
    --non-interactive

  log "Switching Nginx to the final HTTPS + WSS site"
  rm -f /etc/nginx/sites-enabled/vless-wss-bootstrap.conf
  ln -sf /etc/nginx/sites-available/vless-wss.conf /etc/nginx/sites-enabled/vless-wss.conf
  nginx -t
  systemctl restart nginx
else
  log "Using origin HTTP-only mode; skipping Certbot and origin TLS"
  ln -sf /etc/nginx/sites-available/vless-wss-origin-http.conf /etc/nginx/sites-enabled/vless-wss-origin-http.conf
  nginx -t
  systemctl restart nginx
  log "Keep the CDN origin pull protocol set to HTTP while using origin HTTP-only mode"
fi

log "Enabling and restarting Xray"
systemctl enable xray
systemctl restart xray

log "Deployment complete"
if [[ "$ORIGIN_TLS_MODE" == "letsencrypt" ]]; then
  log "Expected listeners: nginx on :80 and :443, xray on 127.0.0.1:32109"
else
  log "Expected listeners: nginx on :80, xray on 127.0.0.1:32109"
fi
log "Run $SCRIPT_DIR/vm-postcheck.sh for a quick validation pass"
log "Run $SCRIPT_DIR/vm-edge-observability.sh after traffic has been collected to build an observability report"
