#!/usr/bin/env bash
set -euo pipefail

DOMAIN='testt00.rayanjavanparast2004-vmern.arvanedge.ir'
EMAIL='tt@ttt.com'
SERVER_PUBLIC_IP='91.107.250.124'
XRAY_WS_LISTEN='32109'
GENERATED_AT_UTC='2026-04-26T22:19:01Z'

if [[ "$(id -u)" -ne 0 ]]; then
  if command -v sudo >/dev/null 2>&1; then
    exec sudo -E bash "$0" "$@"
  fi
  printf 'error: this script must run as root or through sudo\n' >&2
  exit 1
fi

SCRIPT_DIR=$(cd -- "$(dirname "${BASH_SOURCE[0]}")" && pwd)

log() {
  printf '[%s] %s\n' "$(date +'%F %T')" "$*"
}

require_cmd() {
  command -v "$1" >/dev/null 2>&1 || {
    printf 'error: missing command: %s\n' "$1" >&2
    exit 1
  }
}

require_cmd apt
require_cmd install
require_cmd ln
require_cmd rm

log "Generated pack timestamp: $GENERATED_AT_UTC"
log "Installing base packages"
export DEBIAN_FRONTEND=noninteractive
apt update
apt install -y nginx certbot curl ca-certificates unzip python3 openssl

log "Checking DNS for $DOMAIN"
if command -v getent >/dev/null 2>&1; then
  resolved_ipv4=$(getent ahostsv4 "$DOMAIN" | awk '{print $1}' | sort -u | paste -sd ',' -)
  if [[ -z "$resolved_ipv4" ]]; then
    printf 'error: %s does not resolve to an IPv4 address on this server\n' "$DOMAIN" >&2
    exit 1
  fi
  if [[ ",$resolved_ipv4," != *",$SERVER_PUBLIC_IP,"* ]]; then
    printf 'error: DNS mismatch for %s. Expected IPv4 %s, got %s\n' "$DOMAIN" "$SERVER_PUBLIC_IP" "$resolved_ipv4" >&2
    exit 1
  fi
fi

log "Installing Xray-core via the official installer"
bash -c "$(curl -L https://github.com/XTLS/Xray-install/raw/main/install-release.sh)" @ install

log "Preparing ACME and web directories"
mkdir -p /var/www/html
mkdir -p /var/www/certbot/.well-known/acme-challenge
mkdir -p /var/log/xray

log "Installing rendered Xray and Nginx files"
install -D -m 644 "$SCRIPT_DIR/usr/local/etc/xray/config.json" /usr/local/etc/xray/config.json
install -D -m 644 "$SCRIPT_DIR/etc/nginx/conf.d/20-vless-wss-logging.conf" /etc/nginx/conf.d/20-vless-wss-logging.conf
install -D -m 644 "$SCRIPT_DIR/etc/nginx/sites-available/00-bootstrap-http.conf" /etc/nginx/sites-available/vless-wss-bootstrap.conf
install -D -m 644 "$SCRIPT_DIR/etc/nginx/sites-available/10-vless-wss.conf" /etc/nginx/sites-available/vless-wss.conf
install -D -m 644 "$SCRIPT_DIR/etc/logrotate.d/xray" /etc/logrotate.d/xray
install -D -m 644 "$SCRIPT_DIR/var/www/html/index.html" /var/www/html/index.html

log "Enabling bootstrap HTTP site for ACME"
rm -f /etc/nginx/sites-enabled/default
ln -sf /etc/nginx/sites-available/vless-wss-bootstrap.conf /etc/nginx/sites-enabled/vless-wss-bootstrap.conf
nginx -t
systemctl enable nginx
systemctl restart nginx

log "Requesting Let's Encrypt certificate for $DOMAIN"
certbot certonly \
  --webroot \
  -w /var/www/certbot \
  -d "$DOMAIN" \
  --email "$EMAIL" \
  --agree-tos \
  --non-interactive

log "Switching Nginx to the final HTTPS + WSS site"
rm -f /etc/nginx/sites-enabled/vless-wss-bootstrap.conf
ln -sf /etc/nginx/sites-available/vless-wss.conf /etc/nginx/sites-enabled/vless-wss.conf
nginx -t
systemctl restart nginx

log "Enabling and restarting Xray"
systemctl enable xray
systemctl restart xray

log "Deployment complete"
log "Expected listeners: nginx on :80 and :443, xray on 127.0.0.1:32109"
log "Run $SCRIPT_DIR/vm-postcheck.sh for a quick validation pass"
log "Run $SCRIPT_DIR/vm-edge-observability.sh after traffic has been collected to build an observability report"
