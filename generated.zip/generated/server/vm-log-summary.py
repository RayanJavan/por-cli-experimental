#!/usr/bin/env python3
import argparse
import collections
import json
import math
import os
import sys


def load_jsonl(path):
    rows = []
    if not os.path.exists(path):
        return rows

    with open(path, "r", encoding="utf-8") as handle:
        for line_number, raw_line in enumerate(handle, start=1):
            line = raw_line.strip()
            if not line:
                continue
            try:
                rows.append(json.loads(line))
            except json.JSONDecodeError as exc:
                rows.append(
                    {
                        "_parse_error": f"{path}:{line_number}: {exc}",
                        "_raw": line,
                    }
                )
    return rows


def counter(values):
    return collections.Counter(v for v in values if v not in (None, "", "-"))


def parse_float(value):
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def percentile(values, pct):
    if not values:
        return None
    if len(values) == 1:
        return values[0]

    ordered = sorted(values)
    index = (len(ordered) - 1) * pct
    floor = math.floor(index)
    ceil = math.ceil(index)
    if floor == ceil:
        return ordered[int(index)]
    lower = ordered[floor]
    upper = ordered[ceil]
    return lower + (upper - lower) * (index - floor)


def print_counter(title, counts, limit=None):
    print(title)
    if not counts:
        print("  none")
        return
    for key, value in counts.most_common(limit):
        print(f"  {key}: {value}")


def summarize_general(rows):
    print("== General HTTPS access log summary ==")
    parse_errors = [r for r in rows if "_parse_error" in r]
    data = [r for r in rows if "_parse_error" not in r]
    print(f"entries: {len(data)}")
    if parse_errors:
        print(f"parse_errors: {len(parse_errors)}")
        for item in parse_errors[:5]:
            print(f"  {item['_parse_error']}")

    print_counter("status codes:", counter(r.get("status") for r in data))
    print_counter("methods:", counter(r.get("method") for r in data))
    print_counter("top uris:", counter(r.get("uri") for r in data), limit=10)
    print_counter("http versions:", counter(r.get("server_protocol") for r in data))
    print_counter("tls versions:", counter(r.get("ssl_protocol") for r in data))
    print_counter("tls ciphers:", counter(r.get("ssl_cipher") for r in data), limit=10)

    ua_missing = sum(1 for r in data if r.get("user_agent") in ("", "-", None))
    print(f"user_agent_missing: {ua_missing}")

    request_times = [v for v in (parse_float(r.get("request_time")) for r in data) if v is not None]
    if request_times:
        print(f"request_time_p50: {percentile(request_times, 0.50):.4f}")
        print(f"request_time_p95: {percentile(request_times, 0.95):.4f}")

    notes = []
    if any(int(r.get("status", 0)) >= 500 for r in data):
        notes.append("5xx responses present in general HTTPS traffic")
    if any(str(r.get("ssl_protocol", "")).startswith("TLSv1.") and r.get("ssl_protocol") not in ("TLSv1.2", "TLSv1.3") for r in data):
        notes.append("unexpected legacy TLS protocol observed")
    if ua_missing and data and ua_missing / len(data) > 0.20:
        notes.append("more than 20% of general requests have a missing user-agent")

    print("notes:")
    if notes:
        for note in notes:
            print(f"  - {note}")
    else:
        print("  - no obvious general HTTPS anomalies detected")
    print()


def summarize_ws(rows):
    print("== WebSocket path access log summary ==")
    parse_errors = [r for r in rows if "_parse_error" in r]
    data = [r for r in rows if "_parse_error" not in r]
    print(f"entries: {len(data)}")
    if parse_errors:
        print(f"parse_errors: {len(parse_errors)}")
        for item in parse_errors[:5]:
            print(f"  {item['_parse_error']}")

    print_counter("status codes:", counter(r.get("status") for r in data))
    print_counter("methods:", counter(r.get("method") for r in data))
    print_counter("upgrade header values:", counter(r.get("upgrade") for r in data))
    print_counter("ws versions:", counter(r.get("sec_ws_version") for r in data))
    print_counter("upstream statuses:", counter(r.get("upstream_status") for r in data))
    print_counter("tls versions:", counter(r.get("ssl_protocol") for r in data))

    request_times = [v for v in (parse_float(r.get("request_time")) for r in data) if v is not None]
    if request_times:
        print(f"request_time_p50: {percentile(request_times, 0.50):.4f}")
        print(f"request_time_p95: {percentile(request_times, 0.95):.4f}")

    response_times = [v for v in (parse_float(r.get("upstream_response_time")) for r in data) if v is not None]
    if response_times:
        print(f"upstream_response_time_p50: {percentile(response_times, 0.50):.4f}")
        print(f"upstream_response_time_p95: {percentile(response_times, 0.95):.4f}")

    notes = []
    non_get = [r for r in data if r.get("method") not in (None, "", "-", "GET")]
    if non_get:
        notes.append(f"non-GET requests hit the WS path: {len(non_get)}")

    attempted_upgrades = [r for r in data if r.get("upgrade") in ("websocket", "WebSocket")]
    missing_upgrade = [r for r in data if r.get("upgrade") in (None, "", "-")]
    if missing_upgrade:
        notes.append(
            f"requests hit the WS path without an Upgrade header: {len(missing_upgrade)}"
        )

    non_ws_upgrade = [
        r
        for r in data
        if r.get("upgrade") not in (None, "", "-", "websocket", "WebSocket")
    ]
    if non_ws_upgrade:
        notes.append(f"unexpected Upgrade header values observed on the WS path: {len(non_ws_upgrade)}")

    non_101 = [r for r in attempted_upgrades if str(r.get("status")) != "101"]
    if non_101:
        notes.append(f"upgrade attempts with non-101 responses observed on the WS path: {len(non_101)}")

    bad_upstream = [
        r for r in attempted_upgrades if r.get("upstream_status") not in (None, "", "-", "101")
    ]
    if bad_upstream:
        notes.append(f"unexpected upstream_status values observed for WS upgrade attempts: {len(bad_upstream)}")

    if any(int(r.get("status", 0)) >= 500 for r in data):
        notes.append("5xx responses present on the WS path")

    print("notes:")
    if notes:
        for note in notes:
            print(f"  - {note}")
    else:
        print("  - no obvious WS-path anomalies detected")
    print()


def main():
    parser = argparse.ArgumentParser(
        description="Summarize structured Nginx logs for HTTPS and WebSocket path behavior."
    )
    parser.add_argument("--general-log", required=True)
    parser.add_argument("--ws-log", required=True)
    args = parser.parse_args()

    print("This summary evaluates origin-side protocol behavior only.")
    print("It does not predict how any external edge provider will classify traffic.")
    print()

    summarize_general(load_jsonl(args.general_log))
    summarize_ws(load_jsonl(args.ws_log))


if __name__ == "__main__":
    sys.exit(main())
