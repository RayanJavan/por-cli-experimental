#!/usr/bin/env bash
set -euo pipefail

DOMAIN='https://test00.rayanjavanparast2004-vmern.arvanedge.ir'
WS_PATH='/5fjb18cp46a04v2f'
XRAY_WS_LISTEN='32109'

if [[ "$(id -u)" -ne 0 ]]; then
  if command -v sudo >/dev/null 2>&1; then
    exec sudo -E bash "$0" "$@"
  fi
  printf 'error: this script must run as root or through sudo\n' >&2
  exit 1
fi

for cmd in curl openssl python3 ss journalctl systemctl tail timeout; do
  command -v "$cmd" >/dev/null 2>&1 || {
    printf 'error: missing command: %s\n' "$cmd" >&2
    exit 1
  }
done

REPORT_DIR="/var/tmp/vless-wss-observability-$(date -u +%Y%m%dT%H%M%SZ)"
SCRIPT_DIR=$(cd -- "$(dirname "${BASH_SOURCE[0]}")" && pwd)
mkdir -p "$REPORT_DIR"

printf 'Report directory: %s\n' "$REPORT_DIR"

systemctl --no-pager --full status nginx xray > "$REPORT_DIR/01-service-status.txt" 2>&1 || true
ss -ltnp | grep -E ":80|:443|:32109" > "$REPORT_DIR/02-listeners.txt" 2>&1 || true

openssl s_client -connect "https://test00.rayanjavanparast2004-vmern.arvanedge.ir:443" -servername "https://test00.rayanjavanparast2004-vmern.arvanedge.ir" -showcerts < /dev/null > "$REPORT_DIR/03-tls-handshake.txt" 2>&1 || true
curl -4 -sS -o /dev/null -D "$REPORT_DIR/04-root-head-http11.txt" --http1.1 "https://https://test00.rayanjavanparast2004-vmern.arvanedge.ir/" || true
curl -4 -sS -o /dev/null -D "$REPORT_DIR/05-root-head-http2.txt" --http2 "https://https://test00.rayanjavanparast2004-vmern.arvanedge.ir/" || true
curl -4 -sS -o "$REPORT_DIR/06-ws-no-upgrade-body.txt" -D "$REPORT_DIR/06-ws-no-upgrade.txt" --http1.1 "https://https://test00.rayanjavanparast2004-vmern.arvanedge.ir/5fjb18cp46a04v2f" || true

{
  printf 'GET %s HTTP/1.1\r\n' "$WS_PATH"
  printf 'Host: %s\r\n' "$DOMAIN"
  printf 'Connection: Upgrade\r\n'
  printf 'Upgrade: websocket\r\n'
  printf 'Sec-WebSocket-Key: dGhlIHNhbXBsZSBub25jZQ==\r\n'
  printf 'Sec-WebSocket-Version: 13\r\n'
  printf 'User-Agent: VM-Observability/1.0\r\n'
  printf 'Origin: https://%s\r\n' "$DOMAIN"
  printf '\r\n'
} | timeout 8s openssl s_client -connect "https://test00.rayanjavanparast2004-vmern.arvanedge.ir:443" -servername "https://test00.rayanjavanparast2004-vmern.arvanedge.ir" -quiet -ign_eof > "$REPORT_DIR/07-ws-upgrade-probe.txt" 2>&1 || true

{
  printf 'GET /__vm_probe_not_found__ HTTP/1.1\r\n'
  printf 'Host: %s\r\n' "$DOMAIN"
  printf 'Connection: Upgrade\r\n'
  printf 'Upgrade: websocket\r\n'
  printf 'Sec-WebSocket-Key: dGhlIHNhbXBsZSBub25jZQ==\r\n'
  printf 'Sec-WebSocket-Version: 13\r\n'
  printf 'User-Agent: VM-Observability/1.0\r\n'
  printf 'Origin: https://%s\r\n' "$DOMAIN"
  printf '\r\n'
} | timeout 8s openssl s_client -connect "https://test00.rayanjavanparast2004-vmern.arvanedge.ir:443" -servername "https://test00.rayanjavanparast2004-vmern.arvanedge.ir" -quiet -ign_eof > "$REPORT_DIR/08-bad-ws-upgrade-probe.txt" 2>&1 || true

tail -n 200 /var/log/nginx/vless_wss_access.log > "$REPORT_DIR/09-nginx-access-tail.txt" 2>&1 || true
tail -n 200 /var/log/nginx/vless_wss_ws_access.log > "$REPORT_DIR/10-nginx-ws-access-tail.txt" 2>&1 || true
journalctl -u xray -n 200 --no-pager > "$REPORT_DIR/11-xray-journal-tail.txt" 2>&1 || true
journalctl -u nginx -n 200 --no-pager > "$REPORT_DIR/12-nginx-journal-tail.txt" 2>&1 || true

python3 "$SCRIPT_DIR/vm-log-summary.py" \
  --general-log /var/log/nginx/vless_wss_access.log \
  --ws-log /var/log/nginx/vless_wss_ws_access.log \
  > "$REPORT_DIR/13-log-summary.txt" 2>&1 || true

cat > "$REPORT_DIR/README.txt" <<EOF
This report captures origin-side observability only.

Interpretation guidance:
- 04-root-head-http11.txt should usually show HTTP/1.1 200 or 304.
- 05-root-head-http2.txt should usually show HTTP/2 200 or 304 if curl supports HTTP/2.
- 06-ws-no-upgrade.txt should usually show 404 for the WS path without Upgrade headers.
- 07-ws-upgrade-probe.txt should usually contain HTTP/1.1 101 Switching Protocols.
- 08-bad-ws-upgrade-probe.txt should usually show 404 for a bogus WS path.
- 13-log-summary.txt summarizes the structured Nginx logs and highlights obvious anomalies.

This does not predict how any upstream CDN or edge provider will classify traffic.
It only helps verify that your origin behaves like a clean HTTPS + WebSocket service.
EOF

printf 'Observability report written to %s\n' "$REPORT_DIR"
