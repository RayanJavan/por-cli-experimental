#!/usr/bin/env bash
set -euo pipefail

DOMAIN='https://test00.rayanjavanparast2004-vmern.arvanedge.ir'
ORIGIN_TLS_MODE='http_only'
XRAY_WS_LISTEN='32109'

if [[ "$(id -u)" -ne 0 ]]; then
  if command -v sudo >/dev/null 2>&1; then
    exec sudo -E bash "$0" "$@"
  fi
  printf 'error: this script must run as root or through sudo\n' >&2
  exit 1
fi

printf '== Services ==\n'
systemctl --no-pager --full status nginx xray || true

printf '\n== Listening ports ==\n'
ss -ltnp | grep -E ":80|:443|:32109" || true

if [[ "$ORIGIN_TLS_MODE" == "letsencrypt" ]]; then
  printf '\n== HTTPS HEAD ==\n'
  curl -I "https://https://test00.rayanjavanparast2004-vmern.arvanedge.ir/" || true
else
  printf '\n== Local origin HTTP HEAD ==\n'
  curl -I -H "Host: https://test00.rayanjavanparast2004-vmern.arvanedge.ir" "http://127.0.0.1/" || true
fi

printf '\n== Recent Nginx logs ==\n'
journalctl -u nginx -n 50 --no-pager || true

printf '\n== Recent Xray logs ==\n'
journalctl -u xray -n 50 --no-pager || true

printf '\n== Recent structured Nginx access logs ==\n'
tail -n 20 /var/log/nginx/vless_wss_access.log || true

printf '\n== Recent structured Nginx WS logs ==\n'
tail -n 20 /var/log/nginx/vless_wss_ws_access.log || true
